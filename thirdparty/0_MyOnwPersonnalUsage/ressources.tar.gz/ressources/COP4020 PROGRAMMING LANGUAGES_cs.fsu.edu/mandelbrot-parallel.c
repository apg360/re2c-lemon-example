/* 
 c program:
 --------------------------------
  1. draws Mandelbrot set for Fc(z)=z*z +c
  using Mandelbrot algorithm ( boolean escape time )
 -------------------------------         
 2. technique of creating ppm file is  based on the code of Claudio Rocchini
 http://en.wikipedia.org/wiki/Image:Color_complex_plot.jpg
 create 24 bit color graphic file ,  portable pixmap file = PPM 
 see http://en.wikipedia.org/wiki/Portable_pixmap
 to see the file use external application ( graphic viewer)
  */

/* 

   ORIGINAL SOURCE CODE COURTESY OF ROSETTA CODE: 

     http://rosettacode.org/wiki/Mandelbrot_set#PPM_non_interactive

*/

#include <pthread.h>

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <poll.h>


struct client_attributes
{
  int self;
  int pipe_client_to_server[2];
  int pipe_server_to_client[2];
  pthread_t tid;
};

struct message
{
  int first_y;
  int last_y;
};

struct client_attributes client_attributes[5];
struct pollfd poll_fds[5];
int create_client(int i);
int send_request_client(int i, int first_y, int last_y);
int shutdown_client(int i);
void *client(void *id);
int do_block(int,int);

//int do_block(int first_y,int last_y);

FILE * fp;
const int iXmax = 3600; 
const int iYmax = 3600;
const int MaxColorComponentValue=255; 

int bitmap[3600][3600];

int main()
{
  int clients = 5;

  // create server threads
  int i;
  for(i=0; i<clients; i++)
    create_client(i);

  /*
  int block;
  for(block=0;block<59;block++)
    do_block(block*60+0,block*60+59);
  */

  int client_num = 0;
  int block;
  for(block=0;block<59;block++)
    {
      send_request_client(client_num % 5,block*60+0,block*60+59);
      client_num++;
    }

  
  for(i=0; i<clients; i++)
    shutdown_client(i);

  for(i=0; i<clients; i++)
    pthread_join(client_attributes[i].tid,NULL);

  char *filename="new1.ppm";
  char *comment="# ";/* comment should start with # */
  /*create new file,give it a name and open it in binary mode  */
  fp= fopen(filename,"wb"); /* b -  binary mode */
  /*write ASCII header to the file*/
  fprintf(fp,"P6\n %s\n %d\n %d\n %d\n",comment,iXmax,iYmax,MaxColorComponentValue);
  /* compute and write image data bytes to the file*/
  int iX,iY;
  static unsigned char color[3];
  for(iY=0;iY<iYmax;iY++)
    for(iX=0;iX<iXmax;iX++)
      {
	if(bitmap[iY][iX] == 0)
	  {
	    color[0]=0;
	    color[1]=0;
	    color[2]=0;
	  }
	else
	  {
	    color[0]=255;
	    color[1]=255;
	    color[2]=255;
	  }
	fwrite(color,1,3,fp);
      }
  fclose(fp);
  return 0;
}

int create_client(int i)
{
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
  pthread_t tid;

  // set up attributes: self, and the pipe pairs for communication
  client_attributes[i].self = i;
  pipe(client_attributes[i].pipe_client_to_server);
  pipe(client_attributes[i].pipe_server_to_client);

  // create thread
  pthread_create(&tid,&attr,&client,(void *)&client_attributes[i].self);

  // set up to be able to poll for client communications
  poll_fds[i].fd = client_attributes[i].pipe_client_to_server[0];
  poll_fds[i].events = POLLIN;
  client_attributes[i].tid = tid;

  return(0);
}

int send_request_client(int i, int first_y, int last_y)
{
  struct message msg;
  msg.first_y = first_y;
  msg.last_y = last_y;
  write(client_attributes[i].pipe_server_to_client[1],
	&msg,
	sizeof(struct message));
  return(0);
}

int shutdown_client(int i)
{
  struct message msg;
  msg.first_y = -1;
  msg.last_y = -1;
  write(client_attributes[i].pipe_server_to_client[1],
	&msg,
	sizeof(struct message));
  return(0);
}


// int first_y,int last_y

void *client(void *id)
{
  int *my_id = (int *)id;
  struct message msg;

  while(1)
    {
      read(client_attributes[*my_id].pipe_server_to_client[0],
	   &msg,
	   sizeof(struct message));
      printf("%d: received message start = %d, end = %d\n",
	     *my_id,
	     msg.first_y,
	     msg.last_y);
      if(msg.first_y == -1)
	return(NULL);
      do_block(msg.first_y,msg.last_y);
    }
}

int do_block(int first_y,int last_y)
{

  /* screen ( integer) coordinate */
  int iX,iY;
  /* world ( double) coordinate = parameter plane*/
  double Cx,Cy;
  const double CxMin=-2.5;
  const double CxMax=1.5;
  const double CyMin=-2.0;
  const double CyMax=2.0;
  /* */
  double PixelWidth=(CxMax-CxMin)/iXmax;
  double PixelHeight=(CyMax-CyMin)/iYmax;
  /* color component ( R or G or B) is coded from 0 to 255 */
  /* it is 24 bit color RGB file */
  static unsigned char color[3];
  /* Z=Zx+Zy*i  ;   Z0 = 0 */
  double Zx, Zy;
  double Zx2, Zy2; /* Zx2=Zx*Zx;  Zy2=Zy*Zy  */
  /*  */
  int Iteration;
  const int IterationMax=200;
  /* bail-out value , radius of circle ;  */
  const double EscapeRadius=2;
  double ER2=EscapeRadius*EscapeRadius;

  for(iY=first_y;iY<=last_y;iY++)
    {
      Cy=CyMin + iY*PixelHeight;
      if (fabs(Cy)< PixelHeight/2) Cy=0.0; /* Main antenna */
      for(iX=0;iX<iXmax;iX++)
	{         
	  Cx=CxMin + iX*PixelWidth;
	  /* initial value of orbit = critical point Z= 0 */
	  Zx=0.0;
	  Zy=0.0;
	  Zx2=Zx*Zx;
	  Zy2=Zy*Zy;
	  /* */
	  for (Iteration=0;Iteration<IterationMax && ((Zx2+Zy2)<ER2);Iteration++)
	    {
	      Zy=2*Zx*Zy + Cy;
	      Zx=Zx2-Zy2 +Cx;
	      Zx2=Zx*Zx;
	      Zy2=Zy*Zy;
	    };
	  /* compute  pixel color (24 bit = 3 bytes) */
	  if (Iteration==IterationMax)
	    { /*  interior of Mandelbrot set = black */
	      color[0]=0;
	      color[1]=0;
	      color[2]=0;                           
	      bitmap[iY][iX] = 0;
	    }
	  else 
	    { /* exterior of Mandelbrot set = white */
	      color[0]=255; /* Red*/
	      color[1]=255;  /* Green */ 
	      color[2]=255;/* Blue */
	      bitmap[iY][iX] = 1;
	    };
	}
    }
  return(0);
}
