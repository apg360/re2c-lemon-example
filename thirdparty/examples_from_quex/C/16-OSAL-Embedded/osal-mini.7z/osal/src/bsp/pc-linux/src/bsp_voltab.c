#include "common_types.h"
#include "osapi.h"
OS_VolumeInfo_t OS_VolumeTable [NUM_TABLE_ENTRIES] =
{
{"/ramdev0", "./ram0", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/ramdev1", "./ram1", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/ramdev2", "./ram2", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/ramdev3", "./ram3", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/ramdev4", "./ram4", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/ramdev5", "./ram5", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"/eedev0", "./eeprom1", FS_BASED, FALSE, FALSE, TRUE, "CF", "/cf", 512 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 },
{"unused", "unused", FS_BASED, TRUE, TRUE, FALSE, " ", " ", 0 }
};
