#include "osapi.h"
void OS_Application_Startup(void);
int main(int argc, char *argv[])
{
   OS_Application_Startup();
   OS_IdleLoop();
   return(EXIT_SUCCESS);
}
