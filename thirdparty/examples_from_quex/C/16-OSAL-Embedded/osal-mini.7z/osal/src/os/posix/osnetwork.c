#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include "common_types.h"
#include "osapi.h"
int32 OS_NetworkGetID (void)
{
  int host_id;
   host_id = gethostid();
   if (host_id == -1)
       return OS_ERROR;
    return (host_id);
}
int32 OS_NetworkGetHostName (char *host_name, uint32 name_len)
{
   int retval;
   uint32 return_code;
   if ( host_name == NULL)
   {
      return_code = OS_INVALID_POINTER;
   }
   else if ( name_len == 0 )
   {
      return_code = OS_ERROR;
   }
   else
   {
      retval = gethostname( host_name, name_len);
      if ( retval == -1 )
      {
         return_code = OS_ERROR;
      }
      else
      {
         return_code = OS_SUCCESS;
      }
   }
   return(return_code);
}
