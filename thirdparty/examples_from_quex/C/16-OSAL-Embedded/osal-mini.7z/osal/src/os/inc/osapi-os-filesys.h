#ifndef _osapi_filesys_
#define _osapi_filesys_ 
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#define OS_READ_ONLY 0
#define OS_WRITE_ONLY 1
#define OS_READ_WRITE 2
#define OS_SEEK_SET 0
#define OS_SEEK_CUR 1
#define OS_SEEK_END 2
#define OS_CHK_ONLY 0
#define OS_REPAIR 1
#define FS_BASED 0
#define RAM_DISK 1
#define EEPROM_DISK 2
#define ATA_DISK 3
#define NUM_TABLE_ENTRIES 14
#define OS_FS_DEV_NAME_LEN 32
#define OS_FS_PHYS_NAME_LEN 64
#define OS_FS_VOL_NAME_LEN 32
#define OS_FS_ERR_PATH_TOO_LONG (-103)
#define OS_FS_ERR_NAME_TOO_LONG (-104)
#define OS_FS_ERR_DRIVE_NOT_CREATED (-106)
#define OS_FS_ERR_DEVICE_NOT_FREE (-107)
#define OS_FS_ERR_PATH_INVALID (-108)
#define OS_FS_SUCCESS OS_SUCCESS
#define OS_FS_ERROR OS_ERROR
#define OS_FS_ERR_INVALID_POINTER OS_INVALID_POINTER
#define OS_FS_ERR_NO_FREE_FDS OS_ERR_NO_FREE_IDS
#define OS_FS_ERR_INVALID_FD OS_ERR_INVALID_ID
#define OS_FS_UNIMPLEMENTED OS_ERR_NOT_IMPLEMENTED
typedef os_err_name_t os_fs_err_name_t;
typedef struct
{
    char DeviceName [OS_FS_DEV_NAME_LEN];
    char PhysDevName [OS_FS_PHYS_NAME_LEN];
    uint32 VolumeType;
    uint8 VolatileFlag;
    uint8 FreeFlag;
    uint8 IsMounted;
    char VolumeName [OS_FS_VOL_NAME_LEN];
    char MountPoint [OS_MAX_PATH_LEN];
    uint32 BlockSize;
}OS_VolumeInfo_t;
typedef struct
{
    int32 OSfd;
    char Path[OS_MAX_PATH_LEN];
    uint32 User;
    uint8 IsValid;
}OS_FDTableEntry;
typedef struct
{
   uint32 MaxFds;
   uint32 FreeFds;
   uint32 MaxVolumes;
   uint32 FreeVolumes;
} os_fsinfo_t;
typedef struct stat os_fstat_t;
typedef DIR* os_dirp_t;
typedef struct dirent os_dirent_t;
typedef unsigned long int os_fshealth_t;
int32 OS_FS_Init(void);
int32 OS_creat (const char *path, int32 access);
int32 OS_open (const char *path, int32 access, uint32 mode);
int32 OS_close (int32 filedes);
int32 OS_read (int32 filedes, void *buffer, uint32 nbytes);
int32 OS_write (int32 filedes, void *buffer, uint32 nbytes);
int32 OS_chmod (const char *path, uint32 access);
int32 OS_stat (const char *path, os_fstat_t *filestats);
int32 OS_lseek (int32 filedes, int32 offset, uint32 whence);
int32 OS_remove (const char *path);
int32 OS_rename (const char *old_filename, const char *new_filename);
int32 OS_cp (const char *src, const char *dest);
int32 OS_mv (const char *src, const char *dest);
int32 OS_FDGetInfo (int32 filedes, OS_FDTableEntry *fd_prop);
int32 OS_FileOpenCheck(char *Filename);
int32 OS_CloseAllFiles(void);
int32 OS_CloseFileByName(char *Filename);
int32 OS_mkdir (const char *path, uint32 access);
os_dirp_t OS_opendir (const char *path);
int32 OS_closedir(os_dirp_t directory);
void OS_rewinddir(os_dirp_t directory);
os_dirent_t * OS_readdir (os_dirp_t directory);
int32 OS_rmdir (const char *path);
int32 OS_mkfs (char *address,char *devname, char *volname,
                                uint32 blocksize, uint32 numblocks);
int32 OS_mount (const char *devname, char *mountpoint);
int32 OS_initfs (char *address,char *devname, char *volname,
                                uint32 blocksize, uint32 numblocks);
int32 OS_rmfs (char *devname);
int32 OS_unmount (const char *mountpoint);
int32 OS_fsBlocksFree (const char *name);
int32 OS_fsBytesFree (const char *name, uint64 *bytes_free);
os_fshealth_t OS_chkfs (const char *name, boolean repair);
int32 OS_FS_GetPhysDriveName (char * PhysDriveName, char * MountPoint);
int32 OS_TranslatePath ( const char *VirtualPath, char *LocalPath);
int32 OS_GetFsInfo(os_fsinfo_t *filesys_info);
int32 OS_ShellOutputToFile(char* Cmd, int32 OS_fd);
#endif
