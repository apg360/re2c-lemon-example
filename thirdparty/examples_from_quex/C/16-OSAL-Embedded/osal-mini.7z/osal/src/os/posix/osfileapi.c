#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "sys/types.h"
#include "fcntl.h"
#include "unistd.h"
#include "errno.h"
#include "pthread.h"
#include "dirent.h"
#include "sys/stat.h"
#include "signal.h"
#include "common_types.h"
#include "osapi.h"
#define ERROR -1
#define OS_REDIRECTSTRSIZE 15
int32 OS_check_name_length(const char *path);
extern uint32 OS_FindCreator(void);
extern int OS_InterruptSafeLock(pthread_mutex_t *lock, sigset_t *set, sigset_t *previous);
extern void OS_InterruptSafeUnlock(pthread_mutex_t *lock, sigset_t *previous);
OS_FDTableEntry OS_FDTable[OS_MAX_NUM_OPEN_FILES];
pthread_mutex_t OS_FDTableMutex;
int32 OS_FS_Init(void)
{
    int i;
    int ret;
    for (i =0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
        OS_FDTable[i].OSfd = -1;
        strcpy(OS_FDTable[i].Path, "\0");
        OS_FDTable[i].User = 0;
        OS_FDTable[i].IsValid = FALSE;
    }
    ret = pthread_mutex_init((pthread_mutex_t *) & OS_FDTableMutex,NULL);
    if ( ret < 0 )
    {
        return(OS_ERROR);
    }
    else
    {
        return(OS_SUCCESS);
    }
}
int32 OS_creat (const char *path, int32 access)
{
    int status;
    char local_path[OS_MAX_LOCAL_PATH_LEN];
    int perm;
    mode_t mode;
    uint32 PossibleFD;
    sigset_t previous;
    sigset_t mask;
    if (path == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(path) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if (OS_check_name_length(path) != OS_FS_SUCCESS)
    {
        return OS_FS_ERR_NAME_TOO_LONG;
    }
    switch(access)
    {
        case OS_WRITE_ONLY:
            perm = O_WRONLY;
            break;
        case OS_READ_WRITE:
            perm = O_RDWR;
            break;
        default:
            return OS_FS_ERROR;
    }
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    for ( PossibleFD = 0; PossibleFD < OS_MAX_NUM_OPEN_FILES; PossibleFD++)
    {
        if( OS_FDTable[PossibleFD].IsValid == FALSE)
        {
            break;
        }
    }
    if (PossibleFD >= OS_MAX_NUM_OPEN_FILES)
    {
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return OS_FS_ERR_NO_FREE_FDS;
    }
    OS_FDTable[PossibleFD].IsValid = TRUE;
    OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
    mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH;
    status = open(local_path, perm | O_CREAT | O_TRUNC, mode);
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    if (status != ERROR)
    {
        OS_FDTable[PossibleFD].OSfd = status;
        strncpy(OS_FDTable[PossibleFD].Path, path, OS_MAX_PATH_LEN);
        OS_FDTable[PossibleFD].User = OS_FindCreator();
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return PossibleFD;
    }
    else
    {
        OS_FDTable[PossibleFD].IsValid = FALSE;
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return OS_FS_ERROR;
    }
}
int32 OS_open (const char *path, int32 access, uint32 mode)
{
    int status;
    char local_path[OS_MAX_LOCAL_PATH_LEN];
    int perm;
    uint32 PossibleFD;
    sigset_t previous;
    sigset_t mask;
    if (path == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(path) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if (OS_check_name_length(path) != OS_FS_SUCCESS)
    {
        return OS_FS_ERR_NAME_TOO_LONG;
    }
    switch(access)
    {
        case OS_READ_ONLY:
            perm = O_RDONLY;
            break;
        case OS_WRITE_ONLY:
            perm = O_WRONLY | O_CREAT;
            break;
        case OS_READ_WRITE:
            perm = O_RDWR | O_CREAT;
            break;
        default:
            return OS_FS_ERROR;
    }
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    for ( PossibleFD = 0; PossibleFD < OS_MAX_NUM_OPEN_FILES; PossibleFD++)
    {
        if( OS_FDTable[PossibleFD].IsValid == FALSE)
        {
            break;
        }
    }
    if (PossibleFD >= OS_MAX_NUM_OPEN_FILES)
    {
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return OS_FS_ERR_NO_FREE_FDS;
    }
    OS_FDTable[PossibleFD].IsValid = TRUE;
    OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
    status = open(local_path, perm, mode);
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    if (status != ERROR)
    {
        OS_FDTable[PossibleFD].OSfd = status;
        strncpy(OS_FDTable[PossibleFD].Path, path, OS_MAX_PATH_LEN);
        OS_FDTable[PossibleFD].User = OS_FindCreator();
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return PossibleFD;
    }
    else
    {
        OS_FDTable[PossibleFD].IsValid = FALSE;
        OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
        return OS_FS_ERROR;
    }
}
int32 OS_close (int32 filedes)
{
    int status;
    sigset_t previous;
    sigset_t mask;
    if (filedes < 0 || filedes >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[filedes].IsValid == FALSE)
    {
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        do
        {
            status = close ((int) OS_FDTable[filedes].OSfd);
        } while ( status == -1 && errno == EINTR );
        if (status == ERROR)
        {
            OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
            OS_FDTable[filedes].OSfd = -1;
            strcpy(OS_FDTable[filedes].Path, "\0");
            OS_FDTable[filedes].User = 0;
            OS_FDTable[filedes].IsValid = FALSE;
            OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
            return OS_FS_ERROR;
        }
        else
        {
            OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
            OS_FDTable[filedes].OSfd = -1;
            strcpy(OS_FDTable[filedes].Path, "\0");
            OS_FDTable[filedes].User = 0;
            OS_FDTable[filedes].IsValid = FALSE;
            OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
            return OS_FS_SUCCESS;
        }
    }
}
int32 OS_read (int32 filedes, void *buffer, uint32 nbytes)
{
    int32 status;
    if (buffer == NULL)
        return OS_FS_ERR_INVALID_POINTER;
    if (filedes < 0 || filedes >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[filedes].IsValid == FALSE)
    {
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        status = read (OS_FDTable[filedes].OSfd, buffer, nbytes);
        if (status == ERROR)
            return OS_FS_ERROR;
    }
    return status;
}
int32 OS_write (int32 filedes, void *buffer, uint32 nbytes)
{
    int32 status;
    if (buffer == NULL)
        return OS_FS_ERR_INVALID_POINTER;
    if (filedes < 0 || filedes >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[filedes].IsValid == FALSE)
    {
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        status = write(OS_FDTable[filedes].OSfd, buffer, nbytes );
        if (status != ERROR)
            return status;
        else
            return OS_FS_ERROR;
    }
}
int32 OS_chmod (const char *path, uint32 access)
{
    return OS_FS_UNIMPLEMENTED;
}
int32 OS_stat (const char *path, os_fstat_t *filestats)
{
    int ret_val;
    char local_path[OS_MAX_LOCAL_PATH_LEN];
    if (path == NULL || filestats == NULL)
        return OS_FS_ERR_INVALID_POINTER;
    if (strlen(path) >= OS_MAX_PATH_LEN)
        return OS_FS_ERR_PATH_TOO_LONG;
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    ret_val = stat( (char*) local_path, filestats);
    if (ret_val == ERROR)
        return OS_FS_ERROR;
    else
        return OS_FS_SUCCESS;
}
int32 OS_lseek (int32 filedes, int32 offset, uint32 whence)
{
     off_t status;
     int where;
    if (filedes < 0 || filedes >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[filedes].IsValid == FALSE)
    {
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        switch(whence)
        {
            case OS_SEEK_SET:
                where = SEEK_SET;
                break;
            case OS_SEEK_CUR:
                where = SEEK_CUR;
                break;
            case OS_SEEK_END:
                where = SEEK_END;
                break;
            default:
                return OS_FS_ERROR;
        }
        status = lseek( OS_FDTable[filedes].OSfd, (off_t) offset, (int) where );
        if ( (int) status != ERROR)
            return (int32) status;
        else
            return OS_FS_ERROR;
    }
}
int32 OS_remove (const char *path)
{
    int i;
    int status;
    char local_path[OS_MAX_LOCAL_PATH_LEN];
    if (path == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(path) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if (OS_check_name_length(path) != OS_FS_SUCCESS)
    {
        return OS_FS_ERR_NAME_TOO_LONG;
    }
    for ( i =0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
       if ((OS_FDTable[i].IsValid == TRUE) &&
          (strcmp(OS_FDTable[i].Path, path) == 0))
       {
          return OS_FS_ERROR;
       }
    }
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    status = remove (local_path);
    if (status == 0)
    {
        return OS_FS_SUCCESS;
    }
    else
    {
        return OS_FS_ERROR;
    }
}
int32 OS_rename (const char *old, const char *new)
{
    int status,i;
    char old_path[OS_MAX_LOCAL_PATH_LEN];
    char new_path[OS_MAX_LOCAL_PATH_LEN];
    if (old == NULL || new == NULL)
        return OS_FS_ERR_INVALID_POINTER;
    if (strlen(old) >= OS_MAX_PATH_LEN)
        return OS_FS_ERR_PATH_TOO_LONG;
    if (strlen(new) >= OS_MAX_PATH_LEN)
        return OS_FS_ERR_PATH_TOO_LONG;
    if (OS_check_name_length(old) != OS_FS_SUCCESS)
        return OS_FS_ERR_NAME_TOO_LONG;
    if (OS_check_name_length(new) != OS_FS_SUCCESS)
        return OS_FS_ERR_NAME_TOO_LONG;
    if ( OS_TranslatePath(old, (char *)old_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    if ( OS_TranslatePath(new, (char *)new_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    status = rename (old_path, new_path);
    if (status == 0)
    {
        for ( i =0; i < OS_MAX_NUM_OPEN_FILES; i++)
        {
            if (strcmp(OS_FDTable[i].Path, old) == 0 &&
                OS_FDTable[i].IsValid == TRUE)
            {
                strncpy (OS_FDTable[i].Path, new, OS_MAX_PATH_LEN);
            }
        }
        return OS_FS_SUCCESS;
    }
    else
    {
        return OS_FS_ERROR;
    }
}
int32 OS_cp (const char *src, const char *dest)
{
    int i;
    int status;
    char src_path[OS_MAX_LOCAL_PATH_LEN];
    char dest_path[OS_MAX_LOCAL_PATH_LEN];
    char command [OS_MAX_PATH_LEN * 2 + 5];
    if (src == NULL || dest == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(src) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if (strlen(dest) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if (OS_check_name_length(src) != OS_FS_SUCCESS)
    {
        return OS_FS_ERR_NAME_TOO_LONG;
    }
    if (OS_check_name_length(dest) != OS_FS_SUCCESS)
    {
        return OS_FS_ERR_NAME_TOO_LONG;
    }
    for ( i =0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
        if ((OS_FDTable[i].IsValid == TRUE) &&
           (strcmp(OS_FDTable[i].Path, dest) == 0))
        {
           return OS_FS_ERROR;
        }
    }
    if ( OS_TranslatePath(src, (char *)src_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    if ( OS_TranslatePath(dest, (char *)dest_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    sprintf(command,"cp %s %s",src_path, dest_path);
     status = system(command);
     if (status == 0)
     {
         return OS_FS_SUCCESS;
     }
     else
     {
         return OS_FS_ERROR;
     }
}
int32 OS_mv (const char *src, const char *dest)
{
   int i;
   int32 status;
   if (src == NULL || dest == NULL)
   {
        return OS_FS_ERR_INVALID_POINTER;
   }
   if (strlen(src) >= OS_MAX_PATH_LEN)
   {
       return OS_FS_ERR_PATH_TOO_LONG;
   }
   if (strlen(dest) >= OS_MAX_PATH_LEN)
   {
       return OS_FS_ERR_PATH_TOO_LONG;
   }
   if (OS_check_name_length(src) != OS_FS_SUCCESS)
   {
       return OS_FS_ERR_NAME_TOO_LONG;
   }
   if (OS_check_name_length(dest) != OS_FS_SUCCESS)
   {
       return OS_FS_ERR_NAME_TOO_LONG;
   }
   for ( i =0; i < OS_MAX_NUM_OPEN_FILES; i++)
   {
       if ((OS_FDTable[i].IsValid == TRUE) &&
          (strcmp(OS_FDTable[i].Path, src) == 0))
       {
          return OS_FS_ERROR;
       }
   }
   status = OS_cp (src, dest);
   if ( status == OS_FS_SUCCESS )
   {
      status = OS_remove(src);
   }
   return ( status);
}
int32 OS_mkdir (const char *path, uint32 access)
{
   int status;
   mode_t mode;
   char local_path[OS_MAX_LOCAL_PATH_LEN];
    if (path == NULL)
        return OS_FS_ERR_INVALID_POINTER;
    if (strlen(path) >= OS_MAX_PATH_LEN)
        return OS_FS_ERR_PATH_TOO_LONG;
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    mode = S_IFDIR |S_IRWXU | S_IRWXG | S_IRWXO;
    status = mkdir(local_path, mode);
    if (status == 0)
    {
        return OS_FS_SUCCESS;
    }
    else
    {
        return OS_FS_ERROR;
    }
}
os_dirp_t OS_opendir (const char *path)
{
    os_dirp_t dirdescptr;
    char local_path[OS_MAX_LOCAL_PATH_LEN];
    if (path == NULL)
    {
        return NULL;
    }
    if (strlen(path) > OS_MAX_PATH_LEN)
    {
        return NULL;
    }
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return NULL;
    }
    dirdescptr = opendir( (char*) local_path);
    if (dirdescptr == NULL)
    {
        return NULL;
    }
    else
    {
        return dirdescptr;
    }
}
int32 OS_closedir (os_dirp_t directory)
{
    int status;
    if (directory == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    status = closedir(directory);
    if (status != ERROR)
    {
        return OS_FS_SUCCESS;
    }
    else
    {
        return OS_FS_ERROR;
    }
}
os_dirent_t * OS_readdir (os_dirp_t directory)
{
    os_dirent_t *tempptr;
    if (directory == NULL)
        return NULL;
    tempptr = readdir( directory);
    if (tempptr != NULL)
    {
        return tempptr;
    }
    else
    {
        return NULL;
    }
}
void OS_rewinddir (os_dirp_t directory )
{
    if (directory != NULL)
    {
       rewinddir( directory);
    }
}
int32 OS_rmdir (const char *path)
{
    int status;
    char local_path [OS_MAX_LOCAL_PATH_LEN];
    if (path == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(path) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if ( OS_TranslatePath(path, (char *)local_path) != OS_FS_SUCCESS )
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    status = rmdir(local_path);
    if (status == 0)
    {
        return OS_FS_SUCCESS;
    }
    else
    {
        return OS_FS_ERROR;
    }
}
int32 OS_check_name_length(const char *path)
{
    char* name_ptr;
    if (path == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(path) > OS_MAX_PATH_LEN)
    {
        return OS_FS_ERROR;
    }
    name_ptr = strrchr(path, '/');
    if (name_ptr == NULL)
    {
        return OS_FS_ERROR;
    }
    name_ptr ++;
    if( strlen(name_ptr) > OS_MAX_FILE_NAME)
    {
        return OS_FS_ERROR;
    }
    return OS_FS_SUCCESS;
}
int32 OS_ShellOutputToFile(char* Cmd, int32 OS_fd)
{
    char LocalCmd [OS_MAX_CMD_LEN + OS_REDIRECTSTRSIZE];
    int32 ReturnCode;
    int32 Result;
    if (Cmd == NULL)
    {
        return(OS_FS_ERR_INVALID_POINTER);
    }
    if (OS_fd < 0 || OS_fd >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[OS_fd].IsValid == FALSE)
    {
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        snprintf(LocalCmd, sizeof LocalCmd,
                 "%s 1>&%d 2>&%d", Cmd, (int)OS_FDTable[OS_fd].OSfd, (int)OS_FDTable[OS_fd].OSfd);
        Result = system(LocalCmd);
        if (Result == 0)
        {
            ReturnCode = OS_FS_SUCCESS;
        }
        else
        {
            ReturnCode = OS_FS_ERROR;
        }
        return ReturnCode;
    }
    return OS_FS_ERROR;
}
int32 OS_FDGetInfo (int32 filedes, OS_FDTableEntry *fd_prop)
{
    if (fd_prop == NULL)
    {
        return(OS_FS_ERR_INVALID_POINTER);
    }
    if (filedes < 0 || filedes >= OS_MAX_NUM_OPEN_FILES || OS_FDTable[filedes].IsValid == FALSE)
    {
       (*(fd_prop)).IsValid = FALSE;
        return OS_FS_ERR_INVALID_FD;
    }
    else
    {
        *fd_prop = OS_FDTable[filedes];
        return OS_FS_SUCCESS;
    }
}
int32 OS_FileOpenCheck(char *Filename)
{
    uint32 i;
    sigset_t previous;
    sigset_t mask;
    if (Filename == NULL)
    {
        return(OS_FS_ERR_INVALID_POINTER);
    }
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    for ( i = 0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
        if ((OS_FDTable[i].IsValid == TRUE) && (strcmp(OS_FDTable[i].Path, Filename) == 0))
        {
           OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
           return(OS_FS_SUCCESS);
        }
    }
    OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
    return OS_FS_ERROR;
}
int32 OS_CloseFileByName(char *Filename)
{
    uint32 i;
    int status;
    sigset_t previous;
    sigset_t mask;
    if (Filename == NULL)
    {
        return(OS_FS_ERR_INVALID_POINTER);
    }
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    for ( i = 0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
        if ((OS_FDTable[i].IsValid == TRUE) && (strcmp(OS_FDTable[i].Path, Filename) == 0))
        {
           status = close ((int) OS_FDTable[i].OSfd);
           OS_FDTable[i].OSfd = -1;
           strcpy(OS_FDTable[i].Path, "\0");
           OS_FDTable[i].User = 0;
           OS_FDTable[i].IsValid = FALSE;
           OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
           if (status == 0)
           {
              return(OS_FS_SUCCESS);
           }
           else
           {
              return(OS_FS_ERROR);
           }
        }
    }
    OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
    return (OS_FS_ERR_PATH_INVALID);
}
int32 OS_CloseAllFiles(void)
{
    uint32 i;
    int32 return_status = OS_FS_SUCCESS;
    int status;
    sigset_t previous;
    sigset_t mask;
    OS_InterruptSafeLock(&OS_FDTableMutex, &mask, &previous);
    for ( i = 0; i < OS_MAX_NUM_OPEN_FILES; i++)
    {
        if ( OS_FDTable[i].IsValid == TRUE )
        {
           status = close ((int) OS_FDTable[i].OSfd);
           OS_FDTable[i].OSfd = -1;
           strcpy(OS_FDTable[i].Path, "\0");
           OS_FDTable[i].User = 0;
           OS_FDTable[i].IsValid = FALSE;
           if (status == ERROR)
           {
              return_status = OS_FS_ERROR;
           }
        }
    }
    OS_InterruptSafeUnlock(&OS_FDTableMutex, &previous);
    return (return_status);
}
