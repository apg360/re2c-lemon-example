#include "common_types.h"
#include "osapi.h"
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <sys/signal.h>
#include <sys/errno.h>
#include <pthread.h>
extern uint32 OS_FindCreator(void);
extern int OS_InterruptSafeLock(pthread_mutex_t *lock, sigset_t *set, sigset_t *previous);
extern void OS_InterruptSafeUnlock(pthread_mutex_t *lock, sigset_t *previous);
void OS_TimespecToUsec(struct timespec time_spec, uint32 *usecs);
void OS_UsecToTimespec(uint32 usecs, struct timespec *time_spec);
#define OS_STARTING_SIGNAL (SIGRTMAX-1)
#define MAX_SECS_IN_USEC 4293
#define UNINITIALIZED 0
typedef struct
{
   uint32 free;
   char name[OS_MAX_API_NAME];
   uint32 creator;
   uint32 start_time;
   uint32 interval_time;
   uint32 accuracy;
   OS_TimerCallback_t callback_ptr;
   timer_t host_timerid;
} OS_timer_internal_record_t;
OS_timer_internal_record_t OS_timer_table[OS_MAX_TIMERS];
uint32 os_clock_accuracy;
pthread_mutex_t OS_timer_table_mut;
int32 OS_TimerAPIInit ( void )
{
   int i;
   int status;
   struct timespec clock_resolution;
   int32 return_code = OS_SUCCESS;
   for ( i = 0; i < OS_MAX_TIMERS; i++ )
   {
      OS_timer_table[i].free = TRUE;
      OS_timer_table[i].creator = UNINITIALIZED;
      strcpy(OS_timer_table[i].name,"");
   }
   status = clock_getres(CLOCK_REALTIME, &clock_resolution);
   if ( status < 0 )
   {
      return_code = OS_ERROR;
   }
   else
   {
      OS_TimespecToUsec(clock_resolution, &os_clock_accuracy);
      status = pthread_mutex_init((pthread_mutex_t *) & OS_timer_table_mut,NULL);
      if ( status < 0 )
      {
         return_code = OS_ERROR;
      }
   }
   return(return_code);
}
void OS_TimerSignalHandler(int signum)
{
   uint32 timer_id;
   timer_id = OS_STARTING_SIGNAL - signum;
   if ( timer_id < OS_MAX_TIMERS )
   {
      if ( OS_timer_table[timer_id].free == FALSE )
      {
         (OS_timer_table[timer_id].callback_ptr)(timer_id);
      }
   }
}
void OS_UsecToTimespec(uint32 usecs, struct timespec *time_spec)
{
   if ( usecs < 1000000 )
   {
      time_spec->tv_nsec = (usecs * 1000);
      time_spec->tv_sec = 0;
   }
   else
   {
      time_spec->tv_sec = usecs / 1000000;
      time_spec->tv_nsec = (usecs % 1000000) * 1000;
   }
}
void OS_TimespecToUsec(struct timespec time_spec, uint32 *usecs)
{
   if ( time_spec.tv_sec > MAX_SECS_IN_USEC )
   {
      time_spec.tv_sec = MAX_SECS_IN_USEC;
   }
   *usecs = (time_spec.tv_sec * 1000000 ) + (time_spec.tv_nsec / 1000 );
}
int32 OS_TimerCreate(uint32 *timer_id, const char *timer_name, uint32 *clock_accuracy, OS_TimerCallback_t callback_ptr)
{
   uint32 possible_tid;
   int32 i;
   sigset_t previous;
   sigset_t mask;
   int status;
   struct sigaction sig_act;
   struct sigevent evp;
   if ( timer_id == NULL || timer_name == NULL || clock_accuracy == NULL)
   {
        return OS_INVALID_POINTER;
   }
   if (strlen(timer_name) > OS_MAX_API_NAME)
   {
      return OS_ERR_NAME_TOO_LONG;
   }
   OS_InterruptSafeLock(&OS_timer_table_mut, &mask, &previous);
   for(possible_tid = 0; possible_tid < OS_MAX_TIMERS; possible_tid++)
   {
      if (OS_timer_table[possible_tid].free == TRUE)
         break;
   }
   if( possible_tid >= OS_MAX_TIMERS || OS_timer_table[possible_tid].free != TRUE)
   {
        OS_InterruptSafeUnlock(&OS_timer_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
   }
   for (i = 0; i < OS_MAX_TIMERS; i++)
   {
       if ((OS_timer_table[i].free == FALSE) &&
            strcmp ((char*) timer_name, OS_timer_table[i].name) == 0)
       {
            OS_InterruptSafeUnlock(&OS_timer_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
       }
   }
   if (callback_ptr == NULL )
   {
      OS_InterruptSafeUnlock(&OS_timer_table_mut, &previous);
      return OS_TIMER_ERR_INVALID_ARGS;
   }
   OS_timer_table[possible_tid].free = FALSE;
   OS_InterruptSafeUnlock(&OS_timer_table_mut, &previous);
   OS_timer_table[possible_tid].creator = OS_FindCreator();
   strncpy(OS_timer_table[possible_tid].name, timer_name, OS_MAX_API_NAME);
   OS_timer_table[possible_tid].start_time = 0;
   OS_timer_table[possible_tid].interval_time = 0;
   OS_timer_table[possible_tid].callback_ptr = callback_ptr;
   memset((void *)&sig_act, 0, sizeof(sig_act));
   sigemptyset(&sig_act.sa_mask);
   sig_act.sa_handler = OS_TimerSignalHandler;
   sig_act.sa_flags = SA_RESTART;
   memset((void *)&evp, 0, sizeof(evp));
   evp.sigev_notify = SIGEV_SIGNAL;
   evp.sigev_signo = OS_STARTING_SIGNAL - possible_tid;
   status = timer_create(CLOCK_REALTIME, &evp, (timer_t *)&(OS_timer_table[possible_tid].host_timerid));
   if (status < 0)
   {
      OS_timer_table[possible_tid].free = TRUE;
      return ( OS_TIMER_ERR_UNAVAILABLE);
   }
   sigaction(OS_STARTING_SIGNAL - possible_tid, &(sig_act), 0);
   *clock_accuracy = os_clock_accuracy;
   *timer_id = possible_tid;
   return OS_SUCCESS;
}
int32 OS_TimerSet(uint32 timer_id, uint32 start_time, uint32 interval_time)
{
   int status;
   struct itimerspec timeout;
   if (timer_id >= OS_MAX_TIMERS || OS_timer_table[timer_id].free == TRUE)
   {
      return OS_ERR_INVALID_ID;
   }
   if (( start_time > 0 ) && ( start_time < os_clock_accuracy ))
   {
      start_time = os_clock_accuracy;
   }
   if (( interval_time > 0) && ( interval_time < os_clock_accuracy ))
   {
      interval_time = os_clock_accuracy;
   }
   OS_timer_table[timer_id].start_time = start_time;
   OS_timer_table[timer_id].interval_time = interval_time;
   OS_UsecToTimespec(start_time, &(timeout.it_value));
   OS_UsecToTimespec(interval_time, &(timeout.it_interval));
   status = timer_settime((timer_t)(OS_timer_table[timer_id].host_timerid),
                             0,
                             &timeout,
               NULL);
   if (status < 0)
   {
      return ( OS_TIMER_ERR_INTERNAL);
   }
   return OS_SUCCESS;
}
int32 OS_TimerDelete(uint32 timer_id)
{
   int status;
   if (timer_id >= OS_MAX_TIMERS || OS_timer_table[timer_id].free == TRUE)
   {
      return OS_ERR_INVALID_ID;
   }
   status = timer_delete((timer_t)(OS_timer_table[timer_id].host_timerid));
   OS_timer_table[timer_id].free = TRUE;
   if (status < 0)
   {
      return ( OS_TIMER_ERR_INTERNAL);
   }
   return OS_SUCCESS;
}
int32 OS_TimerGetIdByName (uint32 *timer_id, const char *timer_name)
{
    uint32 i;
    if (timer_id == NULL || timer_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(timer_name) > OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_TIMERS; i++)
    {
        if (OS_timer_table[i].free != TRUE &&
                (strcmp (OS_timer_table[i].name , (char*) timer_name) == 0))
        {
            *timer_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_TimerGetInfo (uint32 timer_id, OS_timer_prop_t *timer_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (timer_id >= OS_MAX_TIMERS || OS_timer_table[timer_id].free == TRUE)
    {
       return OS_ERR_INVALID_ID;
    }
    if (timer_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    OS_InterruptSafeLock(&OS_timer_table_mut, &mask, &previous);
    timer_prop ->creator = OS_timer_table[timer_id].creator;
    strcpy(timer_prop-> name, OS_timer_table[timer_id].name);
    timer_prop ->start_time = OS_timer_table[timer_id].start_time;
    timer_prop ->interval_time = OS_timer_table[timer_id].interval_time;
    timer_prop ->accuracy = OS_timer_table[timer_id].accuracy;
    OS_InterruptSafeUnlock(&OS_timer_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_TimeBaseCreate(uint32 *timer_id, const char *timebase_name, OS_TimerSync_t external_sync)
{
    return OS_ERR_NOT_IMPLEMENTED;
}
int32 OS_TimeBaseSet(uint32 timer_id, uint32 start_time, uint32 interval_time)
{
    return OS_ERR_NOT_IMPLEMENTED;
}
int32 OS_TimeBaseDelete(uint32 timer_id)
{
    return OS_ERR_NOT_IMPLEMENTED;
}
int32 OS_TimeBaseGetIdByName (uint32 *timer_id, const char *timebase_name)
{
    return OS_ERR_NOT_IMPLEMENTED;
}
int32 OS_TimerAdd(uint32 *timer_id, const char *timer_name, uint32 timebase_id, OS_ArgCallback_t callback_ptr, void *callback_arg)
{
    return OS_ERR_NOT_IMPLEMENTED;
}
