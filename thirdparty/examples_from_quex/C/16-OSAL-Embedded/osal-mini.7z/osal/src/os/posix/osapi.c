#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>
#include <unistd.h>
#include <semaphore.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#ifndef __USE_UNIX98
#define __USE_UNIX98 
#endif
#include <pthread.h>
#include "common_types.h"
#include "osapi.h"
#ifndef OSAL_SOCKET_QUEUE
#include <mqueue.h>
#endif
#define OS_BASE_PORT 43000
#define UNINITIALIZED 0
#define MAX_PRIORITY 255
#ifndef PTHREAD_STACK_MIN
   #define PTHREAD_STACK_MIN 8092
#endif
#undef OS_DEBUG_PRINTF
#define OS_SHUTDOWN_MAGIC_NUMBER 0xABADC0DE
typedef struct
{
    int free;
    pthread_t id;
    char name [OS_MAX_API_NAME];
    int creator;
    uint32 stack_size;
    uint32 priority;
    osal_task_entry delete_hook_pointer;
}OS_task_internal_record_t;
#ifdef OSAL_SOCKET_QUEUE
typedef struct
{
    int free;
    int id;
    uint32 max_size;
    char name [OS_MAX_API_NAME];
    int creator;
}OS_queue_internal_record_t;
#else
typedef struct
{
    int free;
    mqd_t id;
    uint32 max_size;
    char name [OS_MAX_API_NAME];
    int creator;
}OS_queue_internal_record_t;
#endif
typedef struct
{
    int free;
    pthread_mutex_t id;
    pthread_cond_t cv;
    char name [OS_MAX_API_NAME];
    int creator;
    int max_value;
    int current_value;
}OS_bin_sem_internal_record_t;
typedef struct
{
    int free;
    pthread_mutex_t id;
    pthread_cond_t cv;
    char name [OS_MAX_API_NAME];
    int creator;
    int max_value;
    int current_value;
}OS_count_sem_internal_record_t;
typedef struct
{
    int free;
    pthread_mutex_t id;
    char name [OS_MAX_API_NAME];
    int creator;
}OS_mut_sem_internal_record_t;
typedef void (*FuncPtr_t)(void);
OS_task_internal_record_t OS_task_table [OS_MAX_TASKS];
OS_queue_internal_record_t OS_queue_table [OS_MAX_QUEUES];
OS_bin_sem_internal_record_t OS_bin_sem_table [OS_MAX_BIN_SEMAPHORES];
OS_count_sem_internal_record_t OS_count_sem_table [OS_MAX_COUNT_SEMAPHORES];
OS_mut_sem_internal_record_t OS_mut_sem_table [OS_MAX_MUTEXES];
pthread_key_t thread_key;
pthread_mutex_t OS_task_table_mut;
pthread_mutex_t OS_queue_table_mut;
pthread_mutex_t OS_bin_sem_table_mut;
pthread_mutex_t OS_mut_sem_table_mut;
pthread_mutex_t OS_count_sem_table_mut;
uint32 OS_printf_enabled = TRUE;
volatile uint32 OS_shutdown = FALSE;
void OS_CompAbsDelayTime( uint32 milli_second , struct timespec * tm);
void OS_ThreadKillHandler(int sig );
uint32 OS_FindCreator(void);
int32 OS_PriorityRemap(uint32 InputPri);
int OS_InterruptSafeLock(pthread_mutex_t *lock, sigset_t *set, sigset_t *previous);
void OS_InterruptSafeUnlock(pthread_mutex_t *lock, sigset_t *previous);
static void OS_NoopSigHandler (int signal)
{
}
int32 OS_API_Init(void)
{
   int i;
   int ret;
   pthread_mutexattr_t mutex_attr ;
   int32 return_code = OS_SUCCESS;
   struct sched_param param;
   int sched_policy;
   sigset_t mask;
   sigfillset(&mask);
   sigdelset(&mask, SIGINT);
   sigdelset(&mask, SIGABRT);
   sigdelset(&mask, SIGSEGV);
   sigdelset(&mask, SIGILL);
   sigdelset(&mask, SIGBUS);
   sigdelset(&mask, SIGFPE);
   sigprocmask(SIG_SETMASK, &mask, NULL);
   signal(SIGHUP, OS_NoopSigHandler);
   for(i = 0; i < OS_MAX_TASKS; i++)
   {
        OS_task_table[i].free = TRUE;
        OS_task_table[i].creator = UNINITIALIZED;
        OS_task_table[i].delete_hook_pointer = NULL;
        strcpy(OS_task_table[i].name,"");
    }
    for(i = 0; i < OS_MAX_QUEUES; i++)
    {
        OS_queue_table[i].free = TRUE;
        OS_queue_table[i].id = UNINITIALIZED;
        OS_queue_table[i].creator = UNINITIALIZED;
        strcpy(OS_queue_table[i].name,"");
    }
    for(i = 0; i < OS_MAX_BIN_SEMAPHORES; i++)
    {
        OS_bin_sem_table[i].free = TRUE;
        OS_bin_sem_table[i].creator = UNINITIALIZED;
        strcpy(OS_bin_sem_table[i].name,"");
    }
    for(i = 0; i < OS_MAX_COUNT_SEMAPHORES; i++)
    {
        OS_count_sem_table[i].free = TRUE;
        OS_count_sem_table[i].creator = UNINITIALIZED;
        strcpy(OS_count_sem_table[i].name,"");
    }
    for(i = 0; i < OS_MAX_MUTEXES; i++)
    {
        OS_mut_sem_table[i].free = TRUE;
        OS_mut_sem_table[i].creator = UNINITIALIZED;
        strcpy(OS_mut_sem_table[i].name,"");
    }
   #ifdef OS_INCLUDE_MODULE_LOADER
      return_code = OS_ModuleTableInit();
      if ( return_code == OS_ERROR )
      {
         return(return_code);
      }
   #endif
   return_code = OS_TimerAPIInit();
   if ( return_code == OS_ERROR )
   {
      return(return_code);
   }
   ret = pthread_key_create(&thread_key, NULL );
   if ( ret != 0 )
   {
      #ifdef OS_DEBUG_PRINTF
        printf("Error creating thread key\n");
      #endif
      return_code = OS_ERROR;
      return(return_code);
   }
   return_code = pthread_mutexattr_init(&mutex_attr);
   if ( return_code != 0 )
   {
      #ifdef OS_DEBUG_PRINTF
         printf("Error: pthread_mutexattr_init failed\n");
      #endif
      return_code = OS_ERROR;
      return (return_code);
   }
   return_code = pthread_mutexattr_setprotocol(&mutex_attr,PTHREAD_PRIO_INHERIT) ;
   if ( return_code != 0 )
   {
      #ifdef OS_DEBUG_PRINTF
         printf("Error: pthread_mutexattr_setprotocol failed\n");
      #endif
      return_code = OS_ERROR;
      return (return_code);
   }
   return_code = pthread_mutexattr_settype(&mutex_attr, PTHREAD_MUTEX_RECURSIVE);
   if ( return_code != 0 )
   {
      #ifdef OS_DEBUG_PRINTF
         printf("Error: pthread_mutexattr_settype failed\n");
      #endif
      return_code = OS_ERROR;
      return (return_code);
   }
   ret = pthread_mutex_init((pthread_mutex_t *) & OS_task_table_mut,&mutex_attr);
   if ( ret != 0 )
   {
      return_code = OS_ERROR;
      return(return_code);
   }
   ret = pthread_mutex_init((pthread_mutex_t *) & OS_queue_table_mut,&mutex_attr);
   if ( ret != 0 )
   {
      return_code = OS_ERROR;
      return(return_code);
   }
   ret = pthread_mutex_init((pthread_mutex_t *) & OS_bin_sem_table_mut,&mutex_attr);
   if ( ret != 0 )
   {
      return_code = OS_ERROR;
      return(return_code);
   }
   ret = pthread_mutex_init((pthread_mutex_t *) & OS_count_sem_table_mut,&mutex_attr);
   if ( ret != 0 )
   {
      return_code = OS_ERROR;
      return(return_code);
   }
   ret = pthread_mutex_init((pthread_mutex_t *) & OS_mut_sem_table_mut,&mutex_attr);
   if ( ret != 0 )
   {
      return_code = OS_ERROR;
      return(return_code);
   }
   return_code = OS_FS_Init();
   ret = pthread_getschedparam(pthread_self(), &sched_policy, &param);
   if (ret == 0)
   {
      sched_policy = SCHED_FIFO;
      param.sched_priority = 0;
      ret = pthread_setschedparam(pthread_self(), sched_policy, &param);
      if (ret != 0)
      {
#ifdef OS_DEBUG_PRINTF
         printf("OS_API_Init: Could not set scheduleparam in main thread, error=%d\n",ret);
#endif
      }
   }
   else
   {
#ifdef OS_DEBUG_PRINTF
      printf("OS_API_Init: Could not get scheduleparam in main thread, error=%d\n",ret);
#endif
   }
   return_code = OS_SUCCESS;
   return(return_code);
}
void OS_ApplicationExit(int32 Status)
{
   if (Status == OS_SUCCESS)
   {
      exit(EXIT_SUCCESS);
   }
   else
   {
      exit(EXIT_FAILURE);
   }
}
void OS_DeleteAllObjects (void)
{
    uint32 i;
    for (i = 0; i < OS_MAX_TASKS; ++i)
    {
        OS_TaskDelete(i);
    }
    for (i = 0; i < OS_MAX_QUEUES; ++i)
    {
        OS_QueueDelete(i);
    }
    for (i = 0; i < OS_MAX_MUTEXES; ++i)
    {
        OS_MutSemDelete(i);
    }
    for (i = 0; i < OS_MAX_COUNT_SEMAPHORES; ++i)
    {
        OS_CountSemDelete(i);
    }
    for (i = 0; i < OS_MAX_BIN_SEMAPHORES; ++i)
    {
        OS_BinSemDelete(i);
    }
    for (i = 0; i < OS_MAX_TIMERS; ++i)
    {
        OS_TimerDelete(i);
    }
    for (i = 0; i < OS_MAX_MODULES; ++i)
    {
        OS_ModuleUnload(i);
    }
    for (i = 0; i < OS_MAX_NUM_OPEN_FILES; ++i)
    {
        OS_close(i);
    }
}
void OS_IdleLoop()
{
   sigset_t mask;
   sigemptyset(&mask);

   while (OS_shutdown != OS_SHUTDOWN_MAGIC_NUMBER)
   {
      /* Unblock signals and wait for something to occur */
      sigsuspend(&mask);
   }
}
void OS_ApplicationShutdown(uint8 flag)
{
   if (flag == TRUE)
   {
      OS_shutdown = OS_SHUTDOWN_MAGIC_NUMBER;
   }
   kill(getpid(), SIGHUP);
}
int32 OS_TaskCreate (uint32 *task_id, const char *task_name, osal_task_entry function_pointer,
                      uint32 *stack_pointer, uint32 stack_size, uint32 priority,
                      uint32 flags)
{
    int return_code = 0;
    pthread_attr_t custom_attr ;
    struct sched_param priority_holder ;
    int possible_taskid;
    int i;
    uint32 local_stack_size;
    int ret;
    int os_priority;
    int inheritsched;
    sigset_t previous;
    sigset_t mask;
    if( (task_name == NULL) || (function_pointer == NULL) || (task_id == NULL) )
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(task_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    if (priority > MAX_PRIORITY)
    {
        return OS_ERR_INVALID_PRIORITY;
    }
    os_priority = OS_PriorityRemap(priority);
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    for(possible_taskid = 0; possible_taskid < OS_MAX_TASKS; possible_taskid++)
    {
        if (OS_task_table[possible_taskid].free == TRUE)
        {
            break;
        }
    }
    if( possible_taskid >= OS_MAX_TASKS || OS_task_table[possible_taskid].free != TRUE)
    {
        OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_TASKS; i++)
    {
        if ((OS_task_table[i].free == FALSE) &&
           ( strcmp((char*) task_name, OS_task_table[i].name) == 0))
        {
            OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    OS_task_table[possible_taskid].free = FALSE;
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    if ( stack_size < PTHREAD_STACK_MIN )
    {
       local_stack_size = PTHREAD_STACK_MIN;
    }
    else
    {
        local_stack_size = stack_size;
    }
    memset(&custom_attr, 0, sizeof(custom_attr));
    if(pthread_attr_init(&custom_attr))
    {
        OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
        OS_task_table[possible_taskid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("pthread_attr_init error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
    perror("pthread_attr_init");
        #endif
        return(OS_ERROR);
    }
    if (geteuid() == 0 )
    {
       inheritsched = PTHREAD_EXPLICIT_SCHED;
       return_code = pthread_attr_setinheritsched(&custom_attr, inheritsched);
       if ( return_code < 0 )
       {
           #ifdef OS_DEBUG_PRINTF
               printf("pthread_attr_setinheritsched error in OS_TaskCreate, Task ID = %d, errno = %s\n",
                      possible_taskid,strerror(errno));
           #endif
           return(OS_ERROR);
       }
       if (pthread_attr_setstacksize(&custom_attr, (size_t)local_stack_size ))
       {
          #ifdef OS_DEBUG_PRINTF
             printf("pthread_attr_setstacksize error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
          #endif
          return(OS_ERROR);
       }
       if (pthread_attr_setschedpolicy(&custom_attr, SCHED_FIFO))
       {
          #ifdef OS_DEBUG_PRINTF
             printf("pthread_attr_setschedpolity error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
          #endif
          return(OS_ERROR);
       }
       memset(&priority_holder, 0, sizeof(priority_holder));
       priority_holder.sched_priority = os_priority;
       ret = pthread_attr_setschedparam(&custom_attr,&priority_holder);
       if(ret !=0)
       {
          #ifdef OS_DEBUG_PRINTF
             printf("pthread_attr_setschedparam error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
          #endif
          return(OS_ERROR);
       }
    }
    return_code = pthread_create(&(OS_task_table[possible_taskid].id),
                                 &custom_attr,
                                 (void*(*)(void*))function_pointer,
                                 (void *)0);
    if (return_code != 0)
    {
        OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
        OS_task_table[possible_taskid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("pthread_create error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
        #endif
        return(OS_ERROR);
    }
    return_code = pthread_detach(OS_task_table[possible_taskid].id);
    if (return_code !=0)
    {
       OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
       OS_task_table[possible_taskid].free = TRUE;
       OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
       #ifdef OS_DEBUG_PRINTF
         printf("pthread_detach error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
       #endif
       return(OS_ERROR);
    }
    return_code = pthread_attr_destroy(&custom_attr);
    if (return_code !=0)
    {
       OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
       OS_task_table[possible_taskid].free = TRUE;
       OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
       #ifdef OS_DEBUG_PRINTF
          printf("pthread_attr_destroy error in OS_TaskCreate, Task ID = %d\n",possible_taskid);
       #endif
       return(OS_ERROR);
    }
    *task_id = possible_taskid;
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    OS_task_table[possible_taskid].free = FALSE;
    strcpy(OS_task_table[*task_id].name, (char*) task_name);
    OS_task_table[possible_taskid].creator = OS_FindCreator();
    OS_task_table[possible_taskid].stack_size = stack_size;
    OS_task_table[possible_taskid].priority = priority;
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_TaskDelete (uint32 task_id)
{
    int ret;
    FuncPtr_t FunctionPointer;
    sigset_t previous;
    sigset_t mask;
    if (task_id >= OS_MAX_TASKS || OS_task_table[task_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if ( OS_task_table[task_id].delete_hook_pointer != NULL)
    {
       FunctionPointer = (FuncPtr_t)(OS_task_table[task_id].delete_hook_pointer);
       (*FunctionPointer)();
    }
    ret = pthread_cancel(OS_task_table[task_id].id);
    if (ret != 0)
    {
        #ifdef OS_DEBUG_PRINTF
           printf("FAILED PTHREAD CANCEL %d, %d \n",ret, ESRCH);
        #endif
        return OS_ERROR;
    }
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    OS_task_table[task_id].free = TRUE;
    strcpy(OS_task_table[task_id].name, "");
    OS_task_table[task_id].creator = UNINITIALIZED;
    OS_task_table[task_id].stack_size = UNINITIALIZED;
    OS_task_table[task_id].priority = UNINITIALIZED;
    OS_task_table[task_id].id = UNINITIALIZED;
    OS_task_table[task_id].delete_hook_pointer = NULL;
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    return OS_SUCCESS;
}
void OS_TaskExit()
{
    uint32 task_id;
    sigset_t previous;
    sigset_t mask;
    task_id = OS_TaskGetId();
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    OS_task_table[task_id].free = TRUE;
    strcpy(OS_task_table[task_id].name, "");
    OS_task_table[task_id].creator = UNINITIALIZED;
    OS_task_table[task_id].stack_size = UNINITIALIZED;
    OS_task_table[task_id].priority = UNINITIALIZED;
    OS_task_table[task_id].id = UNINITIALIZED;
    OS_task_table[task_id].delete_hook_pointer = NULL;
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    /* pthread_exit(NULL); */
}
void OS_TaskExitAndShutdown()
    /* (C) Frank-Rene Schaefer; License, see rest of OSAL; */
{
    uint32 task_id;
    sigset_t previous;
    sigset_t mask;
    task_id = OS_TaskGetId();

    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    OS_task_table[task_id].free = TRUE;
    strcpy(OS_task_table[task_id].name, "");
    OS_task_table[task_id].creator = UNINITIALIZED;
    OS_task_table[task_id].stack_size = UNINITIALIZED;
    OS_task_table[task_id].priority = UNINITIALIZED;
    OS_task_table[task_id].id = UNINITIALIZED;
    OS_task_table[task_id].delete_hook_pointer = NULL;

    OS_shutdown = OS_SHUTDOWN_MAGIC_NUMBER;

    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);

    kill(getpid(), SIGHUP); /* => awake OS_IdleLoop() from sigsuspend() */
    /* pthread_exit(NULL); */
}

int32 OS_TaskDelay(uint32 millisecond )
{
    struct timespec waittime;
    uint32 ms = millisecond;
    int sleepstat;
    waittime.tv_sec = ms / 1000;
    waittime.tv_nsec = (ms % 1000) * 1000000;
    do
    {
       sleepstat = nanosleep(&waittime, &waittime);
    }
    while( sleepstat == -1 && errno == EINTR );
    if ( sleepstat == -1 )
    {
       return(OS_ERROR);
    }
    else
    {
       return OS_SUCCESS;
    }
}
int32 OS_TaskSetPriority (uint32 task_id, uint32 new_priority)
{
    int os_priority;
    int ret;
    if(task_id >= OS_MAX_TASKS || OS_task_table[task_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if (new_priority > MAX_PRIORITY)
    {
        return OS_ERR_INVALID_PRIORITY;
    }
    os_priority = OS_PriorityRemap(new_priority);
    if (geteuid() == 0 )
    {
       ret = pthread_setschedprio(OS_task_table[task_id].id, os_priority);
       if( ret != 0 )
       {
          #ifdef OS_DEBUG_PRINTF
             printf("pthread_setschedprio err in OS_TaskSetPriority, Task ID = %lu, prio = %d, errno = %s\n",
                        task_id,os_priority ,strerror(errno));
          #endif
          return(OS_ERROR);
       }
    }
    OS_task_table[task_id].priority = new_priority;
   return OS_SUCCESS;
}
int32 OS_TaskRegister (void)
{
    int i;
    int ret;
    uint32 task_id;
    pthread_t pthread_id;
    pthread_id = pthread_self();
    for(i = 0; i < OS_MAX_TASKS; i++)
    {
       if(OS_task_table[i].id == pthread_id)
       {
          break;
       }
    }
    task_id = i;
    if(task_id == OS_MAX_TASKS)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = pthread_setspecific(thread_key, (void *)task_id);
    if ( ret != 0 )
    {
       #ifdef OS_DEBUG_PRINTF
          printf("OS_TaskRegister Failed during pthread_setspecific function\n");
       #endif
       return(OS_ERROR);
    }
    return OS_SUCCESS;
}
uint32 OS_TaskGetId (void)
{
   void* task_id;
   int task_id_int;
   uint32 task_key;
   task_key = 0;
   task_id = (void *)pthread_getspecific(thread_key);
   memcpy(& task_id_int,&task_id, sizeof(uint32));
   task_key = task_id_int & 0xFFFF;
   return(task_key);
}
int32 OS_TaskGetIdByName (uint32 *task_id, const char *task_name)
{
    uint32 i;
    if (task_id == NULL || task_name == NULL)
    {
       return OS_INVALID_POINTER;
    }
    if (strlen(task_name) >= OS_MAX_API_NAME)
    {
       return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_TASKS; i++)
    {
        if((OS_task_table[i].free != TRUE) &&
                (strcmp(OS_task_table[i].name,(char*) task_name) == 0 ))
        {
            *task_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_TaskGetInfo (uint32 task_id, OS_task_prop_t *task_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (task_id >= OS_MAX_TASKS || OS_task_table[task_id].free == TRUE)
    {
       return OS_ERR_INVALID_ID;
    }
    if( task_prop == NULL)
    {
       return OS_INVALID_POINTER;
    }
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    task_prop -> creator = OS_task_table[task_id].creator;
    task_prop -> stack_size = OS_task_table[task_id].stack_size;
    task_prop -> priority = OS_task_table[task_id].priority;
    task_prop -> OStask_id = (uint32) OS_task_table[task_id].id;
    strcpy(task_prop-> name, OS_task_table[task_id].name);
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_TaskInstallDeleteHandler(osal_task_entry function_pointer)
{
    uint32 task_id;
    sigset_t previous;
    sigset_t mask;
    task_id = OS_TaskGetId();
    if ( task_id >= OS_MAX_TASKS )
    {
       return(OS_ERR_INVALID_ID);
    }
    OS_InterruptSafeLock(&OS_task_table_mut, &mask, &previous);
    if ( OS_task_table[task_id].free != FALSE )
    {
       OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
       return(OS_ERR_INVALID_ID);
    }
    OS_task_table[task_id].delete_hook_pointer = function_pointer;
    OS_InterruptSafeUnlock(&OS_task_table_mut, &previous);
    return(OS_SUCCESS);
}
#ifdef OSAL_SOCKET_QUEUE
int32 OS_QueueCreate (uint32 *queue_id, const char *queue_name, uint32 queue_depth,
                       uint32 data_size, uint32 flags)
{
    int tmpSkt;
    int returnStat;
    struct sockaddr_in servaddr;
    int i;
    uint32 possible_qid;
    sigset_t previous;
    sigset_t mask;
    if ( queue_id == NULL || queue_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(queue_name) >= OS_MAX_API_NAME)
    {
       return OS_ERR_NAME_TOO_LONG;
    }
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    for(possible_qid = 0; possible_qid < OS_MAX_QUEUES; possible_qid++)
    {
        if (OS_queue_table[possible_qid].free == TRUE)
            break;
    }
    if( possible_qid >= OS_MAX_QUEUES || OS_queue_table[possible_qid].free != TRUE)
    {
        OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_QUEUES; i++)
    {
        if ((OS_queue_table[i].free == FALSE) &&
                strcmp ((char*) queue_name, OS_queue_table[i].name) == 0)
        {
            OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    OS_queue_table[possible_qid].free = FALSE;
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
    tmpSkt = socket(AF_INET, SOCK_DGRAM, 0);
    if ( tmpSkt == -1 )
    {
        OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
        OS_queue_table[possible_qid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("Failed to create a socket on OS_QueueCreate. errno = %d\n",errno);
        #endif
        return OS_ERROR;
    }
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(OS_BASE_PORT + possible_qid);
    servaddr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
   returnStat = bind(tmpSkt,(struct sockaddr *)&servaddr, sizeof(servaddr));
   if ( returnStat == -1 )
   {
        OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
        OS_queue_table[possible_qid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("bind failed on OS_QueueCreate. errno = %d\n",errno);
        #endif
        return OS_ERROR;
   }
   *queue_id = possible_qid;
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    OS_queue_table[*queue_id].id = tmpSkt;
    OS_queue_table[*queue_id].free = FALSE;
    OS_queue_table[*queue_id].max_size = data_size;
    strcpy( OS_queue_table[*queue_id].name, (char*) queue_name);
    OS_queue_table[*queue_id].creator = OS_FindCreator();
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
   return OS_SUCCESS;
}
int32 OS_QueueDelete (uint32 queue_id)
{
    sigset_t previous;
    sigset_t mask;
    if (queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if(close(OS_queue_table[queue_id].id) !=0)
    {
        return OS_ERROR;
    }
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    OS_queue_table[queue_id].free = TRUE;
    strcpy(OS_queue_table[queue_id].name, "");
    OS_queue_table[queue_id].creator = UNINITIALIZED;
    OS_queue_table[queue_id].max_size = 0;
    OS_queue_table[queue_id].id = UNINITIALIZED;
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
   return OS_SUCCESS;
}
int32 OS_QueueGet (uint32 queue_id, void *data, uint32 size, uint32 *size_copied, int32 timeout)
{
   int sizeCopied;
   int flags;
   if(queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
   {
      return OS_ERR_INVALID_ID;
   }
   else if( (data == NULL) || (size_copied == NULL) )
   {
      return OS_INVALID_POINTER;
   }
   else if( size < OS_queue_table[queue_id].max_size )
   {
      *size_copied = 0;
      return(OS_QUEUE_INVALID_SIZE);
   }
   if (timeout == OS_PEND)
   {
      fcntl(OS_queue_table[queue_id].id,F_SETFL,0);
      do
      {
         sizeCopied = recvfrom(OS_queue_table[queue_id].id, data, size, 0, NULL, NULL);
      } while ( sizeCopied == -1 && errno == EINTR );
      if ( sizeCopied == -1 )
      {
         *size_copied = 0;
         return OS_ERROR;
      }
      else
      {
         *size_copied = sizeCopied;
      }
   }
   else if (timeout == OS_CHECK)
   {
      flags = fcntl(OS_queue_table[queue_id].id, F_GETFL, 0);
      fcntl(OS_queue_table[queue_id].id,F_SETFL,flags|O_NONBLOCK);
      sizeCopied = recvfrom(OS_queue_table[queue_id].id, data, size, 0, NULL, NULL);
      fcntl(OS_queue_table[queue_id].id,F_SETFL,flags);
      if (sizeCopied == -1 && errno == EWOULDBLOCK )
      {
         *size_copied = 0;
         return(OS_QUEUE_EMPTY);
      }
      else if ( sizeCopied == -1 )
      {
         *size_copied = 0;
         return(OS_ERROR);
      }
      else
      {
         *size_copied = sizeCopied;
      }
   }
   else
   {
      int rv;
      int sock = OS_queue_table[queue_id].id;
      struct timeval tv_timeout;
      fd_set fdset;
      FD_ZERO( &fdset );
      FD_SET( sock, &fdset );
      tv_timeout.tv_usec = (timeout % 1000) * 1000;
      tv_timeout.tv_sec = timeout / 1000;
      do
      {
         FD_ZERO( &fdset );
         FD_SET( sock, &fdset );
         rv = select( sock+1, &fdset, NULL, NULL, &tv_timeout );
      } while ( rv == -1 && errno == EINTR );
      if( rv > 0 )
      {
         sizeCopied = recvfrom(OS_queue_table[queue_id].id, data, size, 0, NULL, NULL);
         if ( sizeCopied == -1 )
         {
            *size_copied = 0;
            return(OS_ERROR);
         }
         else
         {
            *size_copied = sizeCopied;
         }
      }
      else if ( rv < 0 )
      {
         #ifdef OS_DEBUG_PRINTF
            printf("Bad return value from select: %d, sock = %d\n", rv, sock);
         #endif
         *size_copied = 0;
         return OS_ERROR;
      }
      else {
          *size_copied = 0;
          return(OS_QUEUE_TIMEOUT);
      }
   }
   return OS_SUCCESS;
}
int32 OS_QueuePut (uint32 queue_id, const void *data, uint32 size, uint32 flags)
{
   struct sockaddr_in serva;
   static int socketFlags = 0;
   int bytesSent = 0;
   int tempSkt = 0;
   if(queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
   {
       return OS_ERR_INVALID_ID;
   }
   if (data == NULL)
   {
       return OS_INVALID_POINTER;
   }
   memset(&serva, 0, sizeof(serva));
   serva.sin_family = AF_INET;
   serva.sin_port = htons(OS_BASE_PORT + queue_id);
   serva.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
   tempSkt = socket(AF_INET, SOCK_DGRAM, 0);
   bytesSent = sendto(tempSkt,(char *)data, size, socketFlags,
                    (struct sockaddr *)&serva, sizeof(serva));
   if( bytesSent == -1 )
   {
      close(tempSkt);
      return(OS_ERROR);
   }
   if( bytesSent != size )
   {
      close(tempSkt);
      return(OS_QUEUE_FULL);
   }
   close(tempSkt);
   return OS_SUCCESS;
}
#else
int32 OS_QueueCreate (uint32 *queue_id, const char *queue_name, uint32 queue_depth,
                      uint32 data_size, uint32 flags)
{
    int i;
    pid_t process_id;
    mqd_t queueDesc;
    struct mq_attr queueAttr;
    uint32 possible_qid;
    char name[OS_MAX_API_NAME * 2];
    char process_id_string[OS_MAX_API_NAME+1];
    sigset_t previous;
    sigset_t mask;
    if ( queue_id == NULL || queue_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(queue_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    for(possible_qid = 0; possible_qid < OS_MAX_QUEUES; possible_qid++)
    {
        if (OS_queue_table[possible_qid].free == TRUE)
            break;
    }
    if( possible_qid >= OS_MAX_QUEUES || OS_queue_table[possible_qid].free != TRUE)
    {
        OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_QUEUES; i++)
    {
        if ((OS_queue_table[i].free == FALSE) &&
            strcmp ((char*) queue_name, OS_queue_table[i].name) == 0)
        {
            OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    OS_queue_table[possible_qid].free = FALSE;
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
    queueAttr.mq_maxmsg = queue_depth;
    queueAttr.mq_msgsize = data_size;
    strcpy(name, "/");
    process_id = getpid();
    sprintf(process_id_string, "%d", process_id);
    strcat(name, process_id_string);
    strcat(name,".");
    strcat(name, queue_name);
    queueDesc = mq_open(name, O_CREAT | O_RDWR, 0666, &queueAttr);
    if ( queueDesc == -1 )
    {
        OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
        OS_queue_table[possible_qid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("OS_QueueCreate Error. errno = %d\n",errno);
        #endif
        if( errno ==EINVAL)
        {
            printf("Your queue depth may be too large for the\n");
            printf("OS to handle. Please check the msg_max\n");
            printf("parameter located in /proc/sys/fs/mqueue/msg_max\n");
            printf("on your Linux file system and raise it if you\n");
            printf(" need to or run as root\n");
        }
        return OS_ERROR;
    }
    *queue_id = possible_qid;
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    OS_queue_table[*queue_id].id = queueDesc;
    OS_queue_table[*queue_id].free = FALSE;
    OS_queue_table[*queue_id].max_size = data_size;
    strcpy( OS_queue_table[*queue_id].name, (char*) queue_name);
    OS_queue_table[*queue_id].creator = OS_FindCreator();
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_QueueDelete (uint32 queue_id)
{
    pid_t process_id;
    char name[OS_MAX_API_NAME+1];
    char process_id_string[OS_MAX_API_NAME+1];
    sigset_t previous;
    sigset_t mask;
    if (queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
    {
       return OS_ERR_INVALID_ID;
    }
    strcpy(name, "/");
    process_id = getpid();
    sprintf(process_id_string, "%d", process_id);
    strcat(name, process_id_string);
    strcat(name,".");
    strcat(name, OS_queue_table[queue_id].name);
    if((mq_close(OS_queue_table[queue_id].id) == -1) || (mq_unlink(name) == -1))
    {
        return OS_ERROR;
    }
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    OS_queue_table[queue_id].free = TRUE;
    strcpy(OS_queue_table[queue_id].name, "");
    OS_queue_table[queue_id].creator = UNINITIALIZED;
    OS_queue_table[queue_id].max_size = 0;
    OS_queue_table[queue_id].id = UNINITIALIZED;
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_QueueGet (uint32 queue_id, void *data, uint32 size, uint32 *size_copied, int32 timeout)
{
    struct mq_attr queueAttr;
    int sizeCopied = -1;
    struct timespec ts;
    if(queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    else if( (data == NULL) || (size_copied == NULL) )
    {
        return OS_INVALID_POINTER;
    }
    else if( size < OS_queue_table[queue_id].max_size )
    {
        *size_copied = 0;
        return(OS_QUEUE_INVALID_SIZE);
    }
    if (timeout == OS_PEND)
    {
        do
        {
           sizeCopied = mq_receive(OS_queue_table[queue_id].id, data, size, NULL);
        } while ((sizeCopied == -1) && (errno == EINTR));
        if (sizeCopied == -1)
        {
            *size_copied = 0;
            return(OS_ERROR);
        }
        else
        {
           *size_copied = sizeCopied;
        }
    }
    else if (timeout == OS_CHECK)
    {
        if(mq_getattr(OS_queue_table[queue_id].id, &queueAttr))
        {
            *size_copied = 0;
            return (OS_ERROR);
        }
        if(queueAttr.mq_curmsgs > 0)
        {
            do
            {
                sizeCopied = mq_receive(OS_queue_table[queue_id].id, data, size, NULL);
            } while ( sizeCopied == -1 && errno == EINTR );
            if (sizeCopied == -1)
            {
                *size_copied = 0;
                return(OS_ERROR);
            }
            else
            {
               *size_copied = sizeCopied;
            }
        }
        else
        {
            *size_copied = 0;
            return (OS_QUEUE_EMPTY);
        }
    }
    else
    {
        OS_CompAbsDelayTime( timeout , &ts) ;
        do
        {
           sizeCopied = mq_timedreceive(OS_queue_table[queue_id].id, data, size, NULL, &ts);
        } while ( sizeCopied == -1 && errno == EINTR );
        if((sizeCopied == -1) && (errno == ETIMEDOUT))
        {
            return(OS_QUEUE_TIMEOUT);
        }
        else if (sizeCopied == -1)
        {
            *size_copied = 0;
            return(OS_ERROR);
        }
        else
        {
            *size_copied = sizeCopied;
        }
    }
    return OS_SUCCESS;
}
int32 OS_QueuePut (uint32 queue_id, const void *data, uint32 size, uint32 flags)
{
    struct mq_attr queueAttr;
    if(queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
    {
       return OS_ERR_INVALID_ID;
    }
    if (data == NULL)
    {
       return OS_INVALID_POINTER;
    }
    if(mq_getattr(OS_queue_table[queue_id].id, &queueAttr))
    {
       return (OS_ERROR);
    }
    if(queueAttr.mq_curmsgs >= queueAttr.mq_maxmsg)
    {
       return(OS_QUEUE_FULL);
    }
    if(mq_send(OS_queue_table[queue_id].id, data, size, 1) == -1)
    {
        return(OS_ERROR);
    }
    return OS_SUCCESS;
}
#endif
int32 OS_QueueGetIdByName (uint32 *queue_id, const char *queue_name)
{
    uint32 i;
    if(queue_id == NULL || queue_name == NULL)
    {
       return OS_INVALID_POINTER;
    }
    if (strlen(queue_name) >= OS_MAX_API_NAME)
    {
       return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_QUEUES; i++)
    {
        if (OS_queue_table[i].free != TRUE &&
           (strcmp(OS_queue_table[i].name, (char*) queue_name) == 0 ))
        {
            *queue_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_QueueGetInfo (uint32 queue_id, OS_queue_prop_t *queue_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (queue_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (queue_id >= OS_MAX_QUEUES || OS_queue_table[queue_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    OS_InterruptSafeLock(&OS_queue_table_mut, &mask, &previous);
    queue_prop -> creator = OS_queue_table[queue_id].creator;
    strcpy(queue_prop -> name, OS_queue_table[queue_id].name);
    OS_InterruptSafeUnlock(&OS_queue_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_BinSemCreate (uint32 *sem_id, const char *sem_name, uint32 sem_initial_value,
                        uint32 options)
{
    uint32 possible_semid;
    uint32 i;
    int Status;
    pthread_mutexattr_t mutex_attr;
    sigset_t previous;
    sigset_t mask;
    if (sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    OS_InterruptSafeLock(&OS_bin_sem_table_mut, &mask, &previous);
    for (possible_semid = 0; possible_semid < OS_MAX_BIN_SEMAPHORES; possible_semid++)
    {
        if (OS_bin_sem_table[possible_semid].free == TRUE)
            break;
    }
    if((possible_semid >= OS_MAX_BIN_SEMAPHORES) ||
       (OS_bin_sem_table[possible_semid].free != TRUE))
    {
        OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_BIN_SEMAPHORES; i++)
    {
        if ((OS_bin_sem_table[i].free == FALSE) &&
                strcmp ((char*) sem_name, OS_bin_sem_table[i].name) == 0)
        {
            OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    if ( sem_initial_value > 1 )
    {
        sem_initial_value = 1;
    }
    errno = 0;
    Status = pthread_mutexattr_init(&mutex_attr);
    if ( Status == 0 )
    {
       Status = pthread_mutexattr_setprotocol(&mutex_attr,PTHREAD_PRIO_INHERIT);
       if ( Status == 0 )
       {
          Status = pthread_mutex_init(&(OS_bin_sem_table[possible_semid].id), &mutex_attr);
          if( Status == 0 )
          {
             Status = pthread_cond_init(&(OS_bin_sem_table[possible_semid].cv), NULL);
             if ( Status == 0 )
             {
                *sem_id = possible_semid;
                strcpy(OS_bin_sem_table[*sem_id].name , (char*) sem_name);
                OS_bin_sem_table[*sem_id].creator = OS_FindCreator();
                OS_bin_sem_table[*sem_id].max_value = 1;
                OS_bin_sem_table[*sem_id].current_value = sem_initial_value;
                OS_bin_sem_table[*sem_id].free = FALSE;
                OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
                return OS_SUCCESS;
             }
             else
             {
                OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
                #ifdef OS_DEBUG_PRINTF
                   printf("Error: pthread_cond_init failed\n");
                #endif
                return (OS_SEM_FAILURE);
             }
          }
          else
          {
             OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
             #ifdef OS_DEBUG_PRINTF
                printf("Error: pthread_mutex_init failed\n");
             #endif
             return (OS_SEM_FAILURE);
          }
      }
      else
      {
          OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
          #ifdef OS_DEBUG_PRINTF
             printf("Error: pthread_mutexattr_setprotocol failed\n");
          #endif
          return (OS_SEM_FAILURE);
      }
   }
   else
   {
      OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
      #ifdef OS_DEBUG_PRINTF
         printf("Error: pthread_mutexattr_init failed\n");
      #endif
      return (OS_SEM_FAILURE);
   }
}
int32 OS_BinSemDelete (uint32 sem_id)
{
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_BIN_SEMAPHORES || OS_bin_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    OS_InterruptSafeLock(&OS_bin_sem_table_mut, &mask, &previous);
    pthread_mutex_destroy(&(OS_bin_sem_table[sem_id].id));
    pthread_cond_destroy(&(OS_bin_sem_table[sem_id].cv));
    OS_bin_sem_table[sem_id].free = TRUE;
    strcpy(OS_bin_sem_table[sem_id].name , "");
    OS_bin_sem_table[sem_id].creator = UNINITIALIZED;
    OS_bin_sem_table[sem_id].max_value = 0;
    OS_bin_sem_table[sem_id].current_value = 0;
    OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_BinSemGive ( uint32 sem_id )
{
    int ret;
    sigset_t previous;
    sigset_t mask;
    if(sem_id >= OS_MAX_BIN_SEMAPHORES || OS_bin_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = OS_InterruptSafeLock(&(OS_bin_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_bin_sem_table[sem_id].current_value < OS_bin_sem_table[sem_id].max_value )
    {
         OS_bin_sem_table[sem_id].current_value ++;
         pthread_cond_signal(&(OS_bin_sem_table[sem_id].cv));
    }
    OS_InterruptSafeUnlock(&(OS_bin_sem_table[sem_id].id), &previous);
    return (OS_SUCCESS);
}
int32 OS_BinSemFlush (uint32 sem_id)
{
    uint32 ret_val;
    int32 ret = 0;
    sigset_t previous;
    sigset_t mask;
    if(sem_id >= OS_MAX_BIN_SEMAPHORES || OS_bin_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = OS_InterruptSafeLock(&(OS_bin_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    ret = pthread_cond_broadcast(&(OS_bin_sem_table[sem_id].cv));
    if ( ret == 0 )
    {
       ret_val = OS_SUCCESS ;
       OS_bin_sem_table[sem_id].current_value = OS_bin_sem_table[sem_id].max_value;
    }
    else
    {
       ret_val = OS_SEM_FAILURE;
    }
    OS_InterruptSafeUnlock(&(OS_bin_sem_table[sem_id].id), &previous);
    return(ret_val);
}
int32 OS_BinSemTake ( uint32 sem_id )
{
    uint32 ret_val;
    int ret;
    sigset_t previous;
    sigset_t mask;
    if(sem_id >= OS_MAX_BIN_SEMAPHORES || OS_bin_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = OS_InterruptSafeLock(&(OS_bin_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_bin_sem_table[sem_id].current_value < OS_bin_sem_table[sem_id].max_value )
    {
       ret = pthread_cond_wait(&(OS_bin_sem_table[sem_id].cv),&(OS_bin_sem_table[sem_id].id));
       if ( ret == 0 )
       {
          ret_val = OS_SUCCESS;
          OS_bin_sem_table[sem_id].current_value --;
       }
       else
       {
           ret_val = OS_SEM_FAILURE;
       }
    }
    else
    {
       OS_bin_sem_table[sem_id].current_value --;
       ret_val = OS_SUCCESS;
    }
    OS_InterruptSafeUnlock(&(OS_bin_sem_table[sem_id].id), &previous);
    return (ret_val);
}
int32 OS_BinSemTimedWait ( uint32 sem_id, uint32 msecs )
{
    int ret;
    uint32 ret_val;
    struct timespec ts;
    sigset_t previous;
    sigset_t mask;
    if( (sem_id >= OS_MAX_BIN_SEMAPHORES) || (OS_bin_sem_table[sem_id].free == TRUE) )
    {
       return OS_ERR_INVALID_ID;
    }
    OS_CompAbsDelayTime(msecs, &ts);
    ret = OS_InterruptSafeLock(&(OS_bin_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_bin_sem_table[sem_id].current_value < OS_bin_sem_table[sem_id].max_value )
    {
       ret = pthread_cond_timedwait(&(OS_bin_sem_table[sem_id].cv), &(OS_bin_sem_table[sem_id].id), &ts);
       if ( ret == 0 )
       {
          ret_val = OS_SUCCESS;
          OS_bin_sem_table[sem_id].current_value --;
       }
       else if ( ret == ETIMEDOUT )
       {
          ret_val = OS_SEM_TIMEOUT;
       }
       else
       {
           ret_val = OS_SEM_FAILURE;
       }
    }
    else
    {
       OS_bin_sem_table[sem_id].current_value --;
       ret_val = OS_SUCCESS;
    }
    OS_InterruptSafeUnlock(&(OS_bin_sem_table[sem_id].id), &previous);
    return ret_val;
}
int32 OS_BinSemGetIdByName (uint32 *sem_id, const char *sem_name)
{
    uint32 i;
    if (sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
       return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_BIN_SEMAPHORES; i++)
    {
        if (OS_bin_sem_table[i].free != TRUE &&
                (strcmp (OS_bin_sem_table[i].name , (char*) sem_name) == 0))
        {
            *sem_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_BinSemGetInfo (uint32 sem_id, OS_bin_sem_prop_t *bin_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_BIN_SEMAPHORES || OS_bin_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if (bin_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    OS_InterruptSafeLock(&OS_bin_sem_table_mut, &mask, &previous);
    bin_prop ->creator = OS_bin_sem_table[sem_id].creator;
    bin_prop -> value = OS_bin_sem_table[sem_id].current_value ;
    strcpy(bin_prop-> name, OS_bin_sem_table[sem_id].name);
    OS_InterruptSafeUnlock(&OS_bin_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_CountSemCreate (uint32 *sem_id, const char *sem_name, uint32 sem_initial_value,
                        uint32 options)
{
    uint32 possible_semid;
    uint32 i;
    int Status;
    pthread_mutexattr_t mutex_attr;
    sigset_t previous;
    sigset_t mask;
    if (sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    if ( sem_initial_value > SEM_VALUE_MAX )
    {
        return OS_INVALID_SEM_VALUE;
    }
    OS_InterruptSafeLock(&OS_count_sem_table_mut, &mask, &previous);
    for (possible_semid = 0; possible_semid < OS_MAX_COUNT_SEMAPHORES; possible_semid++)
    {
        if (OS_count_sem_table[possible_semid].free == TRUE)
            break;
    }
    if((possible_semid >= OS_MAX_COUNT_SEMAPHORES) ||
       (OS_count_sem_table[possible_semid].free != TRUE))
    {
        OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_COUNT_SEMAPHORES; i++)
    {
        if ((OS_count_sem_table[i].free == FALSE) &&
                strcmp ((char*) sem_name, OS_count_sem_table[i].name) == 0)
        {
            OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    errno = 0;
    Status = pthread_mutexattr_init(&mutex_attr);
    if ( Status == 0 )
    {
       Status = pthread_mutexattr_setprotocol(&mutex_attr,PTHREAD_PRIO_INHERIT);
       if ( Status == 0 )
       {
          Status = pthread_mutex_init(&(OS_count_sem_table[possible_semid].id), &mutex_attr);
          if( Status == 0 )
          {
             Status = pthread_cond_init(&(OS_count_sem_table[possible_semid].cv), NULL);
             if ( Status == 0 )
             {
                *sem_id = possible_semid;
                strcpy(OS_count_sem_table[*sem_id].name , (char*) sem_name);
                OS_count_sem_table[*sem_id].creator = OS_FindCreator();
                OS_count_sem_table[*sem_id].max_value = SEM_VALUE_MAX;
                OS_count_sem_table[*sem_id].current_value = sem_initial_value;
                OS_count_sem_table[*sem_id].free = FALSE;
                OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
                return OS_SUCCESS;
             }
             else
             {
                OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
                #ifdef OS_DEBUG_PRINTF
                   printf("Error: pthread_cond_init failed\n");
                #endif
                return (OS_SEM_FAILURE);
             }
          }
          else
          {
             OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
             #ifdef OS_DEBUG_PRINTF
                printf("Error: pthread_mutex_init failed\n");
             #endif
             return (OS_SEM_FAILURE);
          }
      }
      else
      {
          OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
          #ifdef OS_DEBUG_PRINTF
             printf("Error: pthread_mutexattr_setprotocol failed\n");
          #endif
          return (OS_SEM_FAILURE);
      }
   }
   else
   {
      OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
      #ifdef OS_DEBUG_PRINTF
         printf("Error: pthread_mutexattr_init failed\n");
      #endif
      return (OS_SEM_FAILURE);
   }
}
int32 OS_CountSemDelete (uint32 sem_id)
{
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_COUNT_SEMAPHORES || OS_count_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    OS_InterruptSafeLock(&OS_count_sem_table_mut, &mask, &previous);
    pthread_mutex_destroy(&(OS_count_sem_table[sem_id].id));
    pthread_cond_destroy(&(OS_count_sem_table[sem_id].cv));
    OS_count_sem_table[sem_id].free = TRUE;
    strcpy(OS_count_sem_table[sem_id].name , "");
    OS_count_sem_table[sem_id].creator = UNINITIALIZED;
    OS_count_sem_table[sem_id].max_value = 0;
    OS_count_sem_table[sem_id].current_value = 0;
    OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_CountSemGive ( uint32 sem_id )
{
    int ret;
    sigset_t previous;
    sigset_t mask;
    if(sem_id >= OS_MAX_COUNT_SEMAPHORES || OS_count_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = OS_InterruptSafeLock(&(OS_count_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_count_sem_table[sem_id].current_value <= 0 )
    {
         OS_count_sem_table[sem_id].current_value ++;
         pthread_cond_signal(&(OS_count_sem_table[sem_id].cv));
    }
    else if ( OS_count_sem_table[sem_id].current_value < OS_count_sem_table[sem_id].max_value )
    {
         OS_count_sem_table[sem_id].current_value ++;
    }
    OS_InterruptSafeUnlock(&(OS_count_sem_table[sem_id].id), &previous);
    return (OS_SUCCESS);
}
int32 OS_CountSemTake ( uint32 sem_id )
{
    uint32 ret_val;
    int ret;
    sigset_t previous;
    sigset_t mask;
    if(sem_id >= OS_MAX_COUNT_SEMAPHORES || OS_count_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    ret = OS_InterruptSafeLock(&(OS_count_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_count_sem_table[sem_id].current_value <= 0 )
    {
       ret = pthread_cond_wait(&(OS_count_sem_table[sem_id].cv),&(OS_count_sem_table[sem_id].id));
       if ( ret == 0 )
       {
          ret_val = OS_SUCCESS;
          OS_count_sem_table[sem_id].current_value --;
       }
       else
       {
           ret_val = OS_SEM_FAILURE;
       }
    }
    else
    {
       OS_count_sem_table[sem_id].current_value --;
       ret_val = OS_SUCCESS;
    }
    OS_InterruptSafeUnlock(&(OS_count_sem_table[sem_id].id), &previous);
    return (ret_val);
}
int32 OS_CountSemTimedWait ( uint32 sem_id, uint32 msecs )
{
    int ret;
    uint32 ret_val;
    struct timespec ts;
    sigset_t previous;
    sigset_t mask;
    if( (sem_id >= OS_MAX_COUNT_SEMAPHORES) || (OS_count_sem_table[sem_id].free == TRUE) )
    {
       return OS_ERR_INVALID_ID;
    }
    OS_CompAbsDelayTime(msecs, &ts);
    ret = OS_InterruptSafeLock(&(OS_count_sem_table[sem_id].id), &mask, &previous);
    if ( ret != 0 )
    {
       return(OS_SEM_FAILURE);
    }
    if ( OS_count_sem_table[sem_id].current_value <= 0 )
    {
       ret = pthread_cond_timedwait(&(OS_count_sem_table[sem_id].cv), &(OS_count_sem_table[sem_id].id), &ts);
       if ( ret == 0 )
       {
          ret_val = OS_SUCCESS;
          OS_count_sem_table[sem_id].current_value --;
       }
       else if ( ret == ETIMEDOUT )
       {
          ret_val = OS_SEM_TIMEOUT;
       }
       else
       {
           ret_val = OS_SEM_FAILURE;
       }
    }
    else
    {
       OS_count_sem_table[sem_id].current_value --;
       ret_val = OS_SUCCESS;
    }
    OS_InterruptSafeUnlock(&(OS_count_sem_table[sem_id].id), &previous);
    return ret_val;
}
int32 OS_CountSemGetIdByName (uint32 *sem_id, const char *sem_name)
{
    uint32 i;
    if (sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_COUNT_SEMAPHORES; i++)
    {
        if (OS_count_sem_table[i].free != TRUE &&
                (strcmp (OS_count_sem_table[i].name , (char*) sem_name) == 0))
        {
            *sem_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_CountSemGetInfo (uint32 sem_id, OS_count_sem_prop_t *count_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_COUNT_SEMAPHORES || OS_count_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if (count_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    OS_InterruptSafeLock(&OS_count_sem_table_mut, &mask, &previous);
    count_prop -> value = OS_count_sem_table[sem_id].current_value;
    count_prop -> creator = OS_count_sem_table[sem_id].creator;
    strcpy(count_prop-> name, OS_count_sem_table[sem_id].name);
    OS_InterruptSafeUnlock(&OS_count_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_MutSemCreate (uint32 *sem_id, const char *sem_name, uint32 options)
{
    int return_code;
    pthread_mutexattr_t mutex_attr ;
    uint32 possible_semid;
    uint32 i;
    sigset_t previous;
    sigset_t mask;
    if (sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
    for (possible_semid = 0; possible_semid < OS_MAX_MUTEXES; possible_semid++)
    {
        if (OS_mut_sem_table[possible_semid].free == TRUE)
            break;
    }
    if( (possible_semid == OS_MAX_MUTEXES) ||
        (OS_mut_sem_table[possible_semid].free != TRUE) )
    {
        OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
        return OS_ERR_NO_FREE_IDS;
    }
    for (i = 0; i < OS_MAX_MUTEXES; i++)
    {
        if ((OS_mut_sem_table[i].free == FALSE) &&
                strcmp ((char*) sem_name, OS_mut_sem_table[i].name) == 0)
        {
            OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
            return OS_ERR_NAME_TAKEN;
        }
    }
    OS_mut_sem_table[possible_semid].free = FALSE;
    OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
    return_code = pthread_mutexattr_init(&mutex_attr);
    if ( return_code != 0 )
    {
        OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
        OS_mut_sem_table[possible_semid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("Error: Mutex could not be created. pthread_mutexattr_init failed ID = %lu\n",possible_semid);
        #endif
        return OS_SEM_FAILURE;
    }
    return_code = pthread_mutexattr_setprotocol(&mutex_attr,PTHREAD_PRIO_INHERIT) ;
    if ( return_code != 0 )
    {
        OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
        OS_mut_sem_table[possible_semid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("Error: Mutex could not be created. pthread_mutexattr_setprotocol failed ID = %lu\n",possible_semid);
        #endif
        return OS_SEM_FAILURE;
    }
    return_code = pthread_mutexattr_settype(&mutex_attr, PTHREAD_MUTEX_RECURSIVE);
    if ( return_code != 0 )
    {
        OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
        OS_mut_sem_table[possible_semid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("Error: Mutex could not be created. pthread_mutexattr_settype failed ID = %lu\n",possible_semid);
        #endif
       return OS_SEM_FAILURE;
    }
    return_code = pthread_mutex_init((pthread_mutex_t *) &OS_mut_sem_table[possible_semid].id,&mutex_attr);
    if ( return_code != 0 )
    {
        OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
        OS_mut_sem_table[possible_semid].free = TRUE;
        OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
        #ifdef OS_DEBUG_PRINTF
           printf("Error: Mutex could not be created. ID = %lu\n",possible_semid);
        #endif
       return OS_SEM_FAILURE;
    }
    else
    {
       *sem_id = possible_semid;
       OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
       strcpy(OS_mut_sem_table[*sem_id].name, (char*) sem_name);
       OS_mut_sem_table[*sem_id].free = FALSE;
       OS_mut_sem_table[*sem_id].creator = OS_FindCreator();
       OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
       return OS_SUCCESS;
    }
}
int32 OS_MutSemDelete (uint32 sem_id)
{
    int status=-1;
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_MUTEXES || OS_mut_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    status = pthread_mutex_destroy( &(OS_mut_sem_table[sem_id].id));
    if( status != 0)
    {
        return OS_SEM_FAILURE;
    }
    OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
    OS_mut_sem_table[sem_id].free = TRUE;
    strcpy(OS_mut_sem_table[sem_id].name , "");
    OS_mut_sem_table[sem_id].creator = UNINITIALIZED;
    OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_MutSemGive ( uint32 sem_id )
{
    uint32 ret_val ;
    if(sem_id >= OS_MAX_MUTEXES || OS_mut_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if(pthread_mutex_unlock(&(OS_mut_sem_table[sem_id].id)))
    {
        ret_val = OS_SEM_FAILURE ;
    }
    else
    {
        ret_val = OS_SUCCESS ;
    }
    return ret_val;
}
int32 OS_MutSemTake ( uint32 sem_id )
{
    int status;
    if(sem_id >= OS_MAX_MUTEXES || OS_mut_sem_table[sem_id].free == TRUE)
    {
       return OS_ERR_INVALID_ID;
    }
    status = pthread_mutex_lock(&(OS_mut_sem_table[sem_id].id));
    if( status == EINVAL )
    {
      return OS_SEM_FAILURE ;
    }
    else if ( status == EDEADLK )
    {
       #ifdef OS_DEBUG_PRINTF
          printf("Task would deadlock--nested mutex call!\n");
       #endif
       return OS_SUCCESS ;
    }
    else
    {
      return OS_SUCCESS;
    }
}
int32 OS_MutSemGetIdByName (uint32 *sem_id, const char *sem_name)
{
    uint32 i;
    if(sem_id == NULL || sem_name == NULL)
    {
        return OS_INVALID_POINTER;
    }
    if (strlen(sem_name) >= OS_MAX_API_NAME)
    {
        return OS_ERR_NAME_TOO_LONG;
    }
    for (i = 0; i < OS_MAX_MUTEXES; i++)
    {
        if ((OS_mut_sem_table[i].free != TRUE) &&
           (strcmp (OS_mut_sem_table[i].name, (char*) sem_name) == 0) )
        {
            *sem_id = i;
            return OS_SUCCESS;
        }
    }
    return OS_ERR_NAME_NOT_FOUND;
}
int32 OS_MutSemGetInfo (uint32 sem_id, OS_mut_sem_prop_t *mut_prop)
{
    sigset_t previous;
    sigset_t mask;
    if (sem_id >= OS_MAX_MUTEXES || OS_mut_sem_table[sem_id].free == TRUE)
    {
        return OS_ERR_INVALID_ID;
    }
    if (mut_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    OS_InterruptSafeLock(&OS_mut_sem_table_mut, &mask, &previous);
    mut_prop -> creator = OS_mut_sem_table[sem_id].creator;
    strcpy(mut_prop-> name, OS_mut_sem_table[sem_id].name);
    OS_InterruptSafeUnlock(&OS_mut_sem_table_mut, &previous);
    return OS_SUCCESS;
}
int32 OS_IntAttachHandler (uint32 InterruptNumber, osal_task_entry InterruptHandler, int32 parameter)
{
    if (InterruptHandler == NULL)
    {
        return OS_INVALID_POINTER;
    }
    return(OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_IntUnlock (int32 IntLevel)
{
    return(OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_IntLock ( void )
{
    return(OS_ERR_NOT_IMPLEMENTED) ;
}
int32 OS_IntEnable(int32 Level)
{
    return(OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_IntDisable(int32 Level)
{
    return(OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_HeapGetInfo (OS_heap_prop_t *heap_prop)
{
    if (heap_prop == NULL)
    {
        return OS_INVALID_POINTER;
    }
    return (OS_ERR_NOT_IMPLEMENTED);
}
int32 OS_Tick2Micros (void)
{
   return ((int32)(1000000) / sysconf(_SC_CLK_TCK));
}
int32 OS_Milli2Ticks(uint32 milli_seconds)
{
    uint32 num_of_ticks;
    uint32 tick_duration_usec;
    tick_duration_usec = OS_Tick2Micros();
    num_of_ticks = ((milli_seconds * 1000) + tick_duration_usec - 1)/tick_duration_usec;
    return(num_of_ticks);
}
int32 OS_GetLocalTime(OS_time_t *time_struct)
{
   int Status;
   int32 ReturnCode;
   struct timespec time;
    if (time_struct == NULL)
    {
       return OS_INVALID_POINTER;
    }
    Status = clock_gettime(CLOCK_REALTIME, &time);
    if (Status == 0)
    {
        time_struct -> seconds = time.tv_sec;
        time_struct -> microsecs = time.tv_nsec / 1000;
        ReturnCode = OS_SUCCESS;
    }
    else
    {
        printf("Error calling clock_gettime!\n");
        ReturnCode = OS_ERROR;
    }
    return ReturnCode;
}
int32 OS_SetLocalTime(OS_time_t *time_struct)
{
    int Status;
    int32 ReturnCode;
    struct timespec time;
    if (time_struct == NULL)
    {
       return OS_INVALID_POINTER;
    }
    time.tv_sec = time_struct -> seconds;
    time.tv_nsec = (time_struct -> microsecs * 1000);
    Status = clock_settime(CLOCK_REALTIME, &time);
    if (Status == 0)
    {
        ReturnCode = OS_SUCCESS;
    }
    else
    {
        ReturnCode = OS_ERROR;
    }
    return ReturnCode;
}
int32 OS_SetMask ( uint32 MaskSetting )
{
    return(OS_SUCCESS) ;
}
int32 OS_GetMask ( uint32 * MaskSettingPtr )
{
    return(OS_SUCCESS) ;
}
uint32 OS_FindCreator(void)
{
    pthread_t pthread_id;
    uint32 i;
    pthread_id = pthread_self();
    for (i = 0; i < OS_MAX_TASKS; i++)
    {
        if (pthread_equal(pthread_id, OS_task_table[i].id) != 0 )
        {
            break;
        }
    }
    return i;
}
void OS_CompAbsDelayTime( uint32 msecs, struct timespec * tm)
{
    clock_gettime( CLOCK_REALTIME, tm );
    tm->tv_sec += (time_t) (msecs / 1000) ;
    tm->tv_nsec += (msecs % 1000) * 1000000L ;
    if(tm->tv_nsec >= 1000000000L )
    {
        tm->tv_nsec -= 1000000000L ;
        tm->tv_sec ++ ;
    }
}
void OS_printf( const char *String, ...)
{
    va_list ptr;
    char msg_buffer [OS_BUFFER_SIZE];
    if ( OS_printf_enabled == TRUE )
    {
       va_start(ptr,String);
       vsnprintf(&msg_buffer[0], (size_t)OS_BUFFER_SIZE, String, ptr);
       va_end(ptr);
       msg_buffer[OS_BUFFER_SIZE -1] = '\0';
       printf("%s", &msg_buffer[0]);
    }
}
void OS_printf_disable(void)
{
   OS_printf_enabled = FALSE;
}
void OS_printf_enable(void)
{
   OS_printf_enabled = TRUE;
}
int32 OS_GetErrorName(int32 error_num, os_err_name_t * err_name)
{
    os_err_name_t local_name;
    uint32 return_code = OS_SUCCESS;
    if ( err_name == NULL )
    {
       return(OS_INVALID_POINTER);
    }
    switch (error_num)
    {
        case OS_SUCCESS:
            strcpy(local_name,"OS_SUCCESS"); break;
        case OS_ERROR:
            strcpy(local_name,"OS_ERROR"); break;
        case OS_INVALID_POINTER:
            strcpy(local_name,"OS_INVALID_POINTER"); break;
        case OS_ERROR_ADDRESS_MISALIGNED:
            strcpy(local_name,"OS_ADDRESS_MISALIGNED"); break;
        case OS_ERROR_TIMEOUT:
            strcpy(local_name,"OS_ERROR_TIMEOUT"); break;
        case OS_INVALID_INT_NUM:
            strcpy(local_name,"OS_INVALID_INT_NUM"); break;
        case OS_SEM_FAILURE:
            strcpy(local_name,"OS_SEM_FAILURE"); break;
        case OS_SEM_TIMEOUT:
            strcpy(local_name,"OS_SEM_TIMEOUT"); break;
        case OS_QUEUE_EMPTY:
            strcpy(local_name,"OS_QUEUE_EMPTY"); break;
        case OS_QUEUE_FULL:
            strcpy(local_name,"OS_QUEUE_FULL"); break;
        case OS_QUEUE_TIMEOUT:
            strcpy(local_name,"OS_QUEUE_TIMEOUT"); break;
        case OS_QUEUE_INVALID_SIZE:
            strcpy(local_name,"OS_QUEUE_INVALID_SIZE"); break;
        case OS_QUEUE_ID_ERROR:
            strcpy(local_name,"OS_QUEUE_ID_ERROR"); break;
        case OS_ERR_NAME_TOO_LONG:
            strcpy(local_name,"OS_ERR_NAME_TOO_LONG"); break;
        case OS_ERR_NO_FREE_IDS:
            strcpy(local_name,"OS_ERR_NO_FREE_IDS"); break;
        case OS_ERR_NAME_TAKEN:
            strcpy(local_name,"OS_ERR_NAME_TAKEN"); break;
        case OS_ERR_INVALID_ID:
            strcpy(local_name,"OS_ERR_INVALID_ID"); break;
        case OS_ERR_NAME_NOT_FOUND:
            strcpy(local_name,"OS_ERR_NAME_NOT_FOUND"); break;
        case OS_ERR_SEM_NOT_FULL:
            strcpy(local_name,"OS_ERR_SEM_NOT_FULL"); break;
        case OS_ERR_INVALID_PRIORITY:
            strcpy(local_name,"OS_ERR_INVALID_PRIORITY"); break;
        default: strcpy(local_name,"ERROR_UNKNOWN");
                 return_code = OS_ERROR;
    }
    strcpy((char*) err_name, local_name);
    return return_code;
}
int32 OS_PriorityRemap(uint32 InputPri)
{
    int OutputPri;
    int pmax = 0;
    int pmin = 0;
    int prange = abs((pmax - pmin) +1);
    int numbins, offset;
    int IsMinNegative = 0;
    int MinNegOffset = 0;
    int IsMaxNegative = 0;
    int MaxNegOffset = 0;
    int InputRev;
    if (pmin < 0)
    {
        IsMinNegative = 1;
        MinNegOffset = -pmin;
        pmin += MinNegOffset;
        pmax += MinNegOffset;
    }
    if (pmax < 0)
    {
        IsMaxNegative = 1;
        MaxNegOffset = -pmax;
        pmin += MaxNegOffset;
        pmax += MaxNegOffset;
    }
    numbins = MAX_PRIORITY/prange;
   if (MAX_PRIORITY % prange > prange/2)
   {
      numbins++;
   }
     InputRev = MAX_PRIORITY - InputPri;
     offset = InputRev / numbins ;
     OutputPri = pmin + offset ;
     if (OutputPri > pmax)
     {
         OutputPri = pmax;
     }
     if ( OutputPri < pmin)
     {
            OutputPri = pmin;
     }
     if (IsMinNegative == 1)
     {
         OutputPri -= MinNegOffset;
     }
     if (IsMaxNegative == 1)
     {
         OutputPri -= MaxNegOffset;
     }
    return OutputPri;
}
void OS_ThreadKillHandler(int sig)
{
    pthread_exit(NULL);
}
int32 OS_FPUExcSetMask(uint32 mask)
{
    return(OS_SUCCESS);
}
int32 OS_FPUExcGetMask(uint32 *mask)
{
    return(OS_SUCCESS);
}
int OS_InterruptSafeLock(pthread_mutex_t *lock, sigset_t *set, sigset_t *previous)
{
    sigfillset(set);
    if (pthread_sigmask(SIG_SETMASK, set, previous) == 0)
    {
        return pthread_mutex_lock(lock);
    }
    else
    {
        return EINVAL;
    }
}
void OS_InterruptSafeUnlock(pthread_mutex_t *lock, sigset_t *previous)
{
    pthread_mutex_unlock(lock);
    pthread_sigmask(SIG_SETMASK, previous, NULL);
}
