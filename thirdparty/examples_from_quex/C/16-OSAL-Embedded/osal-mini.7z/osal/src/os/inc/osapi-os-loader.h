#ifndef _osapi_loader_
#define _osapi_loader_ 
typedef struct
{
   uint32 valid;
   uint32 flags;
   cpuaddr code_address;
   cpuaddr code_size;
   cpuaddr data_address;
   cpuaddr data_size;
   cpuaddr bss_address;
   cpuaddr bss_size;
} OS_module_address_t;
typedef struct
{
   cpuaddr entry_point;
   uint32 host_module_id;
   char filename[OS_MAX_PATH_LEN];
   char name[OS_MAX_API_NAME];
   OS_module_address_t addr;
} OS_module_prop_t;
#ifndef OSAL_OMIT_DEPRECATED
typedef OS_module_prop_t OS_module_record_t;
#endif
int32 OS_ModuleTableInit ( void );
int32 OS_SymbolLookup (cpuaddr *symbol_address, const char *symbol_name );
int32 OS_SymbolTableDump ( const char *filename, uint32 size_limit );
int32 OS_ModuleLoad ( uint32 *module_id, const char *module_name, const char *filename );
int32 OS_ModuleUnload ( uint32 module_id );
int32 OS_ModuleInfo ( uint32 module_id, OS_module_prop_t *module_info );
#endif
