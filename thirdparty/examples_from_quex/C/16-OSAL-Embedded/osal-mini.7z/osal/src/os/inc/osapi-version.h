#ifndef _osapi_version_h_
#define _osapi_version_h_ 
#define OS_MAJOR_VERSION 4
#define OS_MINOR_VERSION 2
#define OS_REVISION 1
#define OS_MISSION_REV 0
#define OSAL_API_VERSION ((OS_MAJOR_VERSION * 10000) + (OS_MINOR_VERSION * 100) + OS_REVISION)
#endif
