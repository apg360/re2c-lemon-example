#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <sys/statvfs.h>
#include "common_types.h"
#include "osapi.h"
#include <sys/vfs.h>
#define ERROR (-1)
#undef OS_DEBUG_PRINTF
extern OS_VolumeInfo_t OS_VolumeTable [NUM_TABLE_ENTRIES];
extern OS_FDTableEntry OS_FDTable[OS_MAX_NUM_OPEN_FILES];
int32 OS_mkfs (char *address, char *devname, char * volname, uint32 blocksize,
               uint32 numblocks)
{
    int i;
    if ( devname == NULL || volname == NULL )
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if( strlen(devname) >= OS_FS_DEV_NAME_LEN || strlen(volname) >= OS_FS_VOL_NAME_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == TRUE && OS_VolumeTable[i].IsMounted == FALSE
            && strcmp(OS_VolumeTable[i].DeviceName, devname) == 0)
            break;
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        return OS_FS_ERR_DEVICE_NOT_FREE;
    }
    if (OS_VolumeTable[i].VolumeType == FS_BASED)
    {
       OS_VolumeTable[i].FreeFlag = FALSE;
       strcpy(OS_VolumeTable[i].VolumeName, volname);
       OS_VolumeTable[i].BlockSize = blocksize;
    }
    else
    {
        return OS_FS_ERR_DRIVE_NOT_CREATED;
    }
    return OS_FS_SUCCESS;
}
int32 OS_rmfs (char *devname)
{
    int i;
    int32 ReturnCode;
    if (devname ==NULL)
    {
        ReturnCode = OS_FS_ERR_INVALID_POINTER;
    }
    else if ( strlen(devname) >= OS_FS_DEV_NAME_LEN )
    {
        ReturnCode = OS_FS_ERR_PATH_TOO_LONG;
    }
    else
    {
        for (i = 0; i < NUM_TABLE_ENTRIES; i++)
        {
            if (OS_VolumeTable[i].FreeFlag == FALSE && OS_VolumeTable[i].IsMounted == FALSE
                && strcmp(OS_VolumeTable[i].DeviceName, devname) == 0)
            {
                break;
            }
        }
        if (i >= NUM_TABLE_ENTRIES)
        {
            ReturnCode = OS_FS_ERROR;
        }
        else
        {
            OS_VolumeTable[i].FreeFlag = TRUE;
            ReturnCode = OS_FS_SUCCESS;
        }
    }
    return ReturnCode;
}
int32 OS_initfs (char *address,char *devname, char *volname,
                uint32 blocksize, uint32 numblocks)
{
    int i;
    if ( devname == NULL || volname == NULL )
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if( strlen(devname) >= OS_FS_DEV_NAME_LEN || strlen(volname) >= OS_FS_VOL_NAME_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == TRUE && OS_VolumeTable[i].IsMounted == FALSE
            && strcmp(OS_VolumeTable[i].DeviceName, devname) == 0)
            break;
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        return OS_FS_ERR_DEVICE_NOT_FREE;
    }
    if (OS_VolumeTable[i].VolumeType == FS_BASED)
    {
       OS_VolumeTable[i].FreeFlag = FALSE;
       strcpy(OS_VolumeTable[i].VolumeName, volname);
       OS_VolumeTable[i].BlockSize = blocksize;
    }
    else
    {
        return OS_FS_ERR_DRIVE_NOT_CREATED;
    }
   return OS_FS_SUCCESS;
}
int32 OS_mount (const char *devname, char* mountpoint)
{
    int i;
    if ( devname == NULL || mountpoint == NULL )
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if( strlen(devname) >= OS_FS_DEV_NAME_LEN || strlen(mountpoint) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == FALSE && OS_VolumeTable[i].IsMounted == FALSE
            && strcmp(OS_VolumeTable[i].DeviceName, devname) == 0)
            break;
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        return OS_FS_ERROR;
    }
    strcpy(OS_VolumeTable[i].MountPoint, mountpoint);
    OS_VolumeTable[i].IsMounted = TRUE;
    return OS_FS_SUCCESS;
}
int32 OS_unmount (const char *mountpoint)
{
    int i;
    if (mountpoint == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(mountpoint) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == FALSE && OS_VolumeTable[i].IsMounted == TRUE
             && strcmp(OS_VolumeTable[i].MountPoint, mountpoint) == 0)
            break;
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        return OS_FS_ERROR;
    }
    OS_VolumeTable[i].IsMounted = FALSE;
    strcpy(OS_VolumeTable[i].MountPoint, "");
    return OS_FS_SUCCESS;
}
int32 OS_fsBlocksFree (const char *name)
{
   int status;
   int32 NameStatus;
   struct statvfs stat_buf;
   char tmpFileName[OS_MAX_LOCAL_PATH_LEN +1];
   if ( name == NULL )
   {
      return(OS_FS_ERR_INVALID_POINTER);
   }
   if ( strlen(name) >= OS_MAX_PATH_LEN )
   {
      return(OS_FS_ERR_PATH_TOO_LONG);
   }
   NameStatus = OS_TranslatePath(name, tmpFileName);
   if (NameStatus != OS_FS_SUCCESS)
   {
      return OS_FS_ERROR;
   }
   status = statvfs(tmpFileName, &stat_buf);
   if ( status == 0 )
   {
      return(stat_buf.f_bfree);
   }
   return OS_FS_ERROR;
}
int32 OS_fsBytesFree (const char *name, uint64 *bytes_free)
{
   int status;
   int32 NameStatus;
   struct statvfs stat_buf;
   uint64 bytes_free_local;
   char tmpFileName[OS_MAX_LOCAL_PATH_LEN +1];
   if ( name == NULL || bytes_free == NULL )
   {
      return(OS_FS_ERR_INVALID_POINTER);
   }
   if ( strlen(name) >= OS_MAX_PATH_LEN )
   {
      return(OS_FS_ERR_PATH_TOO_LONG);
   }
   NameStatus = OS_TranslatePath(name, tmpFileName);
   if (NameStatus != OS_FS_SUCCESS)
   {
      return OS_FS_ERROR;
   }
   status = statvfs(tmpFileName, &stat_buf);
   if ( status == 0 )
   {
      bytes_free_local = stat_buf.f_bfree * stat_buf.f_bsize;
      *bytes_free = bytes_free_local;
      return(OS_FS_SUCCESS);
   }
   return(OS_FS_ERROR);
}
os_fshealth_t OS_chkfs (const char *name, boolean repair)
{
    return OS_FS_UNIMPLEMENTED;
}
int32 OS_FS_GetPhysDriveName(char * PhysDriveName, char * MountPoint)
{
    int32 ReturnCode;
    int i;
    if (MountPoint == NULL || PhysDriveName == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if( strlen(PhysDriveName) >= OS_FS_DEV_NAME_LEN || strlen(MountPoint) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == FALSE &&
            strncmp(OS_VolumeTable[i].MountPoint, MountPoint, OS_MAX_PATH_LEN) == 0)
        {
            break;
        }
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        ReturnCode = OS_FS_ERROR;
    }
    else
    {
       strncpy(PhysDriveName, OS_VolumeTable[i].PhysDevName,OS_FS_PHYS_NAME_LEN);
       ReturnCode = OS_SUCCESS;
    }
    return ReturnCode;
}
int32 OS_TranslatePath(const char *VirtualPath, char *LocalPath)
{
    char devname [OS_MAX_PATH_LEN];
    char filename[OS_MAX_PATH_LEN];
    int NumChars;
    int i=0;
    if (VirtualPath == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (LocalPath == NULL)
    {
        return OS_FS_ERR_INVALID_POINTER;
    }
    if (strlen(VirtualPath) >= OS_MAX_PATH_LEN)
    {
        return OS_FS_ERR_PATH_TOO_LONG;
    }
    if ( VirtualPath[0] != '/' )
    {
       return OS_FS_ERR_PATH_INVALID;
    }
    memset((void *)devname,0,OS_MAX_PATH_LEN);
    memset((void *)filename,0,OS_MAX_PATH_LEN);
    NumChars = 1;
    while ((NumChars <= strlen(VirtualPath)) && (VirtualPath[NumChars] != '/'))
    {
        NumChars++;
    }
    if (NumChars > strlen(VirtualPath))
    {
        NumChars = strlen(VirtualPath);
    }
    snprintf(devname, OS_MAX_PATH_LEN, "%*s", NumChars, VirtualPath);
    snprintf(filename, OS_MAX_PATH_LEN, "%s", VirtualPath + NumChars);
#ifdef OS_DEBUG_PRINTF
    printf("VirtualPath: %s, Length: %d\n",VirtualPath, (int)strlen(VirtualPath));
    printf("NumChars: %d\n",NumChars);
    printf("devname: %s\n",devname);
    printf("filename: %s\n",filename);
#endif
    for (i = 0; i < NUM_TABLE_ENTRIES; i++)
    {
        if (OS_VolumeTable[i].FreeFlag == FALSE &&
            strncmp(OS_VolumeTable[i].MountPoint, devname,NumChars) == 0)
        {
            break;
        }
    }
    if (i >= NUM_TABLE_ENTRIES)
    {
        return OS_FS_ERR_PATH_INVALID;
    }
    strncpy(LocalPath,OS_VolumeTable[i].PhysDevName,OS_MAX_LOCAL_PATH_LEN);
    NumChars = strlen(LocalPath);
    strncat(LocalPath, filename, (OS_MAX_LOCAL_PATH_LEN - NumChars));
#ifdef OS_DEBUG_PRINTF
    printf("Result of TranslatePath = %s\n",LocalPath);
#endif
    return OS_FS_SUCCESS;
}
int32 OS_FS_GetErrorName(int32 error_num, os_fs_err_name_t * err_name)
{
    os_fs_err_name_t local_name;
    int32 return_code;
    return_code = OS_FS_SUCCESS;
    switch (error_num)
    {
        case OS_FS_SUCCESS:
            strcpy(local_name,"OS_FS_SUCCESS"); break;
        case OS_FS_ERROR:
            strcpy(local_name,"OS_FS_ERROR"); break;
        case OS_FS_ERR_INVALID_POINTER:
            strcpy(local_name,"OS_FS_ERR_INVALID_POINTER"); break;
        case OS_FS_ERR_PATH_TOO_LONG:
            strcpy(local_name,"OS_FS_ERR_PATH_TOO_LONG"); break;
        case OS_FS_ERR_NAME_TOO_LONG:
            strcpy(local_name,"OS_FS_ERR_NAME_TOO_LONG"); break;
        case OS_FS_UNIMPLEMENTED:
            strcpy(local_name,"OS_FS_UNIMPLEMENTED"); break;
        case OS_FS_ERR_PATH_INVALID:
            strcpy(local_name,"OS_FS_ERR_PATH_INVALID"); break;
        case OS_FS_ERR_DRIVE_NOT_CREATED:
            strcpy(local_name,"OS_FS_ERR_DRIVE_NOT_CREATED"); break;
        default: strcpy(local_name,"ERROR_UNKNOWN");
                 return_code = OS_FS_ERROR;
    }
    strcpy((char*) err_name, local_name);
    return return_code;
}
int32 OS_GetFsInfo(os_fsinfo_t *filesys_info)
{
   int i;
   if (filesys_info == NULL)
   {
       return OS_FS_ERR_INVALID_POINTER;
   }
   filesys_info->MaxFds = OS_MAX_NUM_OPEN_FILES;
   filesys_info->MaxVolumes = NUM_TABLE_ENTRIES;
   filesys_info->FreeFds = 0;
   for ( i = 0; i < OS_MAX_NUM_OPEN_FILES; i++ )
   {
      if ( OS_FDTable[i].IsValid == FALSE)
      {
         filesys_info->FreeFds++;
      }
   }
   filesys_info->FreeVolumes = 0;
   for ( i = 0; i < NUM_TABLE_ENTRIES; i++ )
   {
      if (OS_VolumeTable[i].FreeFlag == TRUE )
      {
         filesys_info->FreeVolumes++;
      }
   }
   return(OS_FS_SUCCESS);
}
