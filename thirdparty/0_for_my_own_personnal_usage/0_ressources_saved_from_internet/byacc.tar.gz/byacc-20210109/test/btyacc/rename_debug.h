#ifndef _yy_defines_h_
#define _yy_defines_h_

#define YYERRCODE 256

#endif /* _yy_defines_h_ */
