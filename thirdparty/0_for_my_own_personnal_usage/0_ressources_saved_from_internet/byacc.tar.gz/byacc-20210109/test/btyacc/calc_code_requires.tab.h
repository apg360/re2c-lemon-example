#ifndef _calc_code_requires__defines_h_
#define _calc_code_requires__defines_h_

/* %code "requires" block start */
#line 1 "calc_code_requires.y"
/* CODE-REQUIRES */ 
#line 2 "calc_code_requires.y"
/* CODE-REQUIRES2 */ 
/* %code "requires" block end */
#define DIGIT 257
#define LETTER 258
#define UMINUS 259

#endif /* _calc_code_requires__defines_h_ */
