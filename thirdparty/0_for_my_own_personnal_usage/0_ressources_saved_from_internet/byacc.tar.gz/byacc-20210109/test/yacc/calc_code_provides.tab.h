#define DIGIT 257
#define LETTER 258
#define UMINUS 259
/* %code "provides" block start */
#line 1 "calc_code_provides.y"
/* CODE-PROVIDES */ 
#line 2 "calc_code_provides.y"
/* CODE-PROVIDES2 */ 
/* %code "provides" block end */
