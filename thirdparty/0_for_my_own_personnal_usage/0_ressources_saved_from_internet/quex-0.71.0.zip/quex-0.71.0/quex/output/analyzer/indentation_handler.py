from   quex.engine.misc.string_handling  import blue_print
from   quex.blackboard                   import Lng, \
                                                required_support_indentation_count, \
                                                E_IncidenceIDs

def do(Mode, ModeNameList):
    assert required_support_indentation_count()
    assert Mode.indentation_handling_f()

    code_fragment = Mode.incidence_db.get(E_IncidenceIDs.INDENTATION_INDENT)
    if code_fragment is not None:
        on_indent_str   = Lng.SOURCE_REFERENCED(code_fragment)
    else:
        on_indent_str   = Lng.TOKEN_SEND("QUEX_SETTING_TOKEN_ID_INDENT")

    code_fragment = Mode.incidence_db.get(E_IncidenceIDs.INDENTATION_NODENT)
    if code_fragment is not None:
        on_nodent_str   = Lng.SOURCE_REFERENCED(code_fragment)
    else:
        on_nodent_str   = Lng.TOKEN_SEND("QUEX_SETTING_TOKEN_ID_NODENT")

    code_fragment   = Mode.incidence_db.get(E_IncidenceIDs.INDENTATION_DEDENT)
    if code_fragment is not None:
        on_dedent_str = Lng.SOURCE_REFERENCED(code_fragment)
    else:
        on_dedent_str = Lng.TOKEN_SEND_N("N", "QUEX_SETTING_TOKEN_ID_DEDENT")

    code_fragment = Mode.incidence_db.get(E_IncidenceIDs.INDENTATION_MISFIT)
    on_indentation_misfit = ""
    if code_fragment is not None:
        on_indentation_misfit = Lng.SOURCE_REFERENCED(code_fragment) 

    on_indentation_bad = ""
    code_fragment      = Mode.incidence_db.get(E_IncidenceIDs.INDENTATION_BAD)
    if code_fragment is not None:
        on_indentation_bad = Lng.SOURCE_REFERENCED(code_fragment) 

    # Note: 'on_indentation_bad' is applied in code generation for 
    #       indentation counter in 'indentation_counter.py'.
    counter_define_str, counter_undefine_str = Lng.DEFINE_COUNTER_VARIABLES()

    return blue_print(on_indentation_str, [
        ["$$DEFINE_SELF$$",                         Lng.DEFINE_SELF("me")],
        ["$$LEXEME_DEFINITIONS$$",                  Lng.DEFINE_LEXEME_VARIABLES()],
        ["$$LEXEME_UNDEFINITIONS$$",                Lng.UNDEFINE_LEXEME_VARIABLES()],
        ["$$COUNTER_DEFINITIONS$$",                 counter_define_str],
        ["$$COUNTER_UNDEFINITIONS$$",               counter_undefine_str],
        ["$$MODE_DEFINITION$$",                     Lng.MODE_DEFINITION(ModeNameList)],
        ["$$MODE_UNDEFINITION$$",                   Lng.MODE_UNDEFINITION(ModeNameList)],
        ["$$INDENT-PROCEDURE$$",                    on_indent_str],
        ["$$NODENT-PROCEDURE$$",                    on_nodent_str],
        ["$$N-DEDENT-PROCEDURE$$",                  on_dedent_str],
        ["$$EVENT_HANDLER-on_indentation_misfit$$", on_indentation_misfit],
        ["$$EVENT_HANDLER-on_indentation_bad$$",    on_indentation_bad]
    ])

on_indentation_str = """
void
$on_indentation(QUEX_TYPE_ANALYZER*    me, 
                QUEX_TYPE_INDENTATION  Indentation, 
                QUEX_TYPE_LEXATOM*     Begin) 
{
    (void)me;
    (void)Indentation;
    (void)Begin;
$$DEFINE_SELF$$
$$MODE_DEFINITION$$
$$LEXEME_DEFINITIONS$$
$$COUNTER_DEFINITIONS$$

    QUEX_NAME(IndentationStack)*  stack = &me->counter._indentation_stack;
    QUEX_TYPE_INDENTATION*        start = 0x0;
    ptrdiff_t                     N = (ptrdiff_t)-1;
    size_t                        IndentationStackSize;
    QUEX_TYPE_INDENTATION*        IndentationStack = &stack->front[0];
    QUEX_TYPE_INDENTATION         IndentationUpper;
    QUEX_TYPE_INDENTATION         IndentationLower;
    (void)start;

    __quex_assert((long)Indentation >= 0);

    if( Indentation > *(stack->back) ) {
        ++(stack->back);
        if( stack->back == stack->memory_end ) {
            QUEX_NAME(MF_error_code_set_if_first)(me, E_Error_Indentation_StackOverflow);
            return;
        }
        *(stack->back) = Indentation;
$$INDENT-PROCEDURE$$
        return;
    }
    else if( Indentation == *(stack->back) ) {
$$NODENT-PROCEDURE$$
    }
    else  {
        start = stack->back;
        --(stack->back);
        while( Indentation < *(stack->back) ) {
            --(stack->back);
        }

        N = (ptrdiff_t)(start - stack->back);
        (void)N;
        if( Indentation == *(stack->back) ) { 
            /* 'Landing' must happen on indentation border. */
$$N-DEDENT-PROCEDURE$$
        } else { 
            IndentationStackSize = ((size_t)(1 + start - stack->front));
            IndentationUpper     = stack->back[0];
            IndentationLower     = ((stack->back == stack->front) ? *(stack->front) : *(stack->back - 1));
            (void)IndentationLower;
            (void)IndentationUpper;
            (void)IndentationStack;
            (void)IndentationStackSize;
            QUEX_NAME(MF_error_code_set_if_first)(me,  E_Error_OnIndentationMisfit);
$$EVENT_HANDLER-on_indentation_misfit$$
            return;
        }
    }

$$LEXEME_UNDEFINITIONS$$
$$COUNTER_UNDEFINITIONS$$
}

void
$on_bad_indentation(QUEX_TYPE_ANALYZER* me) 
{
$$DEFINE_SELF$$
$$MODE_DEFINITION$$
#define BadCharacter  (me->buffer._read_p[-1])
$$LEXEME_DEFINITIONS$$
$$COUNTER_DEFINITIONS$$

$$EVENT_HANDLER-on_indentation_bad$$

#undef  BadCharacter
$$LEXEME_UNDEFINITIONS$$
$$COUNTER_UNDEFINITIONS$$
$$MODE_UNDEFINITION$$
}
"""

