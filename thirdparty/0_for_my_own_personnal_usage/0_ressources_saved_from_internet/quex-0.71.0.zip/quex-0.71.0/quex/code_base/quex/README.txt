All files in this directory and its subdirectores shall not 
depend at all on the particular implementation of a lexical
analyzer. They are general over all implementations.
