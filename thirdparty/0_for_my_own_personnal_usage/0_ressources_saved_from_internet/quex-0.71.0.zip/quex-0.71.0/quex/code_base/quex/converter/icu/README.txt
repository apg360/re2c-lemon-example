This is the converter interface for using IBM's ICU Library for
character conversions.  The library is available at:

http://icu-project.org/userguide/intro.html

Alternatively, if you are using Linux, most major distributions come
with a package that is somehow called like 'icu' or 'icu-converter'.
Search for it with your favorite installer, and you might save the
effort of compiling and installing it by hand.


