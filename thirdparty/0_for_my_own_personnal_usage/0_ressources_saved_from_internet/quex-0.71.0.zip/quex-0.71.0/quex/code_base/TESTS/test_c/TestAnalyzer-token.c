/* -*- C++ -*-   vim: set syntax=cpp: 
 * (C) 2004-2009 Frank-Rene Schaefer
 * ABSOLUTELY NO WARRANTY
 */
#ifndef QUEX_INCLUDE_GUARD_TestAnalyzer_Token__TOKEN__TOKEN__GENERATED__I
#define QUEX_INCLUDE_GUARD_TestAnalyzer_Token__TOKEN__TOKEN__GENERATED__I

#include "test_c/TestAnalyzer-token.h"

 void 
TestAnalyzer_Token_construct(TestAnalyzer_Token* __this)
{
#   define self (*__this)
#   define LexemeNull  (&TestAnalyzer_LexemeNull)
    (void)__this;

#   line 43 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

   self.number = 0;
   self.text   = LexemeNull;

#   line 22 "test_c/TestAnalyzer-token.c"

#   undef  LexemeNull
#   undef  self
}

 void 
TestAnalyzer_Token_destruct(TestAnalyzer_Token* __this)
{
#   define self (*__this)
#   define LexemeNull  (&TestAnalyzer_LexemeNull)
    if( ! __this ) return;


#   line 48 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

   if( self.text != LexemeNull ) {
       quex_MemoryManager_free((void*)self.text,
                                  E_MemoryObjectType_TEXT);
       self.text = LexemeNull;
   }

#   line 44 "test_c/TestAnalyzer-token.c"

#   undef  LexemeNull
#   undef  self
}

 void
TestAnalyzer_Token_copy(TestAnalyzer_Token*       __this, 
                      const TestAnalyzer_Token* __That)
{
#   define self  (*__this)
#   define Other (*__That)
#   define LexemeNull  (&TestAnalyzer_LexemeNull)
    if( __this == __That ) { return; }

#   line 56 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

    self.id  = Other.id;

    if( self.text != LexemeNull ) {
        quex_MemoryManager_free((void*)self.text, E_MemoryObjectType_TEXT);
    }
    if( Other.text != LexemeNull ) {
        self.text = TestAnalyzer_lexeme_clone(self.text, 
                                             TestAnalyzer_lexeme_length(Other.text));
        if( ! self.text ) self.text = LexemeNull;
    }
    self.number = Other.number;

       self.line_n   = Other.line_n;
     self.column_n = Other.column_n;

#   line 76 "test_c/TestAnalyzer-token.c"

#   undef  LexemeNull
#   undef  Other
#   undef  self
    /* If the user even misses to copy the token id, then there's
     * something seriously wrong.                                 */
    __quex_assert(__this->id == __That->id);
       __quex_assert(__this->line_n   == __That->line_n);
     __quex_assert(__this->column_n == __That->column_n);
}



 void 
TestAnalyzer_Token_take_text(TestAnalyzer_Token*         __this, 
                           const TestAnalyzer_lexatom_t* Begin, 
                           const TestAnalyzer_lexatom_t* End)
{
#   define self       (*__this)
#   ifdef  LexemeNull
#   error  "Error LexemeNull shall not be defined here."
#   endif
#   define LexemeNull  (&TestAnalyzer_LexemeNull)
    (void)__this;
    (void)Begin;
    (void)End;

#   line 73 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

    if( self.text != LexemeNull ) {
        quex_MemoryManager_free((void*)self.text, E_MemoryObjectType_TEXT);
    }
    if( Begin != LexemeNull ) {
        __quex_assert(End >= Begin);
        self.text = TestAnalyzer_lexeme_clone(Begin, (size_t)(End - Begin));
        if( ! self.text ) self.text = LexemeNull;
        *((TestAnalyzer_lexatom_t*)(self.text + (End - Begin))) = (TestAnalyzer_lexatom_t)0;
    } else {
        self.text = LexemeNull;
    }

#   line 118 "test_c/TestAnalyzer-token.c"

#   undef  LexemeNull
#   undef  self
}



#   line 91 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

    const char* 
    TestAnalyzer_Token_get_string(TestAnalyzer_Token* me, char*   buffer, size_t  BufferSize) 
    {
        const char*  token_id_str = TestAnalyzer_map_token_id_to_name(me->id);
        const char*  BufferEnd    = buffer + BufferSize;
        char*        writerator   = 0;

        if( ! BufferSize ) return NULL;

        /* Token Type */
        writerator = buffer; 
        writerator += __QUEX_STD_strlcpy(writerator, token_id_str, (size_t)(BufferEnd - writerator));

        /* Opening Quote */
        if( BufferEnd - writerator > 2 ) {
            *writerator++ = ' ';
            *writerator++ = '\'';
        }

        /* The String */
        writerator = TestAnalyzer_lexeme_to_pretty_char(me->text, writerator, BufferEnd);

        /* Closing Quote */
        if( BufferEnd - writerator > 1 ) {
            *writerator++ = '\'';
        }
        *writerator = '\0';
        return buffer;
    }



#include <test_c/lib/lexeme/basics.i>
   
#   line 162 "test_c/TestAnalyzer-token.c"


#endif /* QUEX_INCLUDE_GUARD_TestAnalyzer_Token__TOKEN__TOKEN__GENERATED__I */