/* -*- C++ -*-   vim: set syntax=cpp: 
 * (C) 2004-2017 Frank-Rene Schaefer
 * ABSOLUTELY NO WARRANTY
 */
#ifndef QUEX_INCLUDE_GUARD_TestAnalyzer_Token__TOKEN__TOKEN__GENERATED
#define QUEX_INCLUDE_GUARD_TestAnalyzer_Token__TOKEN__TOKEN__GENERATED

/* For '--token-class-only' the following option may not come directly
 * from the configuration file.                                        */

#   line 2 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"


#include <stdio.h>
#include <string.h>

#include <test_c_cg/lib/quex/types.h>
#include <test_c_cg/lib/quex/MemoryManager>
#include <test_c_cg/lib/quex/asserts>
#include <test_c_cg/lib/quex/standard_functions>

#include <test_c_cg/lib/lexeme/basics>
#include <test_c_cg/lib/lexeme/converter-from-lexeme>

struct TestAnalyzer_Token_tag;



extern TestAnalyzer_lexatom_t TestAnalyzer_LexemeNull;
extern const char*       TestAnalyzer_map_token_id_to_name(const TestAnalyzer_token_id_t);



extern const char* TestAnalyzer_Token_get_string(struct TestAnalyzer_Token_tag* me,  
                                              char*                       buffer, 
                                              size_t                      BufferSize); 

#   line 38 "test_c_cg/TestAnalyzer-token.h"


#include "test_c_cg/TestAnalyzer-configuration.h"

struct TestAnalyzer_Token_tag;

 void     TestAnalyzer_Token_construct(struct TestAnalyzer_Token_tag*);
 void     TestAnalyzer_Token_copy(struct TestAnalyzer_Token_tag*, 
                                           const struct TestAnalyzer_Token_tag*);
 void     TestAnalyzer_Token_destruct(struct TestAnalyzer_Token_tag*);


 void     TestAnalyzer_Token_take_text(struct TestAnalyzer_Token_tag* me, 
                                                const TestAnalyzer_lexatom_t*    Begin, 
                                                const TestAnalyzer_lexatom_t*    End);


typedef struct QUEX_SETTING_USER_CLASS_DECLARATION_EPILOG_EXT TestAnalyzer_Token_tag {
    TestAnalyzer_token_id_t                               id;
       TestAnalyzer_token_line_n_t    line_n;
     TestAnalyzer_token_column_n_t  column_n;

#   line 35 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"
    const TestAnalyzer_lexatom_t* text;
#   line 63 "test_c_cg/TestAnalyzer-token.h"

#   line 36 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"
    size_t                   number;
#   line 67 "test_c_cg/TestAnalyzer-token.h"



#   line 87 "/home/fschaef/prj/quex/git/quex/code_base/token/CDefault.qx"

   /* Nothing here. */

#   line 75 "test_c_cg/TestAnalyzer-token.h"

} TestAnalyzer_Token;


#endif /* QUEX_INCLUDE_GUARD_TestAnalyzer__TOKEN__GENERATED */