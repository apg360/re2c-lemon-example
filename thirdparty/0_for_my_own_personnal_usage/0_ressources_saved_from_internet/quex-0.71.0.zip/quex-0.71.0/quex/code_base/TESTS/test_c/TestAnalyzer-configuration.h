/* -*- C++ -*-   vim: set syntax=cpp:
 *
 * (C) 2005-2017 Frank-Rene Schaefer
 * ABSOLUTELY NO WARRANTY                                                     */
#ifndef QUEX_INCLUDE_GUARD_TestAnalyzer__ANALYZER__CONFIGURATION
#define QUEX_INCLUDE_GUARD_TestAnalyzer__ANALYZER__CONFIGURATION

/*______________________________________________________________________________
 * TYPE DEFINITIONS                                                 -- ADAPTABLE
 *                                                                            */
#ifdef QUEX_TYPE_lexatom_t_EXT
   typedef QUEX_TYPE_lexatom_t_EXT TestAnalyzer_lexatom_t;
#else
   typedef uint8_t TestAnalyzer_lexatom_t;
#endif
#ifdef QUEX_TYPE_token_id_t_EXT
   typedef QUEX_TYPE_token_id_t_EXT TestAnalyzer_token_id_t;
#else
   typedef uint32_t TestAnalyzer_token_id_t;
#endif
#ifdef QUEX_TYPE_token_line_n_t_EXT
   typedef QUEX_TYPE_token_line_n_t_EXT TestAnalyzer_token_line_n_t;
#else
   typedef size_t TestAnalyzer_token_line_n_t;
#endif
#ifdef QUEX_TYPE_token_column_n_t_EXT
   typedef QUEX_TYPE_token_column_n_t_EXT TestAnalyzer_token_column_n_t;
#else
   typedef size_t TestAnalyzer_token_column_n_t;
#endif
#ifdef QUEX_TYPE_acceptance_id_t_EXT
   typedef QUEX_TYPE_acceptance_id_t_EXT TestAnalyzer_acceptance_id_t;
#else
   typedef int TestAnalyzer_acceptance_id_t;
#endif
#ifdef QUEX_TYPE_indentation_t_EXT
   typedef QUEX_TYPE_indentation_t_EXT TestAnalyzer_indentation_t;
#else
   typedef int TestAnalyzer_indentation_t;
#endif
#ifdef QUEX_TYPE_stream_position_t_EXT
   typedef QUEX_TYPE_stream_position_t_EXT TestAnalyzer_stream_position_t;
#else
   typedef intmax_t TestAnalyzer_stream_position_t;
#endif
#ifdef QUEX_TYPE_goto_label_t_EXT
   typedef QUEX_TYPE_goto_label_t_EXT TestAnalyzer_goto_label_t;
#else
   typedef int32_t TestAnalyzer_goto_label_t;
#endif


/*______________________________________________________________________________
 * CONFIGURATION PARAMETERS (I)                                     -- ADAPTABLE 
 *                                                                            */
#if   defined(QUEX_SETTING_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE QUEX_SETTING_BUFFER_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE 131072
#endif
#if   defined(QUEX_SETTING_BUFFER_FALLBACK_N_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N QUEX_SETTING_BUFFER_FALLBACK_N_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N 0
#endif
#if   defined(QUEX_SETTING_BUFFER_SIZE_MIN_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_MIN QUEX_SETTING_BUFFER_SIZE_MIN_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_MIN_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_MIN QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_MIN_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_SIZE_MIN QUEX_TestAnalyzer_SETTING_BUFFER_SIZE
#endif
#if   defined(QUEX_SETTING_INDENTATION_STACK_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_INDENTATION_STACK_SIZE QUEX_SETTING_INDENTATION_STACK_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_INDENTATION_STACK_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_INDENTATION_STACK_SIZE QUEX_TestAnalyzer_SETTING_INDENTATION_STACK_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_INDENTATION_STACK_SIZE 1024
#endif
#if   defined(QUEX_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE QUEX_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_CONVERTER_BUFFER_SIZE (size_t)65536
#endif
#if   defined(QUEX_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE QUEX_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_LOADER_SEEK_BUFFER_SIZE 512
#endif
#if   defined(QUEX_SETTING_MODE_STACK_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_MODE_STACK_SIZE QUEX_SETTING_MODE_STACK_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_MODE_STACK_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_MODE_STACK_SIZE QUEX_TestAnalyzer_SETTING_MODE_STACK_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_MODE_STACK_SIZE (size_t)64
#endif
#if   defined(QUEX_SETTING_TOKEN_QUEUE_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_TOKEN_QUEUE_SIZE QUEX_SETTING_TOKEN_QUEUE_SIZE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_TOKEN_QUEUE_SIZE_EXT)
#   define QUEX_TestAnalyzer_SETTING_TOKEN_QUEUE_SIZE QUEX_TestAnalyzer_SETTING_TOKEN_QUEUE_SIZE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_TOKEN_QUEUE_SIZE (size_t)64
#endif

/*______________________________________________________________________________
 * CONFIGURATION PARAMETERS (II)                                    -- IMMUTABLE 
 *                                                                            */
#if   defined(QUEX_SETTING_VERSION_EXT)
#   define QUEX_TestAnalyzer_SETTING_VERSION QUEX_SETTING_VERSION_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_VERSION_EXT)
#   define QUEX_TestAnalyzer_SETTING_VERSION QUEX_TestAnalyzer_SETTING_VERSION_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_VERSION "0.69.2"
#endif
#if   defined(QUEX_SETTING_ANALYZER_VERSION_EXT)
#   define QUEX_TestAnalyzer_SETTING_ANALYZER_VERSION QUEX_SETTING_ANALYZER_VERSION_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_ANALYZER_VERSION_EXT)
#   define QUEX_TestAnalyzer_SETTING_ANALYZER_VERSION QUEX_TestAnalyzer_SETTING_ANALYZER_VERSION_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_ANALYZER_VERSION "0.0.0-pre-release"
#endif
#if   defined(QUEX_SETTING_BUILD_DATE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUILD_DATE QUEX_SETTING_BUILD_DATE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUILD_DATE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUILD_DATE QUEX_TestAnalyzer_SETTING_BUILD_DATE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUILD_DATE "Sat Apr  4 06:09:55 2020"
#endif
#if   defined(QUEX_SETTING_MODE_INITIAL_P_EXT)
#   define QUEX_TestAnalyzer_SETTING_MODE_INITIAL_P QUEX_SETTING_MODE_INITIAL_P_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_MODE_INITIAL_P_EXT)
#   define QUEX_TestAnalyzer_SETTING_MODE_INITIAL_P QUEX_TestAnalyzer_SETTING_MODE_INITIAL_P_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_MODE_INITIAL_P &TestAnalyzer_M
#endif
#if   defined(QUEX_SETTING_BUFFER_LEXATOM_BUFFER_BORDER_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_BUFFER_BORDER QUEX_SETTING_BUFFER_LEXATOM_BUFFER_BORDER_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_BUFFER_BORDER_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_BUFFER_BORDER QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_BUFFER_BORDER_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_BUFFER_BORDER 0x0
#endif
#if   defined(QUEX_SETTING_BUFFER_LEXATOM_NEWLINE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_NEWLINE QUEX_SETTING_BUFFER_LEXATOM_NEWLINE_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_NEWLINE_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_NEWLINE QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_NEWLINE_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_NEWLINE 10
#endif
#if   defined(QUEX_SETTING_BUFFER_LEXATOM_PATH_TERMINATION_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_PATH_TERMINATION QUEX_SETTING_BUFFER_LEXATOM_PATH_TERMINATION_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_PATH_TERMINATION_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_PATH_TERMINATION QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_PATH_TERMINATION_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_LEXATOM_PATH_TERMINATION 0x1
#endif
#if   defined(QUEX_SETTING_BUFFER_FALLBACK_N_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N QUEX_SETTING_BUFFER_FALLBACK_N_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N_EXT)
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_BUFFER_FALLBACK_N 0
#endif
#if   defined(QUEX_SETTING_FALLBACK_MANDATORY_EXT)
#   define QUEX_TestAnalyzer_SETTING_FALLBACK_MANDATORY QUEX_SETTING_FALLBACK_MANDATORY_EXT
#elif defined(QUEX_TestAnalyzer_SETTING_FALLBACK_MANDATORY_EXT)
#   define QUEX_TestAnalyzer_SETTING_FALLBACK_MANDATORY QUEX_TestAnalyzer_SETTING_FALLBACK_MANDATORY_EXT
#else
#   define QUEX_TestAnalyzer_SETTING_FALLBACK_MANDATORY false
#endif

/*______________________________________________________________________________
 * DERIVED SETTINGS                                                 -- IMMUTABLE
 *                                                                            */


/* Asserts are enabled by default. The lexer emits a warning message and tells
 * how to deactivate them. Asserts can be DEACTIVATED as follows.
 *
 *  'NDEBUG' (from Standard 'assert.h') => avoid surprises.
 *  'QUEX_OPTION_ASSERTS_DISABLED_EXT'  => solely prevent Quex's asserts.     
 *                                                                            */
#if defined(NDEBUG) 
#   ifdef     QUEX_OPTION_ASSERTS
#      warning "undef 'QUEX_OPTION_ASSERTS' by 'NDEBUG'"
#      undef  QUEX_OPTION_ASSERTS
#   endif
#elif defined(QUEX_OPTION_ASSERTS_DISABLED_EXT)
#   ifdef     QUEX_OPTION_ASSERTS
#      warning "undef 'QUEX_OPTION_ASSERTS' by 'QUEX_OPTION_ASSERTS_DISABLED_EXT'"
#      undef  QUEX_OPTION_ASSERTS
#   endif
#elif ! defined(QUEX_OPTION_ASSERTS)
#   define QUEX_OPTION_ASSERTS
#endif

/* Special Case MinGW: At the time of this writing (2009y09m23d) it does 
 * not support 'wchart_t'.                                                    */
#if (defined (__GLIBCPP__) || defined(__GLIBCXX__)) && ! defined  (_GLIBCXX_USE_WCHAR_T)
#   define  QUEX_OPTION_WCHAR_T_DISABLED_EXT
#endif

/* No external definition of QUEX_SETTING_USER_CLASS_DECLARATION_EPILOG_EXT
 * => define as empty.                                                        */
#ifndef   QUEX_SETTING_USER_CLASS_DECLARATION_EPILOG_EXT
#  define QUEX_SETTING_USER_CLASS_DECLARATION_EPILOG_EXT
#endif

#define QUEX_INDICATE_CONFIGURATION_FILE_PASSED
#endif /* QUEX_INCLUDE_GUARD_TestAnalyzer__ANALYZER__CONFIGURATION */