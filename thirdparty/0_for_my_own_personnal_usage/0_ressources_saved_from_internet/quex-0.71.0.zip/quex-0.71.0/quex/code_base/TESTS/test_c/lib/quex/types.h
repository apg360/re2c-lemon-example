/* PURPOSE: Definition of basic data types (integers, bool, sizes)
 *
 * For the standard reference, please review: "The Open Group Base 
 * Specifications Issue 6, IEEE Std 1003.1, 2004 Edition".
 *
 * (C) 2008-2019  Frank-Rene Schaefer                                         */           
#ifndef QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H
#define QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H

/* Boolean Values ("stdbool.h") ________________________________________________
 *                                                                            */

#if    (defined(__STDC_VERSION__) && __STDC_VERSION__ < 199901L) \
    || (defined(_MSC_VER)         && _MSC_VER < 1800) 

   /* Helper definition for the case that the compiler distribution does not
    * provide 'stdbool.h'.                                                    */
#  if ! defined(__bool_true_false_are_defined)
      typedef int _Bool;
#     define bool  _Bool
#     define true  ((_Bool)1)
#     define false ((_Bool)0)
#     define __bool_true_false_are_defined ((int)(1))
#  endif

#else
   /* Include fails => compiler distribution does not provide 'stdbool.h'.
    * Use helper definitions above (and report problem, so that special
    * case can be included in later versions of Quex).                        */
#  include <stdbool.h>
#endif



/* Integer Types ("stdint.h"/"inttypes.h") ____________________________________
 *                                                                           */

#if defined (_MSC_VER)
#include "test_c/lib/quex/compatibility/msc_stdint.h"
#elif defined(__BORLANDC__)
#include "test_c/lib/quex/compatibility/borland_stdint.h"
#elif defined(__sun) && defined(__sparc)

#   include <inttypes.h>  

#else

#   include <stdint.h>

#endif






#   include <stddef.h>




 typedef long           QUEX_TYPE_STREAM_POSITION;



#endif /* QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H                                   */

