/* PURPOSE: Definition of basic data types (integers, bool, sizes)
 *
 * For the standard reference, please review: "The Open Group Base 
 * Specifications Issue 6, IEEE Std 1003.1, 2004 Edition".
 *
 * (C) 2008-2019  Frank-Rene Schaefer                                         */           
#ifndef QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H
#define QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H

/* Boolean Values ("stdbool.h") ________________________________________________
 *                                                                            */



/* Integer Types ("stdint.h"/"inttypes.h") ____________________________________
 *                                                                           */
 extern "C" {
#if defined (_MSC_VER)
#include "test_cpp_emm/lib/quex/compatibility/msc_stdint.h"
#elif defined(__BORLANDC__)
#include "test_cpp_emm/lib/quex/compatibility/borland_stdint.h"
#elif defined(__sun) && defined(__sparc)

#   include <inttypes.h>  

#else

#   include <stdint.h>

#endif
 }




#   include <cstddef>






 #include <iostream>
 typedef std::streampos QUEX_TYPE_STREAM_POSITION;

#endif /* QUEX_INCLUDE_GUARD_LIB_QUEX__TYPES_H                                   */

