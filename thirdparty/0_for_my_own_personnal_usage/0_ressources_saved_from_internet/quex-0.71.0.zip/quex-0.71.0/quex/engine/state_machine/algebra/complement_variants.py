import quex.engine.state_machine.algorithm.beautifier as beautifier
from   copy import deepcopy

def tersest_not(Dfa):
    """RETURNS: Matches as soon as lexeme deviates from Dfa.

    Contrary to the algebraic 'not', this not does not eat until infinity
    upon deviation. 

    If 'Dfa' does not end with 'Any+', so the result won't.
    """
    assert Dfa.is_DFA_compliant()

    result = deepcopy(Dfa)

    accept_on_drop_out_si = result.create_new_state(AcceptanceF=True) 

    for state_index, state in Dfa.states.items():
        result_state = result.states[state_index]

        # drop-out --> transition to 'Accept-All' state.
        tm = state.target_map
        drop_out_trigger_set = tm.get_drop_out_trigger_set_union()
        if not drop_out_trigger_set.is_empty():
            result_state.add_transition(drop_out_trigger_set, 
                                        accept_on_drop_out_si)

        # All other transitions are forgotten in result

    # acceptance state --> non-acceptance state.
    for si in Dfa.acceptance_state_index_list():
        del result.states[si]

    # 'result.delete_hopeless_states()' is not enough.
    # There might be an acceptance state pending in the void.
    result.clean_up()
    return result.clone()

def prolix(Dfa):
    """RETURNS: Matches as long as lexeme stays on path of Dfa.
        
    The result is state machine equal to 'Dfa', only that all states but the
    initial state are acceptance states.

    The state machine matches any lexeme that may lie on a path to an
    acceptance state. In other words, if 'L' matches 'Dfa', then 'L[i]' matches
    the resulting state machine for all i=1...length(L).

    If 'Dfa' does not end with 'Any+', so the result won't.
    """
    result = Dfa.clone()
    for si, state in result.states.items():
        if si == result.init_state_index: continue
        state.set_acceptance(True)
    result.clean_up()
    return beautifier.do(result)

def inner_prolix(Dfa):
    """Matches everything that is matched by 'prolix' except for what is
    matched by 'Dfa'.
    -- never matches what is matched by 'Dfa'
    -- never steps over something matched by 'Dfa'

    'Nothing' becomes 'Empty'.
    """
    result = Dfa.clone()

    # non-acceptance states => acceptance states
    for si, state in result.states.items():
        state.set_acceptance(not state.is_acceptance())

    # remove any transition to a previous acceptance state
    result.clean_up()
    return result
