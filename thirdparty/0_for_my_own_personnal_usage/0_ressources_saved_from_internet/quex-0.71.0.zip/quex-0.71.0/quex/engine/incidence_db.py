from   quex.engine.misc.tools                import typed
from   quex.engine.analyzer.terminal.factory import TerminalFactory
import quex.engine.misc.error                as     error
from   quex.input.code.base                  import CodeFragment, \
                                                    SourceRef_DEFAULT
from   quex.input.code.core                  import CodeTerminal
from   quex.input.setup                      import NotificationDB
from   quex.blackboard import standard_incidence_db, \
                              standard_incidence_db_is_mandatory, \
                              standard_incidence_db_get_terminal_type, \
                              E_IncidenceIDs, \
                              Lng


class IncidenceDB(dict):
    """Database of CodeFragments related to 'incidences'.
    ---------------------------------------------------------------------------

                      incidence_id --> [ CodeFragment ]

    If the 'mode_option_info_db[option_name]' mentions that there can be 
    no multiple definitions or if the options can be overwritten than the 
    list of OptionSetting-s must be of length '1' or the list does not exist.

    ---------------------------------------------------------------------------
    """
    # When webbed into a state machine, certain incidences may not be changed, 
    # because their address is used all over the place.

    @staticmethod
    def from_BaseModeSequence(BaseModeSequence):
        """Collects the content of the 'incidence_db' member of this mode and
        its base modes. Incidence handlers can only defined ONCE in a mode
        hierarchy.

        RETURNS:      map:    incidence_id --> [ CodeFragment ]
        """
        def find_in_mode_hierarchy(BaseModeSequence, incidence_name):
            """Find incidence handler in the mode hierarchy. An incidence handler
            can only be defined once. If none is found 'None' is returned.
            """
            found      = None # Note on style: 'for-else' does not make sense,
            #                 # because multi-definitions need to be detected.
            found_mode = None
            for mode_descr in BaseModeSequence:
                code_fragment = mode_descr.incidence_db.get(incidence_name)
                if code_fragment is None:         
                    continue
                elif found is not None:
                    error.warning("Handler '%s' in mode '%s' overwrites previous in mode '%s'." \
                                  % (incidence_name, mode_descr.name, found_mode), code_fragment.sr,
                                  SuppressCode=NotificationDB.warning_incidence_handler_overwrite)
                found      = code_fragment
                found_mode = mode_descr.name
            return found

        assert len(BaseModeSequence) > 0
        mode_name = BaseModeSequence[-1].name
        result    = IncidenceDB()

        # Collect all possible incidence handlers.
        for incidence_name, info in standard_incidence_db.items():

            # (1) Find handler definition in base mode sequence
            code = find_in_mode_hierarchy(BaseModeSequence, incidence_name)

            # (2) Add default handler for undefined mandatory handlers
            incidence_id, comment = info
            if code is None and standard_incidence_db_is_mandatory(incidence_id): 
                code = IncidenceDB.__default_code_fragment(incidence_id, mode_name)

            # (3) Add incidence handler to result database
            if code is None: continue

            IncidenceDB.__insert_raise_error_flag_in_front_if_relevant(incidence_id, code)

            result[incidence_id] = code

        return result

    def __setitem__(self, Key, Value):
        dict.__setitem__(self, Key, Value)

    @staticmethod
    def __insert_raise_error_flag_in_front_if_relevant(IncidenceId, code_fragment):
        """Modifies 'code_fragment' so that the error flag is always raised, even
           if the user might have missed to set it.
        """
        if   IncidenceId == E_IncidenceIDs.END_OF_STREAM: return
        elif not IncidenceId in Lng.error_code_db:        return
        code_fragment.get_pure_code().insert(0,
            Lng.RAISE_ERROR_FLAG(Lng.error_code_db[IncidenceId])
        )

    @staticmethod
    def __default_code_fragment(IncidenceId, ModeName):
        code = [
            "%s\n" % Lng.TOKEN_SEND("QUEX_SETTING_TOKEN_ID_TERMINATION"),
            '%s\n' % Lng.PURE_RETURN
        ]
        return CodeFragment(code, SourceRef_DEFAULT)

    @typed(factory=TerminalFactory)
    def extract_terminal_db(self, factory, ReloadRequiredF):
        """SpecialTerminals: END_OF_STREAM
                             FAILURE
                             BAD_LEXATOM
                             ...
        """
        result = {}
        for incidence_id, code_fragment in self.items():
            terminal_type = standard_incidence_db_get_terminal_type(incidence_id)
            if terminal_type is None:
                continue
            elif     incidence_id == E_IncidenceIDs.END_OF_STREAM \
                 and not ReloadRequiredF:
                continue
            code_terminal = CodeTerminal.from_CodeFragment(code_fragment)
            assert terminal_type not in result
            terminal = factory.do(terminal_type, code_terminal)
            terminal.set_incidence_id(incidence_id)
            result[incidence_id] = terminal

        return result

    def get_CodeTerminal(self, IncidenceId):
        """TODO: RETURN [0] code
                        [1] LexemeBeginF required
                        [2] LexemeTerminatingZeroF required
        """

        if IncidenceId not in self: return CodeTerminal([""])

        return CodeTerminal.from_CodeFragment(self[IncidenceId]) 

    def get_text(self, IncidenceId):
        code_fragment = self.get(IncidenceId)
        if code_fragment is None: return ""
        else:                     return "".join(code_fragment.get_code())


