#! /usr/bin/env python
"""SPDX license identifier: MIT; Project 'http://quex.sf.net';
   (C) Frank-Rene Schaefer
"""
import quex.engine.misc.error                   as     error
from   quex.engine.misc.file_operations         import open_file_or_die
from   quex.engine.misc.file_in                 import EndOfStreamException, \
                                                       check, \
                                                       check_end_of_file, \
                                                       parse_identifier_assignment, \
                                                       read_identifier, \
                                                       read_integer, \
                                                       skip_whitespace
import quex.input.files.mode                    as     mode
import quex.input.files.section_define          as     section_define
import quex.input.files.token_type              as     token_type
import quex.input.files.code_fragment           as     code_fragment
from   quex.input.setup                         import NotificationDB
from   quex.output.token.id_generator           import token_id_db_enter, prepare_default_standard_token_ids
from   quex.input.code.base                     import SourceRef
from   quex.input.code.core                     import CodeUser
from   quex.blackboard                          import setup as Setup, Lng
import quex.blackboard                          as     blackboard
import quex.token_db                            as     token_db
from   quex.input.regular_expression.exception  import RegularExpressionException

def do(file_list):
    if not file_list and not (Setup.token_class_only_f or Setup.converter_only_f): 
        error.log("No input files.")

    mode_prep_prep_db = {} # mode name --> Mode_PrepPrep object
    #                      # later: Mode_PrepPrep is transformed into Mode objects.

    # If a foreign token-id file was presented even the standard token ids
    # must be defined there.
    if not Setup.extern_token_id_file:
        prepare_default_standard_token_ids()

    for file_name in file_list:
        error.insight("File '%s'" % file_name)
        fh = open_file_or_die(file_name, CodecCheckF=True, Encoding="utf-8-sig")

        # Read all modes until end of file
        try:
            while 1 + 1 == 2:
                parse_section(fh, mode_prep_prep_db)
        except EndOfStreamException:
            pass # ... next, please!
        except RegularExpressionException as x:
            error.log(x.message, fh)
        
    if token_db.token_type_definition is None:
        _parse_default_token_definition(mode_prep_prep_db)

    _token_consistency_check()

    if mode_prep_prep_db: return mode_prep_prep_db 
    else:                 return dict()

def parse_section(fh, mode_prep_prep_db, CustomizedTokenTypeF=True):
    position = fh.tell()
    word     = ""
    try:
        skip_whitespace(fh)
        word = read_identifier(fh)
        if not word: 
            _check_stream_issues(fh)
        else:
            _parse_section(fh, position, word, mode_prep_prep_db, CustomizedTokenTypeF)

    except UnicodeDecodeError as x:
        if x.start == 0: extra_str = " (Probably wrong byte order mark)."
        else:            extra_str = "."
        error.log("Quex requires ASCII or UTF8 input character format.\n" \
                  "Found encoding error at position '%s'%s" % (x.start, extra_str), fh)

    except EndOfStreamException as x:
        fh.seek(position)
        if word: error.error_eof(word, fh)
        else:    raise x

def _parse_section(fh, position, section_name, mode_prep_prep_db, CustomizedTokenTypeF):
    """  -- 'mode { ... }'        => define a mode
         -- 'start = ...;'        => define the name of the initial mode
         -- 'header { ... }'      => define code that is to be pasted on top
                                     of the engine (e.g. "#include<...>")
         -- 'body { ... }'        => define code that is to be pasted in the class' body
                                     of the engine (e.g. "public: int  my_member;")
         -- 'constructor { ... }' => define code that is to be pasted in the class' constructor
                                     of the engine (e.g. "my_member = -1;")
         -- 'destructor { ... }'  => define code that is to be pasted in the class' destructor
                                     of the engine (e.g. "my_member = -1;")
         -- 'print { ... }'       => define code that is to be pasted in the class' print function.
                                     of the engine (e.g. "my_member = -1;")
         -- 'define { ... }'      => define patterns shorthands such as IDENTIFIER for [a-z]+
         -- 'token { ... }'       => define token ids
         -- 'token_type { ... }'  => define a customized token type
    """ 
    # End of File is supposed to be reached when trying to read a new section. 
    # => end-of-file catcher does not encompass the beginning.

    error.verify_word_in_list(section_name, blackboard.all_section_title_list, 
                              "Unknown quex section '%s'" % section_name, fh)

    if section_name in list(blackboard.fragment_db.keys()):
        element_name = blackboard.fragment_db[section_name]
        fragment     = code_fragment.parse(fh, section_name, AllowBriefTokenSenderF=False)        
        blackboard.__dict__[element_name] = fragment
        return

    elif section_name == "init":
        error.log("Section 'init' is no longer supported.\n"
                  "Keyword 'constructor' is provided instead.\n"
                  "Use 'destructor' to define destructor code.\n", fh)

    elif section_name == "repeated_token":
        error.log("Section 'repeated_token' is no longer supported.\n"
                  "specify '\\repeatable' after a token definition in section 'token' to\n"
                  "to allow implicit repetitions of its kind.\n"
                  "\n"
                  "EXAMPLE: token {\n"
                  "            TOKEN_A = 4711 \\repeatable;\n"
                  "            TOKEN_B        \\repeatable;\n"
                  "         }\n", fh)

    elif section_name == "start":
        mode_name = parse_identifier_assignment(fh)
        if mode_name == "":
            error.log("Missing mode_name after 'start ='", fh)

        elif not blackboard.initial_mode.sr.is_void():
            error.log("start mode defined more than once!", fh, DontExitF=True)
            error.log("previously defined here", blackboard.initial_mode.sr)
         
        blackboard.initial_mode = CodeUser(mode_name, SourceRef.from_FileHandle(fh))
        return

    elif section_name == "define":
        section_define.parse(fh)
        error.insight("Section '%s'" % section_name)
        return

    elif section_name == "token":       
        parse_token_id_definitions(fh)
        return

    elif section_name == "token_type":       
        token_type.do(fh, mode_prep_prep_db, CustomizedTokenTypeF)
        return

    elif section_name == "mode":
        # When the first mode is parsed, a token_type definition must be 
        # present. If not, the default token type definition is considered.
        if token_db.token_type_definition is None:
            _parse_default_token_definition(mode_prep_prep_db)

        mode.parse(fh, mode_prep_prep_db)
        return

    else:
        # This case should have been caught by the 'verify_word_in_list' function
        assert False

def parse_token_id_definitions(fh, NamesOnlyF=False):
    """NamesOnlyF == True: Allow only definition of names, no numeric values 
                           may be assigned to it.

       'NamesOnlyF' indicates that data is not written to the global 
       'token_id_db'. Then only a list of names is returned.
    """
    # NOTE: Catching of EOF happens in caller: parse_section(...)
    #
    prefix       = Setup.token_id_prefix
    prefix_plain = Setup.token_id_prefix_plain # i.e. without name space included
    def _check_suspicious_prefix(candidate, fh):
        suspicious_prefix = None
        if prefix and candidate.startswith(prefix):       
            suspicious_prefix = prefix
        elif prefix_plain and candidate.startswith(prefix_plain): 
            suspicious_prefix = prefix_plain
        if suspicious_prefix is None: return
        error.warning("Token identifier '%s' starts with token prefix '%s'.\n" \
                  % (candidate, suspicious_prefix) \
                  + "Token prefix is mounted automatically. This token id appears in the source\n" \
                  + "code as '%s%s'." \
                  % (prefix, candidate), \
                  fh, 
                  SuppressCode=NotificationDB.warning_token_id_prefix_appears_in_token_id_name)

    if NamesOnlyF: 
        result = set()

    skip_whitespace(fh)
    if not check(fh, "{"):
        error.log("Missing opening '{' for after 'token' section identifier.", 
                  fh)

    while check(fh, "}") == False:
        skip_whitespace(fh)

        candidate = read_identifier(fh, TolerantF=True, OnMissingStr="Missing valid token identifier.")

        _check_suspicious_prefix(candidate, fh)

        skip_whitespace(fh)

        if NamesOnlyF:
            result.add(prefix + candidate)
            if check(fh, ";") == False:
                error.log("Missing ';' after token identifier '%s'.\n" \
                          % candidate, fh)
            continue

        # Parse a possible numeric value after '='
        numeric_value = None
        if check(fh, "="):
            skip_whitespace(fh)
            numeric_value = read_integer(fh)
            if numeric_value is None:
                error.log("Missing number after '=' for token identifier '%s'." % candidate, 
                          fh)

        repeatable_f = False
        if check(fh, "\\"):
            option_name = read_identifier(fh, TolerantF=True, OnMissingStr="Missing 'option name' after '\\'.")
            if option_name != "repeatable":
                error.log("The option allowed in token definitions is '\\repeatable'; found '%s'.\n" % option_name, fh)
            repeatable_f = True

        if check(fh, ";") == False:
            error.log("Missing ';' after token identifier '%s'." % candidate, 
                      fh)

        if Setup.extern_token_id_file and (not repeatable_f or numeric_value):
            error.log("Section 'token' while token id file '%s' has also been specified.\n" \
                      % Setup.extern_token_id_file \
                      + "In that case, the only thing to be specified for a token-id in 'token'\n"
                      + "is '\\repeatable', i.e. that it is admissible to repeat it.", fh)

        if not NamesOnlyF:
            token_id_db_enter(fh, candidate, numeric_value) 

        if repeatable_f:
            token_db.token_repetition_token_id_list.append(candidate)
            if token_db.token_repetition_source_reference_example is None:
                token_db.token_repetition_source_reference_example = SourceRef.from_FileHandle(fh)

    if NamesOnlyF:
        return sorted(list(result))
    else:
        return # Changes are applied to 'token_db.token_id_db'

def _parse_default_token_definition(mode_prep_prep_db):
    sub_fh = Lng.open_template_fh(Lng.token_default_file())
    parse_section(sub_fh, mode_prep_prep_db, CustomizedTokenTypeF=False)
    sub_fh.close()
    token_type.command_line_settings_overwrite(CustomizedTokenTypeF=False)

def _token_consistency_check():
    if not token_db.token_repetition_token_id_list: 
        return
    elif token_db.support_repetition():
        return

    hint = ""
    if Setup.extern_token_class_file:
        hint = " (possibly specify '--token-repetition-n-member-name')"
    error.log("Token with option '\\repeatable' defined, but current token class does not\n"
              "support implicit token repetition%s." % hint, token_db.token_repetition_source_reference_example)

def _check_stream_issues(fh):
    position = fh.tell()
    content  = fh.read()
    if content.count('\0') > 1:
        error.log("Quex requires ASCII or UTF8 input character format.\n" \
                  "File contains one or more '0' characters. Is it UTF16/UTF32 encoded?.", fh)
    fh.seek(position)

    if check_end_of_file(fh):
        raise EndOfStreamException()
    elif fh.tell() != 0:
        error.log("Missing section title", fh)

