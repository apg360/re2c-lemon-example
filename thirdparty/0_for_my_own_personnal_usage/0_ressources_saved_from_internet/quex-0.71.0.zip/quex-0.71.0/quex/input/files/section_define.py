from   quex.engine.misc.tools                   import iterator_N_slots_with_setting_db
import quex.engine.misc.error                   as     error
from   quex.engine.misc.file_operations         import open_file_or_die
from   quex.engine.misc.file_in                 import optional_flags, \
                                                       read_until_whitespace, \
                                                       read_until_character, \
                                                       check, \
                                                       read_identifier, \
                                                       skip_whitespace, \
                                                       EndOfStreamException
import quex.input.regular_expression.core       as     regular_expression
from   quex.input.regular_expression.macro      import PatternShorthand, \
                                                       MacroCall
from   quex.input.code.base                     import SourceRef
import quex.blackboard                          as     blackboard
from   quex.constants                           import DEFINE_SECTION_COMMAND_SET
from   quex.output.syntax_elements              import Signature

def parse(fh):
    """Parses pattern definitions of the form:
   
          WHITESPACE  [ \t\n]
          IDENTIFIER  [a-zA-Z0-9]+
          OP_PLUS     "+"

          \macro SOMETHING(sm = X, set = Y, number = N):
          
       That means: 'name' whitespace 'regular expression' whitespace newline.
       Comments can only be '//' nothing else and they have to appear at the
       beginning of the line.

       One regular expression can have more than one name, but one name can 
       only have one regular expression.
    """
    command_db = {
        "\\macro": _parse_macro,
        "\\plot":  _parse_plot,
        "\\run":   _parse_run
    }
    assert set(command_db.keys()) == DEFINE_SECTION_COMMAND_SET

    if not check(fh, "{"):
        error.log("define region must start with opening '{'.", fh)

    while 1 + 1 == 2:
        if check(fh, "}"): 
            return
        
        skip_whitespace(fh)
        # Get the name of the pattern
        for command, parse_function in command_db.items():
            if check(fh, command):
                name, value = parse_function(fh)
                break
        else:
            name, value = _parse_shorthand(fh)

        if name is None: continue

        ## print "#DONE"
        blackboard.shorthand_db[name] = value
        ## print "#shorthand_db:", id(shorthand_db), shorthand_db

def _parse_plot(fh):
    PatternDict = blackboard.shorthand_db

    sr = SourceRef.from_FileHandle(fh)

    flags = optional_flags(fh, "brief pattern action pair list", "h", 
                           {"h": "(default) hexadecimal values",
                            "d": "decimal values",
                            "c": "unicode characters",
                            "s": "(default) print shortcut to file with same name + \".dot\"",
                            "f": "plot expression to file (name to follow)",
                           },
                           BadCombinationList=["hdc", "sf"])

    skip_whitespace(fh)
    if "f" in flags:
        pos = fh.tell()
        file_name = read_until_whitespace(fh)

        if not file_name:
            error.log("Missing file name after '\plot' (option 'f' for filename).", sr)

        skip_whitespace(fh)
        pattern = regular_expression.parse(fh, 
                                           Name="\\plot",
                                           AllowAcceptanceOnNothingF = True,
                                           AllowPreContextF=False,
                                           AllowPostContextF=False) 
        if not pattern: dfa = None
        else:           dfa = pattern.extract_sm()

    else:
        identifier = read_identifier(fh)
        if not identifier:
            error.log("Missing identifier following '\\plot'.", sr)
        file_name  = "%s.dot" % identifier

        reference = PatternDict.get(identifier)
        if not reference:
            error.log("Dfa '%s' has not been defined yet." % identifier, sr)

        dfa = reference.get_DFA()

    if dfa is None:
        fh.seek(pos)
        error.log("Expression did not result in DFA.", fh)

    if "h" in flags:
        Option = "hex"
    elif "d" in flags:
        Option = "dec"
    else:
        Option = "utf8"

    txt = dfa.get_graphviz_string(NormalizeF=True, Option=Option)

    fh = open_file_or_die(file_name, "wb")
    fh.write(txt)
    fh.close()

    error.note("plot (%s) to file '%s'." % (flags, file_name), sr)

    return None, None

def _parse_macro(fh):
    signature_str = read_until_character(fh, ":").strip()
    if not signature_str: 
        error.log("Missing signature for macro definition.\n"
                  "(Possibly misplaced ':').", fh)
   
    signature = Signature.from_String(signature_str)
    for arg in signature.argument_list:
        if not arg.name:
            error.log("Missing argument name in macro defitions.", fh)

    pos = fh.tell()
    reference_sr = SourceRef.from_FileHandle(fh)
    try:
        skip_whitespace(fh) #, ExceptNewlineF=True)
        # The function body remains a string until it is parsed at expansion time.
        function_body = read_until_character(fh, "\n").strip()
        name          = signature.function_name
        value         = MacroCall(signature.argument_list,
                                  function_body, 
                                  reference_sr)
    except EndOfStreamException:
        fh.seek(pos)
        error.log("End of stream reached while parsing '%s' in 'define' section.",
                  fh)

    return name, PatternShorthand(name, value, SourceRef.from_FileHandle(fh), 
                                  signature.function_name)

def _parse_run(fh):
    sr = SourceRef.from_FileHandle(fh)
    skip_whitespace(fh)
    pattern = regular_expression.parse(fh, 
                                       Name="\\run",
                                       AllowAcceptanceOnNothingF = True,
                                       AllowPreContextF=False,
                                       AllowPostContextF=False) 
    if not pattern: 
        error.log("\\run command: first argument missing: the DFA (1st argument)", sr)

    dfa        = pattern.extract_sm()
    dfa_string = pattern.pattern_string()

    # Let the sequences list be given by a DFA
    skip_whitespace(fh)
    pattern = regular_expression.parse(fh, 
                                       Name="\\run",
                                       AllowAcceptanceOnNothingF = True,
                                       AllowPreContextF=False,
                                       AllowPostContextF=False) 

    if not pattern: 
        error.log("\\run command: missing test sequence description (2nd argument).", sr)

    tsql_dfa = pattern.extract_sm()
    if tsql_dfa.has_cycles(): 
        error.error("DFA to describe test sequence list contains loop.\n"
                    "This would result in an infinite number of test sequences.",
                    fh)

    def _plug(PlugPositions, PlugSettings, Sequence):
        result = [x for x in Sequence] # Clone 'Sequence'
        for i in PlugPositions:
            result[i] = PlugSettings[i]
        return result

    def _expand(RawTestSequence):
        fine_raw_sequence = []
        for step in RawTestSequence:
            if step.has_size_one(): value = step.get_the_only_element()
            else:                   value = None
            fine_raw_sequence.append(value)

        plug_positions = [
            i for i, step in enumerate(fine_raw_sequence) if step is None
        ]
        if not plug_positions:
            yield fine_raw_sequence
            return

        plug_setting_db = [
            RawTestSequence[i].get_number_list() for i in plug_positions
        ]
        for plug_settings in iterator_N_slots_with_setting_db(plug_setting_db):
            yield _plug(plug_positions, plug_settings, fine_raw_sequence)

    test_sequence_list = []
    for raw_sequence in [p for p in tsql_dfa.iterable_paths(1)]:
        test_sequence_with_NumberSet = [step[1] for step in raw_sequence[1:]]
        for test_sequence in _expand(test_sequence_with_NumberSet):
            test_sequence_list.append(test_sequence)

    error.note("run on '%s'" % dfa_string, sr)
    error.note(" ", sr)
    for test_sequence in sorted(test_sequence_list):
        _perform_run(dfa, test_sequence, sr)
    error.note(" ", sr)
    error.note("run <terminated>", sr)
    return None, None

def _perform_run(dfa, TestSeq, sr):
    """Print test sequence, step along and show where acceptance
       happened, and where the analysis stopped.
    """
    if not TestSeq: 
       error.note("  <empty test sequence>", sr)
       return

    state = dfa.get_init_state()
    last_acceptance_step_i = -1
    if state.is_acceptance(): 
        last_acceptance_step_i = 0
    for i, x in enumerate(TestSeq, start=1):
        next_si = state.target_map.get_resulting_target_state_index(x)
        if not next_si: break
        state = dfa.states[next_si]
        if state.is_acceptance(): 
            last_acceptance_step_i = i

    def marker(k):
        if k == last_acceptance_step_i: return "A"
        elif k == i:                    return "^"
        else:                           return " "

    test_sequence_txt = "".join(eval("u'\\U%08X'" % c) for c in TestSeq)
    error.note("  " + "|" + "|".join(x for x in test_sequence_txt) + "|", sr)
    error.note("  " + " ".join("%s" % marker(k) for k in range(len(test_sequence_txt)+1)), sr)

def _parse_shorthand(fh):
    skip_whitespace(fh)
    name = read_identifier(fh, 
                           OnMissingStr="Missing identifier in 'define' section.")

    if name in blackboard.shorthand_db:
        error.log("Second definition of pattern '%s'.\n" % name + \
                  "Pattern names must be unique.", fh)

    pos = fh.tell()
    try:
        if check(fh, "}", SkipWhitespaceExceptNewlineF=True): 
            error.log("Missing regular expression for pattern definition '%s'." % \
                      name, fh)

        skip_whitespace(fh)
        pattern = regular_expression.parse(fh, 
                                           Name="define",
                                           AllowAcceptanceOnNothingF = True,
                                           AllowPreContextF=False,
                                           AllowPostContextF=False) 

    except EndOfStreamException:
        fh.seek(pos)
        error.log("End of stream reached while parsing '%s' in 'define' section.",
                  fh)

    state_machine = pattern.extract_sm()

    value = PatternShorthand(name, state_machine, SourceRef.from_FileHandle(fh), 
                             pattern.pattern_string())

    return name, value


