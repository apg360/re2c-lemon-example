// for mmap(2)
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

// in parameter: filename
// out parameters: start and end of bytes in memory
void memorymap_file(char *file, char **start, char **lastchar)
{
  struct stat stat_buff;
  int ret = stat(file,&stat_buff);
  if(ret == -1)
    {
      fail("Error: stat(2) failed for file '%s'\n",file);
    }
  size_t file_size = (size_t) stat_buff.st_size;

  // mmap(2) the file into memory
  int fd = open(file,O_RDONLY);
  if(fd == -1)
    {
      fail("Error: open(2) failed for file %s\n",file);
    }

  *start = mmap(NULL,           // Any location in memory is fine
                file_size,      // Length of the file
                PROT_READ,      // Let us read the file
                MAP_PRIVATE,    // We don't need to share this
                fd,             // Our file descriptor
                0);             // Start at the beginning
  *lastchar = *start + file_size;

  close(fd);                    // Apparently this is fine; look at man mmap(2)
  
  return;
}
