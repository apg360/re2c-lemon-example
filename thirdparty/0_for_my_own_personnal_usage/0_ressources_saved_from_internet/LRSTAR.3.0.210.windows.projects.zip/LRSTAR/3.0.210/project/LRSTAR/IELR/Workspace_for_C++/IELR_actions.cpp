
/* Original source code by Compilerware with tabs = 3 */

		#include "IELR_main.h"
  		#include "IELR_actions.h"          

#ifdef TOKEN_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    error     																				  //

int   Typedef_TokenAction::error (short t)                     
{
	// Illegal character?
		if (token.end == token.start) 
		{
			token.end++;
			return (t); // Return zero (t should be zero).
		}
	// Do a symbol table lookup.
	// Could be a valid keyword or constant from an ambiguous grammar.
		return (lookup (t)); 
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    lookup    																				  //

int   Typedef_TokenAction::lookup (short t) // Look for Symbol.
{
//		int a = tact_arg[t];
		token.sti = add_symbol (t, token.start, token.end); 
		return (symbol[token.sti].term); // This works for {typedef}
}

#endif
#ifdef PARSE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    defterm   																				  //

short Typedef_ParseAction::defterm (short p) 
{
	   short i = pact_arg[p];				   // Get first argument index.
      short sti = PS [arg_numb[i]-1].sti; // Get sti for first argument.
      symbol[sti].term = arg_numb [i+1];  // Set term to second argument.
      return (0);
}

#endif
#ifdef NODE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    goal_ (not used, for testing only)												  //

short Typedef_ASTAction::goal_ (int n)
{
		return (0);
}

#endif

/*--- End of Actions. -------------------------------------------------------*/

























