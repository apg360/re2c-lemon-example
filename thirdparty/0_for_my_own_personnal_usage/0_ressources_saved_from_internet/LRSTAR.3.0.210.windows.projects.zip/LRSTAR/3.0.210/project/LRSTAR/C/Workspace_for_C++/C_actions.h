
/* Original source code by Compilerware with tabs = 3 */

#ifndef cActions_H
#define cActions_H

		#include "C_parser.h"

#ifdef TOKEN_ACTIONS

		class C_TokenAction : public C_parser
		{
			public:	
         static int error  (short terminal_number);
         static int lookup (short terminal_number);
		};

#endif
#ifdef PARSE_ACTIONS

		class C_ParseAction : public C_parser
		{
			public:	
			static short defterm     (short prod_number); 
			static short goal_       (short prod_number); 
		};

#endif
#ifdef NODE_ACTIONS

		class C_NodeAction : public C_parser
		{
			public:		
			static short goal_      (int node_number);
		};

#endif
#endif
