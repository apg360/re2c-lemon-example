  
/* Original source code by Compilerware with tabs = 3 */


		#define MAIN
      #include "Calc1_main.h"          
      #include "Calc1_parser.h"    

		#define WAIT_ON_KEY

		#ifdef WAIT_ON_KEY
  		#include "conio.h"
		#endif																						 

		char* Input::input_start;    // First byte of input area.              
		char* Input::input_end;      // Byte after input.                      
		char* Input::filename;       // Filename of input file.
		int   Input::filedesc;		 
		int   Input::filesize;

		char  Output::filename[];    // Filename of output file.
		FILE* Output::filedesc;      // File descriptor.

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    main     																				  //

int   main (int na, char *arg[])
{
      int t, time1, time2, thou, sec, nlps, nl, rc;
   
   // Initializations ...
		rc = 0;
		nl = 0;
		Calc1_parser Calc1_parser (10000, 100000);	// Create Parser Object.
		if (!Option.init (na, arg)) { rc = 1; goto Ret; }
		if (!Input.init  (arg[1]) ) { rc = 2; goto Ret; }
		if (!Output.init (arg[1]) ) { rc = 3; goto Ret; }
		
   // Parsing ...
	   time1 = clock();	// Get start time.
		printf  (                 "\nCalc1_parser\n");
		fprintf (Output.filedesc, "\nCalc1_parser\n");
		printf  (                 "Parsing %s ...\n\n", Input.filename);
		fprintf (Output.filedesc, "Parsing %s ...\n\n", Input.filename);
		for (int i = 0; i < 1; i++)
		{
			int n = Calc1_parser.parse (Input.input_start);
			if (n <= 0) 
			{
				nl -= n;
				break;
			}
			nl += n;
		}
		Calc1_parser.parse_term();

	// Compute time used ...
		time2 = clock (); // Get end time.
		t = time2 - time1;
		if (t == 0) t = 1;
		nlps = CLOCKS_PER_SEC * (nl/t);
      thou = t * 1000 / CLOCKS_PER_SEC;
      sec  = thou / 1000;
      thou -= sec * 1000;

	// Print results ...
      printf  ("%6d.%03ld seconds.\n", sec, thou);
      printf  ("%10s lines per second.\n\n", number(nlps));

   // Terminations ...
		Input.term  ();
		Output.term ();

Ret:
		#ifdef WAIT_ON_KEY
   // Wait until key is pressed ...
	  	printf( "Press any key to continue ...\n");
	  	while( !_kbhit() );
		#endif
		return rc;
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    init - initialization.     														  //

int   Option::init (int na, char* arg[])
{
      if (na < 2)
      {
         printf ("\nCalc1_parser\n\n");
         printf ("parse <filename>\n");
         printf ("\n");
			return 0;
      }    
		return 1;
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    init - initialization of input.													  //

int   Input::init (char* fn)
{
      int  nb;												// Number of bytes read.
		filename = fn;
		filedesc = _open (filename, 0);           // Open the file.             
		if (filedesc < 0)                         // If open error.             
		{
			printf ("File %s not found.\n", filename);
			return 0;
		}
		filesize = _filelength (filedesc);				// Get filesize.             
		input_start = new char [filesize+6];			// Get some RAM space.       
		*input_start++ = '\n';								// Put <eol> at beginning. 
		
      nb = _read (filedesc, input_start, filesize);	// Read size bytes into buffer. 
      if (nb <= 0)												// If read error.               
      {
         printf ("Read error on file %s.\n", filename);
         return 0;
      }
      input_end = input_start + nb;				// Set end-of-buffer pointer.         
      *input_end++ = EOL_CHAR;					// Put end-of-line here.
      *input_end++ = EOF_CHAR;					// Put first <eof> here.
      *input_end++ = EOF_CHAR;					// Put second <eof> here. 
      *input_end++ = EOL_CHAR;					// Put end-of-line here.
      *input_end++ = 0;								// Put zero byte here. 
      _close (filedesc);							// Close file.                        

		return 1;
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    term - termination of input. 														  //

void  Input::term ()
{
		input_start--;
  		delete [] input_start;                  
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    init - initialization.     														  //

int   Output::init (char* fn)
{
		strcpy (filename, fn);        
		strcat (filename, ".txt"); 
		filedesc = fopen (filename, "w");  

      if (filedesc == NULL)
      {
         printf ("\n\nOutput file %s cannot be created.\n\n", filename);
         return 0;
      }
		return 1;
}
                                        
///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    term - termination.         														  //

void  Output::term ()
{
		printf ("Created %s ...\n", filename);
		fprintf (filedesc, "End of Output.\n");
      fclose (filedesc);  
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    number																					  //

char* number (int x)
{
		int i, j, k;
		char buff[16];
		static char string[12] = "           ";

		_itoa (x, buff, 10);
		k = strlen (buff);
		i = k + (k-1)/3;
		string[i--] = 0;
		j = 0;
		while (1)
		{
			string[i--] = buff[--k];
			if (i < 0) break;
			if (++j % 3 == 0) string[i--] = ',';
		}
		return (string);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    quit     																				  //

void  quit ()
{
		#ifdef WAIT_ON_KEY
   // Wait until key is pressed ...
	  	printf( "Press any key to continue ...\n");
	  	while( !_kbhit() );
		#endif
		exit (0);
}

/*--- End of Main Program. --------------------------------------------------*/

