
/* Original source code by Compilerware with tabs = 3 */

#ifndef cActions_H
#define cActions_H

		#include "Typedef_parser.h"

#ifdef TOKEN_ACTIONS
		class Typedef_TokenAction : public Typedef_parser
		{
			public:	
         static int   error       (short terminal_number);
         static int   lookup      (short terminal_number);
		};

#endif
#ifdef PARSE_ACTIONS
		class Typedef_ParseAction : public Typedef_parser
		{
			public:	
			static short defterm     (short prod_number); 
		};

#endif
#ifdef NODE_ACTIONS
		class Typedef_ASTAction : public Typedef_parser
		{
			public:		
			static short goal_      (int node_number);
		};

#endif
#endif
