
/* Source code by Compilerware with tabs = 3 */

#ifndef cActions_H
#define cActions_H

#ifdef TOKEN_ACTIONS
																									   
		class Calc_TokenAction : public Calc_parser
		{
			public:	
			static int goal_       (short); 
			static int defterm     (short); 
			static int delete_tree (short); 
			static int stack       (short); 
         static int error       (short);
         static int lookup      (short);
		};
#endif
#ifdef PARSE_ACTIONS

		class Calc_ParseAction : public Calc_parser
		{
			public:	
			static short goal_       (short); 
			static short is_head     (short); 
			static short defterm     (short); 
			static short delete_tree (short); 
			static short stack       (short); 
         static short error       (short);
         static short lookup      (short);
		};
#endif
#ifdef NODE_ACTIONS

		class Calc_NodeAction : public Calc_parser
		{
			public:		
         static short goal_     (int);
         static short program_  (int);
         static short store_    (int);
         static short if_       (int);
         static short target_   (int);
         static short add_      (int);
         static short sub_      (int);
         static short mul_      (int);
         static short div_      (int);
         static short ident_    (int);
         static short int_      (int);
         static short eq_       (int);
         static short ne_       (int);
         static short then_     (int);
         static short else_     (int);
         static short then2_    (int);
         static short else2_    (int);
         static short emit      (int);
		};

#endif

#endif

