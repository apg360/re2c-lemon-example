
/* Source code by Compilerware with tabs = 3 */

#include "Calc_main.h"
#include "Calc_parser.h"
#include "Calc_actions.h"

#ifdef TOKEN_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    error     																				  //

int   Calc_TokenAction::error (short t)                    
{
	// Illegal character?
		if (token.end == token.start) 
		{
			token.end++;
			return (t); // Return zero (t should be zero).
		}
	// Do a symbol table lookup.
	// Could be a valid keyword or constant from an ambiguous grammar.
      return (lookup (t)); 
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    lookup    																				  //

int   Calc_TokenAction::lookup (short t) // Look for Symbol.
{
		token.sti = add_symbol (t, token.start, token.end); 
      return (symbol[token.sti].term); // This works for {typedef}
}

#endif
#ifdef PARSE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    goal_

short Calc_ParseAction::goal_ (short p)                    
{
	//	int a = pact_arg [p]; // Get first parse action argument.
 		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    defterm   																				  //

short Typedef_ParseAction::defterm (short p) 
{
	   short i = pact_arg[p];				   // Get first argument index.
      short sti = PS [arg_numb[i]-1].sti; // Get sti for first argument.
      symbol[sti].term = arg_numb [i+1];  // Set term to second argument.
      return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    delete_tree																				  //

short Calc_ParseAction::delete_tree (short p)
{
      n_nodes--;                          // Get last node created.
      while (node[n_nodes].child > 0)     // While not leaf.      
      {
         n_nodes = node[n_nodes].child;   // Down to first node.  
      }                                 
      if (n_nodes == 1) root = 1;         // If AST is gone.     
      PS->node = 0;                       // Set *PS to 0.        
      return (0);
}  

#endif
#ifdef NODE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::add_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tADD\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::div_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tDIV\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::then_ (int n)
{												
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tBR NZ endif&1\nthen&1:\n"); break;						
			case PASS_OVER: break;
			case BOTTOM_UP: break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::else_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tBR Z endif&1 \nelse&1:\n"); break;
			case PASS_OVER: break;
			case BOTTOM_UP: break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::then2_ (int n)
{												
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tBR NZ else&1 \nthen&1:\n"); break;
			case PASS_OVER: break;
			case BOTTOM_UP: break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::else2_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tBR endif&1   \nelse&1:\n"); break;
			case PASS_OVER: break;
			case BOTTOM_UP: break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::eq_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tEQ\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::ne_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tNE\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::goal_ (int n)
{
	//	int a = nact_arg [node[n].prod]; // Get first node action argument.
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tSTART\n"); break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tEOF\n"); break;
		}
      return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::ident_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tLOAD %s\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::if_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "if&0:\n"); break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "endif&0:\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::int_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tLOAD %s\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::mul_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tMUL\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::program_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 emitstr (n, "\t\tPROGRAM %s\n");break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tEND PROGRAM %s\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::store_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tSTORE\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::sub_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tSUB\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::target_ (int n)
{
		switch (status)
		{
			case TOP_DOWN:	 break;
			case PASS_OVER: break;
			case BOTTOM_UP: emitstr (n, "\t\tLADR %s\n"); break;
		}
		return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

short Calc_NodeAction::emit (int n) 
{
      int a;
   // Get string for this status (0 = TOP_DOWN, 1 = PASS_OVER, 2 = BOTTOM_UP).
      a = nact_arg [node[n].prod] + status;
      if (a >= 0 && arg_numb[a] >= 0)
      {
			emitstr (n, arg_text [arg_numb[a]]);
      }
		return (0);
}

#endif

/*--- End of Actions. -------------------------------------------------------*/

























