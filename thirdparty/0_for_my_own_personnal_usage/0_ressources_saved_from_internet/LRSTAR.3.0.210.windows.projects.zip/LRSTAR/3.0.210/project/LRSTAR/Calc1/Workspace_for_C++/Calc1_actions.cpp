
/* Source code by Compilerware with tabs = 3 */

#include "Calc1_main.h"
#include "Calc1_parser.h"
#include "Calc1_actions.h"

#ifdef TOKEN_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    error     																				  //

int   Calc1_TokenAction::error (short t)                    
{
	// Illegal character?
		if (token.end == token.start) 
		{
			token.end++;
			return (t); // Return zero (t should be zero).
		}
	// Do a symbol table lookup.
	// Could be a valid keyword or constant from an ambiguous grammar.
      return (lookup (t)); 
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    lookup    																				  //

int   Calc1_TokenAction::lookup (short t) // Look for Symbol.
{
		token.sti = add_symbol (t, token.start, token.end); 
      return (symbol[token.sti].term); // This works for {typedef}
}

#endif
#ifdef PARSE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    defterm   																				  //

short Typedef_ParseAction::defterm (short p) 
{
	   short i = pact_arg[p];				   // Get first argument index.
      short sti = PS [arg_numb[i]-1].sti; // Get sti for first argument.
      symbol[sti].term = arg_numb [i+1];  // Set term to second argument.
      return (0);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    delete_tree																				  //

short Calc1_ParseAction::delete_tree (short p)
{
      n_nodes--;                          // Get last node created.
      while (node[n_nodes].child > 0)     // While not leaf.      
      {
         n_nodes = node[n_nodes].child;   // Down to first node.  
      }                                 
      if (n_nodes == 1) root = 1;         // If AST is gone.     
      PS->node = 0;                       // Set *PS to 0.        
      return (0);
}  

#endif
#ifdef NODE_ACTIONS

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//		emit																						  //

short Calc1_NodeAction::emit (int n) 
{
      int a;
   // Get string for this status (0 = TOP_DOWN, 1 = PASS_OVER, 2 = BOTTOM_UP).
      a = nact_arg[node[n].prod] + status;
      if (a >= 0 && arg_numb[a] >= 0)
      {
			emitstr (n, arg_text [arg_numb[a]]);
      }
		return (0);
}

#endif

/*--- End of Actions. -------------------------------------------------------*/

























