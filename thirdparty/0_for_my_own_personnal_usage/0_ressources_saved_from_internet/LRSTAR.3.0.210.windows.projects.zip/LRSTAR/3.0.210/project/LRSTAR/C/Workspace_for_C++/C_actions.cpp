
/* Original source code by Compilerware with tabs = 3 */

		#include "C_main.h"
  		#include "C_actions.h"

#ifdef TOKEN_ACTIONS

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 // 
//    error     																				                        

int   C_TokenAction::error (short t)                    
{
		if (token.end == token.start) // Illegal character?
		{
			token.end++;
			return (t); // Return zero (t should be zero).
		}
	// Do a symbol table lookup, could be a valid keyword or constant.
		return (lookup (t)); 
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 // 
//    lookup    																				                        

int   C_TokenAction::lookup (short t) // Look for Symbol.
{
	// Do a symbol-table lookup for this token. 
		token.sti = add_symbol (t, token.start, token.end); 
		return (symbol[token.sti].term); // Retuen terminal symbol number. 
}

#endif
#ifdef PARSE_ACTIONS

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 // 
//    goal_ (not used, for testing only)												                        

short C_ParseAction::goal_ (short p) 
{
	   short a = pact_arg[p];				  // Get first argument index.
      return (0);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 // 
//    defterm   																				                        

short Typedef_ParseAction::defterm (short p) 
{
	   short i = pact_arg[p];				   // Get first argument index.
      short sti = PS [arg_numb[i]-1].sti; // Get sti for first argument.
      symbol[sti].term = arg_numb [i+1];  // Set term to second argument.
      return (0);
}

#endif
#ifdef NODE_ACTIONS

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 // 
//    goal_ (not used, for testing only)												                        

short C_NodeAction::goal_ (int n)
{
		ushort p = node[n].prod;
	   short a = nact_arg[p];				  // Get first argument index.
		return (0);
}

#endif

//                                                                                                 // 
/////////////////////////////////////////////////////////////////////////////////////////////////////
























