
/* Source code by Compilerware with tabs = 3 */

#ifndef cActions_H
#define cActions_H

#ifdef TOKEN_ACTIONS

		class Calc1_TokenAction : public Calc1_parser
		{
			public:	
         static int   error       (short);
         static int   lookup      (short);
		};

#endif

#ifdef PARSE_ACTIONS
																									   
		class Calc1_ParseAction : public Calc1_parser
		{
			public:	
			static short defterm     (short); 
			static short delete_tree (short); 
		};
		
#endif
#ifdef NODE_ACTIONS

		class Calc1_NodeAction : public Calc1_parser
		{
			public:		
			static short emit      (int);
		};
		
#endif

#endif

