  
#ifndef c_parser_h
#define c_parser_h

      #include "c_lexer.h"

      class c_parser : public c_lexer
		{
		   public:
		   static int   parse      (char* input_start);	
		   static void  parse_term ();	

		   static int   n_errors;		// Number of errors.
		   static int   n_lines;		// Number of lines read.
		   static int   max_errs;		// Maximum allowable errors.
         static int   line_number;
      };

#endif

