  
/* Source code by Compilerware, with tab = 3. */

		#define EXTERN
      #include "c_main.h"  

		#undef  EXTERN 
		#define EXTERN extern
      #include "c_lexer.h"   
      #include "c_parser.h"   

		#define WAIT_ON_KEY
		#ifdef  WAIT_ON_KEY
  		#include "conio.h"
		#endif

		extern int   c_parse (char*);
		extern void  option_init (int,  char*[]);
		extern void  input_init (char*);
		extern void  output_init (char*);
		extern void  input_term ();
		extern void  output_term ();

///////////////////////////////////////////////////////////////////////////////
//                                                                           //

int   main (int na, char *arg[])
{
      int time1, time2, thou, sec, ntr, t, ntps;

   // Initializations ...
		option_init (na, arg);							 
		input_init  (arg[1]);
		output_init (arg[1]);

   // Parsing ...
	   time1 = clock();	// Set clock.
		ntr   = c_parse (input.start);	// Get number of tokens read.
		time2 = clock ();	// Get elapsed time.

	// Compute time used ...
		t = time2 - time1;
		if (t == 0) t = 1;
		ntps  = CLOCKS_PER_SEC * (ntr/t); // Get number of tokens per sec.
      thou  = t * 1000 / CLOCKS_PER_SEC;
      sec   = thou / 1000;
      thou -= sec * 1000;

	// Printouts ...
      printf (" %11d.%03ld seconds.\n", sec, thou);
      printf (" %11s tokens per second.\n\n", number(ntps));
		fprintf (output.filedesc, " %11d.%03ld seconds.\n", sec, thou);
		fprintf (output.filedesc, " %11s tokens per second.\n\n", number(ntps));

   // Finish up ...
		input_term ();
		output_term ();
      quit ();
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

void  option_init (int na, char* arg[])
{
		int i;
      printf ("DFAC Lexer Test\n");
      if (na < 2)
      {
Opt:     printf ("\n");
         printf ("\t lexer <filename> [<option>...]\n");
         printf ("\n");
         printf ("\t options: \n");
         printf ("\t t - Trace each token.\n\n");
			quit ();
      }    

      option.trace = 0;
		for (i = 2; i < na; i++)
      {
         if (*arg[i] == 't') option.trace = 1; 
         else 
			{
				printf ("Invalid option: %s\n", arg[i]);
  				goto Opt;
			}
      }																 
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

void  input_init (char* fn)
{
      long  nb;										// Number of bytes actually read
		long _filelength (int);                // Get file length function.  

		input.filename = fn;
		input.filedesc = _open (input.filename, 0);        // Open the file.             
		if (input.filedesc < 0)                      // If open error.             
		{
			printf ("File %s not found.\n", input.filename);
			quit ();
		}

		input.filesize = _filelength (input.filedesc);  // Get filesize.             
		input.start = (char*)malloc(input.filesize+4);  // Get some space + 4.       
		*input.start = '\n';										// Put <eol> at beginning. 
		
		nb = 0;
		if (input.filesize > 0)
		{
			nb = _read (input.filedesc, input.start+1, input.filesize);	
			if (nb <=0)												
			{
				printf ("Read error or on file %s.\n", input.filename);
				quit ();
			}
		}

      input.end = input.start + 1 + nb;	// Set end-of-buffer pointer.          
      *input.end++ = EOF_MARK;
      *input.end++ = EOF_MARK;
		input.line_start = input.start + 1;			// Point at first line. 
      _close (input.filedesc);						// Close file.                         
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

void  input_term ()
{
		free (input.start);                  
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

void  output_init (char* fn)
{
      strcpy (output.filename, fn);        
      strcat (output.filename, ".txt"); 
      output.filedesc = fopen (output.filename, "w");  

      if (output.filedesc == NULL)
      {
         printf ("\n\n\nOutput file %s cannot be created.\n", output.filename);
         quit ();
      }
      fprintf (output.filedesc, "\nDFAC Lexer Test\n");
}
                                        
///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

void  output_term ()
{
      printf  ("Creating %s ...\n", output.filename);
	   fprintf (output.filedesc, "End of Output.\n");
      fclose  (output.filedesc);  
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 

char* number (int x)
{
		int i, j, k;
		char buff[16];
		static char string[256];

		_itoa (x, buff, 10);
		k = strlen (buff);
		i = k + (k-1)/3;
		string[i--] = 0;
		j = 0;
		while (1)
		{
			string[i--] = buff[--k];
			if (i < 0) break;
			if (++j % 3 == 0) string[i--] = ',';
		}
		return (string);
}

///////////////////////////////////////////////////////////////////////////////
//                                                                           // 
//    quit     																				  //

void  quit ()
{
		#ifdef WAIT_ON_KEY
   // Wait until key is pressed ...
	  	printf( "Press any key to continue ...\n");
	  	while( !_kbhit() );
		#endif
		exit (0);
}

/*--- End of Main Program. --------------------------------------------------*/

