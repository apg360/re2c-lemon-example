    
/* Source code by Compilerware, with tab = 3. */

		#define EXTERN extern
		#include "c_main.h"
		#include "c_lexer.h"
		#include "c_parser.h"

///////////////////////////////////////////////////////////////////////////////
//    
//    parse

int   c_parse (char* input_start) // Simple Parser.               
{
		int eof, i, n_tokens_read, n_lines_read, n_errors; 

		printf ("Reading %s ...\n", input.filename);
		fprintf (output.filedesc, "Reading %s ...\n", input.filename);

		n_errors      = 0;
		n_tokens_read = 0;
      n_lines_read  = 0;

		token.end = "\x1A";
		eof = c_lexer_read();
																				 
		for (i = 0; i < 1000; i++) // Parse input file 1000 times.
		{
         c_lexer_init (input_start);
    		while ((c_lexer_read ()) != eof)   
			{
				n_tokens_read++;
			/* if (option.trace)
			 	{
    	  			char c = *token.end;
  					*token.end = 0;
  					printf ("       %s\n", token.start);
  					*token.end = c; 
				}  */
			}
         n_lines_read += linenumb - 1; 
		}

		printf ("Done.\n\n");
		printf (" %11s lines read.\n",  number (n_lines_read));
		printf (" %11s tokens read.\n", number (n_tokens_read));
		printf (" %11s errors.\n",      number (n_errors));

		fprintf (output.filedesc, "Done.\n\n");
		fprintf (output.filedesc, " %11s lines read.\n",  number (n_lines_read));
		fprintf (output.filedesc, " %11s tokens read.\n", number (n_tokens_read));
		fprintf (output.filedesc, " %11s errors.\n",      number (n_errors));

		return (n_tokens_read);
}

///////////////////////////////////////////////////////////////////////////////





