    
/* Source code by Compilerware, with tab = 3. */

		#include "c_main.h"
		#include "c_lexer.h"

///////////////////////////////////////////////////////////////////////////////
//    

int   parse () // Simple Parser.               
{
		int eof, i, n_tokens_read, n_errors, n_lines_read; 

		printf ("Reading %s ...\n", input.filename);
		fprintf (output.filedesc, "Reading %s ...\n", input.filename);

		colnumb = 1;
		linenumb = 1;	
		n_errors = 0;
		n_tokens_read = 0;
      n_lines_read  = 0;

		token.end = "\x1A";
		eof = lexer_read();
																				 
		for (i = 0; i < 1000; i++)
		{											  
			lexer_init (input.linestart);
    		while ((lexer_read ()) != eof)   
			{
				n_tokens_read++;
			/* if (option.trace)
			 	{
    	  			char c = *token.end;
  					*token.end = 0;
  					printf ("       %s\n", token.start);
  					*token.end = c; 
				}  */
			}
         n_lines_read += linenumb - 1; 
		}

		printf ("Done.\n\n");
		printf (" %11s lines read.\n",  number(n_lines_read));
		printf (" %11s tokens read.\n", number(n_tokens_read));
		printf (" %11s errors.\n", number(n_errors));

		fprintf (output.filedesc, "Done.\n\n");
		fprintf (output.filedesc, " %11s lines read.\n",  number(n_lines_read));
		fprintf (output.filedesc, " %11s tokens read.\n", number(n_tokens_read));
		fprintf (output.filedesc, " %11s errors.\n", number(n_errors));

		return (n_tokens_read);
}

///////////////////////////////////////////////////////////////////////////////





