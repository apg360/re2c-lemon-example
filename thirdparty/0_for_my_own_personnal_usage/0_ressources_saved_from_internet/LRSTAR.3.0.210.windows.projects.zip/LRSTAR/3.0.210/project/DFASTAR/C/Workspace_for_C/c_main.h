
/* Source code by Compilerware, with tab = 3. */

		#ifdef MAIN
			#define EXTERN 
		#else 
			#define EXTERN extern
		#endif

	// Include Files ...
		#include "stdio.h"
	   #include "sys/types.h"
		#include "sys/stat.h"
      #include "stdlib.h"
      #include "string.h"
      #include "fcntl.h"
      #include "time.h"
      #include "io.h"

   // Defines ...
      #define uchar     unsigned char
      #define ushort    unsigned short
      #define ulong     unsigned long
      #define uint      unsigned int

		#define EOL_MARK  10 // End Of Line marker.
		#define EOF_MARK  26 // End Of File marker.

   // Typedefs ...
		typedef struct
		{
			char  trace;      // Trace input tokens.
		}
		Option;

		typedef struct 
		{
			char* start;		// First byte of input area.              
			char* end;			// Byte after input area.                      
			char* linestart;	// First byte of current line.            
			char* filename;	// Filename of input file.
			int   filesize;	// File size.
			int   filedesc;	// File descriptor.
		}
		Input;

		typedef struct
		{
			char  filename[256]; // File name.  
			FILE* filedesc;      //	File descriptor.
		}
		Output;

	// Global stuff ...
		EXTERN Option  option;
		EXTERN Input   input;
		EXTERN Output  output;

   // Global Functions ...
		extern void  quit();
		extern char* number (int x);

/*--- End of Header File. ---------------------------------------------------*/

