README for scripts/extended-pictographic
===========

This directory contains the Unicode UTS #35 `ExtendedPictographic.txt` data file,
intended to be parsed by the script `parse.py` to produce `ExtendedPictographic-Parsed.txt`.

This produces a series of `IntervalSet` entries to be consumed by
`UnicodeDataTemplateController`.
