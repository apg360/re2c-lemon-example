void main()
{
    int a=0;
    if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }

    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }

    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        a++;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
    else if( 3 > 4){
        ;
    }
}